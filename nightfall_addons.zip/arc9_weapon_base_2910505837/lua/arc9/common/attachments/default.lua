ATT.PrintName = "Konstantin Red Dot"
ATT.CompactName = "RDSx1"
ATT.Icon = Material("")
ATT.FullColorIcon = false -- This icon spans the entire area of the material and needs special treatment.
ATT.Description = [[Collimated red dot optic sight.]]
ATT.SortOrder = 0
ATT.MenuCategory = "ARC9 - Attachments"

ATT.CustomPros = {
    Ergonomics = 1,
    ["You're awesome"] = "",
}
ATT.CustomCons = {
    Bad = "-50",
    ["Warning: this enables something"] = "",
}

ATT.InstallSound = nil -- sounds for installing and uninstalling the attachment respectively
ATT.UninstallSound = nil

ATT.AdminOnly = false
ATT.Free = false
ATT.Ignore = true
ATT.AttNotForNPCs = false -- for randomizing through presets too

ATT.Model = ""
ATT.WorldModel = "" -- optional
ATT.BoxModel = nil --"models/items/arc9/att_plastic_box.mdl" 
--                                          ^ Use att_plastic_box (modern middle sized container), att_wooden_box (old big box) or att_cardboard_box (cheap small box)
-- If nil, will use slot defined ATT.Pack

-- Material for stickers
ATT.StickerMaterial = ""
ATT.StickerDrawFunc = function(swep, model, wm)
end

-- Used to attach another model to a bone of this model.
ATT.CharmModel = ""
ATT.CharmBone = ""
ATT.CharmOffset = Vector(0, 0, 0)
ATT.CharmAngle = Angle(0, 0, 0)
ATT.CharmMaterial = nil
ATT.CharmBodygroups = ""
ATT.CharmScale = 1
ATT.CharmSkin = 0

ATT.Scale = 1
ATT.ModelOffset = Vector(0, 0, 0)
ATT.ModelAngleOffset = Angle(0, 0, 0)
ATT.DrawFunc = function(swep, model, wm) end
ATT.ModelSkin = 0
ATT.ModelBodygroups = ""
ATT.ModelMaterial = ""

ATT.NoDraw = false
ATT.TranslucentPass = false -- if that model has $translucent 1 in vmt, will be drawn behind c_hands otherwise
-- ATT.TranslucentPassExtraMat = Material( "models/" ) -- extra material to apply during translucent pass, use for vertexlit + refract
-- ATT.TranslucentPassBlend = 0.75 -- blend to use during translucent pass

ATT.Material = "material/path"

-- Use SubMaterial0 through SubMaterial31 to set submaterials
ATT.SubMaterial0 = "material/path"

-- For model submats
ATT.EnableModelSubMaterial = true
ATT.ModelSubMaterial0 = "material/path"

ATT.InvAtt = "" -- Having this other attachment will grant access to this one.

ATT.Category = "" -- can be "string" or {"list", "of", "strings"}
-- Set to "*" (exactly) to make this attachment available for all slots

ATT.Folder = "" -- a string separated by slashes (/), e.g. "my/folder/hierarchy"
-- to give a folder a name, add a localization string "folder.FOLDERNAME"

ATT.ActivateElements = {"plum_stock"}

-- Does precisely the same thing AttachmentElements do
-- Use ONLY for weapon-specific attachments. These don't get modified in any way shape or form
-- Oh, and just... try not to use this if you can, okay? Consider this a port of last resort.
ATT.Element = {
    --[[]
    Bodygroups = {
        {1, 1}
    },
    AttPosMods = {
        [1] = { -- slot index
            Pos = Vector(),
            Ang = Angle(),
        }
    }
    Models = {
        Model = "",
        Pos = Vector(),
        Ang = Angle(),
        Bone = "",
        BoneMerge = false,
        Skin = 0,
        Bodygroups = "000",
        Scale = 1,
        ScaleVector = Vector(),
    }
    -- Other attachment parameters work here
    ]]
}

ATT.ToggleOnF = false -- This attachment is toggleable with the flashlight key.
ATT.ToggleStats = {
    ["On"] = {
        SpreadAddHipFire = -0.1,
    },
    ["Off"] = {}
}
-- max of 256 togglestats

ATT.MuzzleDevice = false -- set to true if you want to use this to emit particles
ATT.MuzzleDevice_Priority = 0

ATT.Flashlight = false
ATT.FlashlightColor = Color(255, 255, 255)
ATT.FlashlightMaterial = "" -- Not material but texture, you need here path to vtf file
ATT.FlashlightBrightness = 3
ATT.FlashlightDistance = 1024
ATT.FlashlightFOV = 70
ATT.FlashlightAttachment = 0
ATT.Flashlight360 = false -- for funnies: set to true to make flare glow from any side

ATT.Laser = false
ATT.LaserStrength = 1
ATT.LaserFlareMat = nil
ATT.LaserTraceMat = nil
ATT.LaserColor = Color(255, 0, 0)
ATT.LaserAttachment = 0

-- ATT.Flare = false
-- ATT.FlareColor = Color(255, 255, 255)
-- ATT.FlareSize = 200
-- ATT.FlareAttachment = 0
-- ATT.FlareFocus = false -- This flare comes from a source of light that persists over distance, like a laser.

-- Allows a custom sight position to be defined

ATT.Sights = {
    {
        Pos = Vector(0, 0, 0),
        Ang = Angle(0, 0, 0),
        Reticle = nil, -- Same as ATT.RTScopeReticle or HoloSightReticle but this sight only. Better cache material somewhere outside this structure: local Reticle1 = Material("reticle1.png", "mips smooth") and here you type only Reticle1). If not defined, will use ATT.RTScopeReticle/HoloSightReticle
        ExtraSightData = {
            -- like an atttbl, only works for sight related data
        },
        Blur = true, -- If arc9_fx_adsblur 1 then blur gun in that sight. Disable if your sights have a big field of view and the blur distorts picture
        DeferSights = false, -- the first parent sight will be used for sight data instead. Use for magnifiers
        Magnification = 1,
        Disassociate = false, -- don't associate with parent slot
        NoSensAdjustment = false, -- no sens adjustments for rt scopes
        IsIronSight = false, -- disable if another sight is installed
        KeepBaseIrons = false,
        InvertColors = false,
        UBGLOnly = false, -- Only show this sight when UBGL is equipped
        OnSwitchToSight = function(self, slottbl) end,
        OnSwitchFromSight = function(self, slottbl) end,
    }
}

ATT.HoloSight = false
ATT.HoloSightReticle = ""
ATT.HoloSightSize = 32
ATT.HoloSightColor = Color(255, 255, 255)
ATT.HoloSightColorable = true -- Holosight takes color from player settings
ATT.HoloSightFunc = function(swep, pos, mdl) end -- pos = reticle position
ATT.HoloSightDepthAdjustment = 0.0093 -- Increase this slightly if holosight clips into the model

ATT.FLIRHotFunc = function(swep, ent) end -- return true for hot and false for cold

ATT.RTScope = true
ATT.RTScopeSubmatIndex = 1
ATT.RTScopeReticle = Material("")
ATT.RTScopeReticleScale = 1
ATT.RTScopeColorable = true -- Scope takes color from player settings
ATT.RTCollimator = false -- Disables cheap scopes fov boost, disables sensivity adjustements
ATT.RTScopeNoBlur = false -- By default, if arc9_fx_rtblur 1 then world behind gun wil be blurred. Enable if your "scope" is not so scope.
ATT.RTScopeNoPP = false

-- list of removed variables (but kept as legacy fallback)   DO NOT INCLUDE THEM!   REMOVE FROM EXISTING SCOPES!!!
-- RTScopeNoShadow   RTScopeBlackBox   RTScopeBlackBoxShadow   RTScopeShadowIntensity    RTScopeFOV     ScopeScreenRatio

ATT.RTScopeNew_ShadowScale = 1 -- overall scale of shadows -- reticle scale also affects shadow scale so you can use this to combat this
ATT.RTScopeNew_ShadowIntensity = 1 -- do not set to zero
ATT.RTScopeNew_FrontShadow = true -- shadow in front of scope
ATT.RTScopeNew_FrontShadowScale = 1
ATT.RTScopeNew_BackShadow = true -- shadow close to your eye, hides visible reticle when not aimed
ATT.RTScopeNew_BackShadowScale = 1
ATT.RTScopeNew_ReticleBlackBox = false -- blackbox
ATT.RTScopeNew_DisableShader = false
ATT.RTScopeNew_DisableShaderEyeOffset = false -- disable dynamic eyeoffset (vignette & chrom aberation) from shader if your scope is fucked up
ATT.RTScopeNew_ChromaticAberrationMult = 1
ATT.RTScopeNew_ShaderDistorsionMult = 1

ATT.RTScopeNew_FPSLock = 30 -- digital scope thing -- for fpslock work properly, you need either pixelation either shader enabled. sory.
ATT.RTScopeNew_Pixelation = 240 -- same, vertical resolution i think

-- ATT.RTScopeNew_FixAngle = Angle(-0.034, 84.588, 4.109) -- If scope angle isn't 0, 0, 0, it might look ASS. Fix this by setting this to "print" first, aim & setang 0 0 0 in console, copying angle from console to this
ATT.RTScopeNew_ForceExpensive = false -- highly specific
ATT.RTScopeNew_ForceCheap = false -- highly specific
ATT.RTScopeNew_OnlyInSights = false -- highly specific
ATT.RTScopeNew_DisableRTVM = false -- if rendereing gun in this scopes renders it too much

ATT.RTScopeDrawFunc = function(swep, rtsize, sight) end -- Square reticle-like 2d context, works good as regular reticle  (remove counterrotation thing if you had it!)
ATT.RTScopeNew_DrawFunc3D = function(swep, scrh, sight, ang, pos) end -- Advanced drawfunc in 3d context
ATT.RTScopeNew_DrawFunc2D = function(swep, scrw, scrh, sight) end -- Overlay drawfunc in 2d context, not moving unlike RTScopeDrawFunc. Also draws fullres

-- Extra post processing like DrawMotionBlur() DrawSharpen() DrawBloom()
ATT.RTScopeCustomPPFunc = function(swep) end


ATT.RTScopeMagnification = 4 -- New zoom thing, 1 is 1x, 4 is 4x (crazy!) Please use it.

ATT.RTScopeNightVision = true
ATT.RTScopeNightVisionMonochrome = true
ATT.RTScopeNightVisionCC = {
    ["$pp_colour_addr"] = -255,
    ["$pp_colour_addg"] = 0,
    ["$pp_colour_addb"] = -255,
    ["$pp_colour_brightness"] = 0,
    ["$pp_colour_contrast"] = 4,
    ["$pp_colour_colour"] = 1,
    ["$pp_colour_mulr"] = 0,
    ["$pp_colour_mulg"] = 0,
    ["$pp_colour_mulb"] = 0,
    ["$pp_colour_inv"] = 0
}
ATT.RTScopeNightVisionFunc = function(swep) end

ATT.RTScopeFLIR = true
ATT.RTScopeFLIRSolid = false -- Solid color FLIR instead of like a shaded look
ATT.RTScopeFLIRHighlightColor = Color(255, 255, 255)
ATT.RTScopeFLIRMonochrome = true
ATT.RTScopeFLIRNoPP = false
ATT.RTScopeFLIRBlend = 0.25
ATT.RTScopeFLIRCCHot = { -- Color correction drawn only on FLIR targets
    ["$pp_colour_addr"] = 0,
    ["$pp_colour_addg"] = 0,
    ["$pp_colour_addb"] = -255,
    ["$pp_colour_brightness"] = 0,
    ["$pp_colour_contrast"] = 4,
    ["$pp_colour_colour"] = 1,
    ["$pp_colour_mulr"] = 0,
    ["$pp_colour_mulg"] = 0,
    ["$pp_colour_mulb"] = 0,
    ["$pp_colour_inv"] = 0,
}
ATT.RTScopeFLIRCCCold = { -- Color correction drawn only on FLIR targets
    ["$pp_colour_addr"] = 0,
    ["$pp_colour_addg"] = 0,
    ["$pp_colour_addb"] = -255,
    ["$pp_colour_brightness"] = 0,
    ["$pp_colour_contrast"] = 4,
    ["$pp_colour_colour"] = 1,
    ["$pp_colour_mulr"] = 0,
    ["$pp_colour_mulg"] = 0,
    ["$pp_colour_mulb"] = 0,
    ["$pp_colour_inv"] = 0
}
ATT.RTScopeFLIRFunc = function(swep) end
ATT.RTScopeFLIRHotOnlyFunc = function(swep) end -- same but only for hot targets (try `DrawSobel(0.05)` here!!))
ATT.RTScopePostInvertFunc = function(swep) end -- only when InvertColors is true

ATT.RTScopeMotionBlur = false

ATT.RTScopeAdjustable = false -- adjustable scope settings
ATT.RTScopeAdjustmentLevels = 4
ATT.RTScopeFOVMin = 10
ATT.RTScopeFOVMax = 2.5

ATT.Attachments = {
    {
        PrintName = "",
        DefaultIcon = Material(""),
        InstalledElements = "", -- single or list of elements to activate when something is installed here
        UnInstalledElements = "",
        Integral = false, -- cannot be removed; set to a string to make it the "default"
        Category = "", -- single or {"list", "of", "values"}
        Bone = "",
        Pos = Vector(0, 0, 0),
        Ang = Angle(0, 0, 0),
        KeepBaseIrons = false,
        StickerModel = "" -- applies to the current model if one exists
    }
}

ATT.LHIK = false
ATT.LHIK_Priority = 0

ATT.RHIK = false
ATT.RHIK_Priority = 0

ATT.IKAnimationProxy = {
    ["reload_ubgl"] = {
        -- All standard animation stuff works
        Source = "",
        Priority = 1, -- Like _Priority, this determines whether a proxy should override other identical animations.
    }
} -- When an animation event plays, override it with one based on this LHIK model.

ATT.IKAnimationAlsoPlayBase = false -- Also play the base animation

ATT.IKGunMotionQCA = nil -- Make the gun move while in IK animation

ATT.IKGunMotionMult = 1

ATT.IKCameraMotionQCA = nil
ATT.IKCameraMotionQCA_Mult = nil
ATT.IKCameraMotionOffsetAngle = Angle(0, 0, 0)