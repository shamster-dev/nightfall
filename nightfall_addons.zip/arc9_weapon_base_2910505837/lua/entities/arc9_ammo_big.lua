AddCSLuaFile()

ENT.Type                     = "anim"
ENT.Base                     = "arc9_ammo"

ENT.PrintName                = "Ammo Crate"
ENT.Category                 = "ARC9 - Ammo"

ENT.Spawnable                = true
ENT.Model                    = "models/items/ammocrate_ar2.mdl"
ENT.ModelOptions = nil

ENT.InfiniteUse = true
ENT.OpeningAnim = false
ENT.NextUse = 0
ENT.Open = false

ENT.Supply = 6
