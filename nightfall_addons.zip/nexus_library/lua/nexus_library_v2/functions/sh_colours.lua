local themes = {}
themes["Default"] = {
    ["background"] = Color(10, 10, 12), // Deep, dark cinematic dread background (almost black)
    ["primary"] = Color(110, 24, 24), // Muted dried-blood red for primary elements

    ["background-secondary-text"] = Color(20, 18, 18, 120),
    ["background-text"] = Color(10, 10, 12), // Dark text to match background
    ["primary-text"] = Color(240, 235, 235, 220), // Cold bone white for primary text
    ["secondary-text"] = Color(150, 140, 140, 120), // Ash grey for less important text

    ["secondary"] = Color(10+15, 10+15, 12+15), // Slightly lighter dark grey for layered elements
    ["secondary-2"] = Color(10+30, 10+30, 12+30), // Lighter charcoal for inputs/scrollbars

    ["header"] = Color(25, 20, 20, 255), // Muted dark header

    ["accent"] = Color(160, 20, 20, 255), // Blood red highlight accent

    ["orange"] = Color(180, 85, 30, 255), // Rust / burnt orange
    ["overlay"] = Color(110, 24, 24, 15), // Faint blood red overlay for hover
    ["highlight"] = Color(160, 20, 20, 40), // Active highlight in blood red
    ["red"] = Color(170, 30, 30, 255), // Deep red
    ["blue"] = Color(114, 160, 220), // Cold steel blue
    ["green"] = Color(75, 105, 80, 255), // Sickly decaying green
}

function Nexus:GetThemes()
    return themes
end

function Nexus:GetColor(str)
    str = string.lower(str)

    return themes["Default"][str]
end