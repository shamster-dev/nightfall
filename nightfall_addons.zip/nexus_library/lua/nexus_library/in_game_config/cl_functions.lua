concommand.Add("nexus_config", function()
    if IsValid(Nexus.ConfigFrame) then Nexus.ConfigFrame:Remove() end
    local frame = vgui.Create("Nexus:V2:Frame")
    frame:SetSize(Nexus:GetScale(1100), Nexus:GetScale(700))
    frame:MakePopup()
    frame:Center()
    frame.ConfigFrame = frame
    Nexus.ConfigFrame = frame
    frame.OnRefresh = function()
        RunConsoleCommand("nexus_config")
    end
    frame:SetTitle(Nexus:GetPhrase("Config"))

    local panel = frame:Add("Nexus:Config:MenuV2")
    panel:Dock(FILL)
    Nexus.ConfigFrame.Contents = panel
end)

Nexus.DataCache = Nexus.DataCache or {}
net.Receive("Nexus:IGC:v2:NetworkFull", function()
    local data = net.ReadUInt(32)
    data = net.ReadData(data)
    data = util.Decompress(data)
    data = util.JSONToTable(data)

    Nexus.DataCache = data

    hook.Run("Nexus:ReceiveIGC")
end)

local function GetElementInfo(configID)
    for _, addon in ipairs(Nexus.Addons or {}) do
        local data = addon.Elements
        for _, v in ipairs(data) do
            if v.data and v.data.id == configID then
                return v.data
            end
        end
    end

    return false
end

function Nexus:GetValue(id)
    if Nexus.DataCache[id] then
        return Nexus.DataCache[id]
    end

    local info = GetElementInfo(id)
    return info and info.defaultValue or false
end

net.Receive("Nexus:IGC:V2:NetworkValue", function()
    local elementType = net.ReadString()
    if elementType == "button-row" then
        local id = net.ReadString()
        local value = net.ReadType()

        Nexus.DataCache[id] = value
        hook.Run("Nexus:IGC:ValueChanged", id, value)
    elseif elementType == "text-entry" then
        local id = net.ReadString()
        local value = net.ReadString()

        local info = GetElementInfo(id)
        if info.isNumeric then
            value = tonumber(value) or info.defaultValue
        end

        Nexus.DataCache[id] = value
        hook.Run("Nexus:IGC:ValueChanged", id, value)
    elseif elementType == "multi-text-entry" then
        local id = net.ReadString()

        local info = GetElementInfo(id)
        local data = {}
        for k, v in ipairs(info.entries) do
            data[v.id] = net.ReadString()
            if v.isNumeric then
                data[v.id] = tonumber(data[v.id]) or v.default
            end
        end

        Nexus.DataCache[id] = data
        hook.Run("Nexus:IGC:ValueChanged", id, data)
    elseif elementType == "key-table" then
        local id = net.ReadString()

        local isAdd = net.ReadBool()

        local info = GetElementInfo(id)
        local data = Nexus:GetValue(id)

        if isAdd then
            local value = net.ReadString()
            if info.isNumeric then
                value = tonumber(value) or nil
            end

            data[value] = isAdd and true or nil

            Nexus.DataCache[id] = data
            hook.Run("Nexus:IGC:ValueChanged", id, {isAdd = isAdd, value = value})
        else
            local int = net.ReadUInt(8)
            for i = 1, int do
                local value = net.ReadString()
                data[value] = nil
                data[tonumber(value) or value] = nil

                hook.Run("Nexus:IGC:ValueChanged", id, {isAdd = false, value = value})
            end

            Nexus.DataCache[id] = data
        end
    elseif elementType == "table" then
        local id = net.ReadString()
        local isAdd = net.ReadBool()
        local data = Nexus:GetValue(id)

        local info = GetElementInfo(id)
        if isAdd then
            local tbl = {
                m_id = net.ReadUInt(20),
            }
            for _, v in ipairs(isfunction(info.values) and info.values() or info.values) do
                local value
                if v.type == "TextEntry" and v.isNumeric then
                    value = tonumber(net.ReadString())
                elseif v.type == "TextEntry" then
                    value = net.ReadString()
                elseif v.type == "ComboBox" then
                    value = net.ReadString()
                elseif v.type == "CheckBox" then
                    value = net.ReadBool()
                end

                tbl[v.id] = value
            end

            table.Add(data, {tbl})
            hook.Run("Nexus:IGC:ValueChanged", id, {isAdd = true, value = tbl})
        else
            local count = net.ReadUInt(8)
            for i = 1, count do
                local m_id = net.ReadUInt(20)
                for key, v in ipairs(data) do
                    if v["m_id"] == m_id then
                        table.remove(data, key)
                        break
                    end
                end

                hook.Run("Nexus:IGC:ValueChanged", id, {isAdd = false, id = m_id})
            end
        end

        Nexus.DataCache[id] = data
    end
end)

net.Receive("Nexus:IGC:V2:ValueEditted", function()
    local configID = net.ReadString()
    local column = net.ReadString()
    local m_id = net.ReadUInt(32)

    local int = net.ReadUInt(2)
    local value;
    if int == 0 then
        value = tonumber(net.ReadString())
    elseif int == 1 then
        value = net.ReadString()
    elseif int == 2 then
        value = net.ReadBool()
    end

    for _, v in ipairs(Nexus.DataCache[configID]) do
        if v["m_id"] ~= m_id then continue end
        v[column] = value
        break
    end

    hook.Run("Nexus:IGC:V2:Edited", configID, column, m_id, value)
end)