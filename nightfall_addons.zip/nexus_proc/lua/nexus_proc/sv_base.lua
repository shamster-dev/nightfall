function Nexus.Proc.Base:GetHP()
    return GetGlobalInt("NightFall:BaseHP", self.MaxHP)
end

util.AddNetworkString("NightFall:Base:DamageEffect")
function Nexus.Proc.Base:SetHP(val)
    local oldHP = self:GetHP()
    local newHP = math.Clamp(math.Round(val), 0, self.MaxHP)
    SetGlobalInt("NightFall:BaseHP", newHP)

    if oldHP ~= newHP then
        net.Start("NightFall:Base:DamageEffect")
        net.Broadcast()

        -- Trigger defeat state if base reaches 0 during active rounds
        if newHP <= 0 and GetGlobalInt("NightFall:RoundState", ROUND_WAITING) == ROUND_ACTIVE then
            Nexus.Proc.Rounds.SetState(ROUND_DEFEAT, FADE_DURATION)
        end
    end
end

function Nexus.Proc.Base:TakeDamage(amount, attacker)
    local current = self:GetHP()
    self:SetHP(current - amount)

    -- Emit a structure/wall hit sound at the location of damage or at random wall
    local randomWall = self.Walls[math.random(#self.Walls)]
    local soundPos = randomWall and (randomWall.startPos + randomWall.endPos) * 0.5 or Vector(0,0,0)
    sound.Play("physics/concrete/concrete_impact_bullet" .. math.random(1,4) .. ".wav", soundPos, 80, 100, 1)
end