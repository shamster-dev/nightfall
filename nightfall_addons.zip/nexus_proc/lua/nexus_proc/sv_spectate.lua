-- When a player dies during an active round, put them into spectator
hook.Add("PostPlayerDeath", "NexusProc:SpectateOnDeath", function(ply)
    local state = GetGlobalInt("NightFall:RoundState", ROUND_WAITING)
    if state ~= ROUND_ACTIVE then return end

    timer.Simple(0.1, function()
        if not IsValid(ply) then return end
        
        -- Set up base spectator properties
        ply:SetTeam(TEAM_SPECTATOR)
        
        -- Find a default target player to spectate
        local target = nil
        for _, p in ipairs(player.GetAll()) do
            if IsValid(p) and p ~= ply and p:Alive() and p:Team() ~= TEAM_SPECTATOR then
                target = p
                break
            end
        end

        if IsValid(target) then
            ply:Spectate(OBS_MODE_CHASE)
            ply:SpectateEntity(target)
            ply.NexusSpectateTarget = target
        else
            -- If no target found, spectate own ragdoll or default to roaming
            if IsValid(ply.NexusRagdoll) then
                ply:Spectate(OBS_MODE_CHASE)
                ply:SpectateEntity(ply.NexusRagdoll)
            else
                ply:Spectate(OBS_MODE_ROAMING)
            end
        end
    end)
end)

-- Allow dead players to cycle spectating targets using attack/jump keys
hook.Add("KeyPress", "NexusSpectatorCycleKeys", function(ply, key)
    if ply:Team() ~= TEAM_SPECTATOR or not ply:GetObserverMode() or ply:GetObserverMode() == OBS_MODE_NONE then return end

    -- Primary attack (left click): Cycle forward. Secondary attack (right click): Cycle mode (Chase / Orbit).
    -- Jump key (space): Cycle forward.
    if key == IN_ATTACK or key == IN_JUMP or key == IN_ATTACK2 then
        local alives = {}
        for _, p in ipairs(player.GetAll()) do
            if IsValid(p) and p:Alive() and p:Team() ~= TEAM_SPECTATOR then
                table.insert(alives, p)
            end
        end

        if #alives == 0 then return end

        if key == IN_ATTACK2 then
            -- Cycle observer mode between CHASE (first person follow) and ORBIT (third person orbit rotate)
            local currentMode = ply:GetObserverMode()
            local nextMode = (currentMode == OBS_MODE_CHASE) and OBS_MODE_IN_EYE or OBS_MODE_CHASE
            ply:Spectate(nextMode)
            return
        end

        -- Cycle spectate target player
        local currentTarget = ply:GetObserverTarget()
        local nextIdx = 1

        if IsValid(currentTarget) then
            for idx, p in ipairs(alives) do
                if p == currentTarget then
                    nextIdx = idx + 1
                    if nextIdx > #alives then nextIdx = 1 end
                    break
                end
            end
        end

        local targetPlayer = alives[nextIdx]
        if IsValid(targetPlayer) then
            ply:SpectateEntity(targetPlayer)
            ply.NexusSpectateTarget = targetPlayer
            ply:ChatPrint("[Spectator] Now spectating: " .. targetPlayer:Nick() .. " (" .. (ply:GetObserverMode() == OBS_MODE_IN_EYE and "In-Eye" or "Chase/Orbit") .. ")")
        end
    end
end)