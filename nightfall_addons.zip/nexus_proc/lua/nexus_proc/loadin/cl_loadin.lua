-- cl_loadin.lua
-- Client-side loading hooks and UI triggers for the Nexus load-in menu.

net.Receive("Nexus:Loadin:OpenMenu", function()
    if IsValid(Nexus.Proc.LoadinMenuPanel) then
        Nexus.Proc.LoadinMenuPanel:Remove()
    end
    
    Nexus.Proc.LoadinMenuPanel = vgui.Create("Nexus:Proc:Menu")
end)

concommand.Add("nexus_menu", function()
    if IsValid(Nexus.Proc.LoadinMenuPanel) then
        Nexus.Proc.LoadinMenuPanel:Remove()
    end
    
    Nexus.Proc.LoadinMenuPanel = vgui.Create("Nexus:Proc:Menu")
end)

concommand.Add("nexus_weapons", function()
    if IsValid(Nexus.Proc.WeaponsPanel) then
        Nexus.Proc.WeaponsPanel:Remove()
    end

    Nexus.Proc.WeaponsPanel = vgui.Create("Nexus:Proc:WeaponsMenu")
    Nexus.Proc.WeaponsPanel:SetAlpha(0)
    Nexus.Proc.WeaponsPanel:AlphaTo(255, 0.6, 0)
    Nexus.Proc.WeaponsPanel:MakePopup()
end)
