-- sh_weapons.lua
-- Shared weapon & attachment unlock settings and loadout management.

Nexus.Proc = Nexus.Proc or {}
Nexus.Proc.Weapons = Nexus.Proc.Weapons or {}

-- Available weapons list
Nexus.Proc.Weapons.List = {}

local function PopulateWeapons()
    local tbl = {}
    local added = {}

    -- Only M4 and X16 are free starter weapons. Everything else must be unlocked.
    local defaults = {
        { class = "arc9_cod2019_ar_m4",        name = "M4A1",      category = "Primary",   subCategory = "Assault Rifles",   desc = "Versatile fully automatic assault rifle.",          defaultUnlocked = true,  price = 0    },
        { class = "arc9_cod2019_pi_x16",       name = "X16",       category = "Secondary", subCategory = "Pistols",           desc = "Standard-issue semi-automatic sidearm.",            defaultUnlocked = true,  price = 0    },
        { class = "arc9_cod2019_ar_ak47",      name = "AK-47",     category = "Primary",   subCategory = "Assault Rifles",   desc = "Heavy-hitting assault rifle with high recoil.",     defaultUnlocked = true,  price = 0    },
        { class = "arc9_cod2019_sm_mp5",       name = "MP5",       category = "Primary",   subCategory = "Submachine Guns",  desc = "Reliable close-quarters submachine gun.",           defaultUnlocked = false, price = 800  },
        { class = "arc9_cod2019_sh_model680",  name = "Model 680", category = "Primary",   subCategory = "Shotguns",         desc = "12-gauge pump-action shotgun.",                     defaultUnlocked = false, price = 650  },
        { class = "arc9_cod2019_sn_ax50",      name = "AX-50",     category = "Primary",   subCategory = "Sniper Rifles",    desc = "High-caliber bolt-action sniper rifle.",            defaultUnlocked = false, price = 1800 },
        { class = "arc9_cod2019_pi_m19",       name = "M19",       category = "Secondary", subCategory = "Pistols",           desc = "Modern tactical sidearm with high fire rate.",      defaultUnlocked = false, price = 500  },
        { class = "arc9_cod2019_pi_50gs",      name = ".50 GS",    category = "Secondary", subCategory = "Pistols",           desc = "Hand cannon chambered in .50 Action Express.",      defaultUnlocked = false, price = 1200 },
    }

    for _, w in ipairs(defaults) do
        table.insert(tbl, w)
        added[w.class] = true
    end

    -- Dynamically query GMod registered weapons
    for _, wep in ipairs(weapons.GetList()) do
        local class = wep.ClassName
        if class and not added[class] then
            local lowerClass = string.lower(class)
            local isARC9 = string.sub(lowerClass, 1, 4) == "arc9" and class ~= "arc9_base" and class ~= "arc9_base_shield"
            -- Hide any weapon with "base" in the classname (e.g. arc9_base_*, arc9_cod2019_base_*)
            if isARC9 and string.find(lowerClass, "base", 1, true) then isARC9 = false end
            if isARC9 then
                local subcategory = wep.SubCategory or wep.Category or "Other"
                if string.find(subcategory, " - ") then
                    subcategory = string.Split(subcategory, " - ")[2] or subcategory
                end

                -- Determine Primary vs Secondary based on slot and subcategory
                local secondarySubcats = {
                    ["Pistols"]            = true,
                    ["Handguns"]           = true,
                    ["Handguns (AKIMBO)"]  = true,
                    ["Melee"]              = true,
                    ["Lethal"]             = true,
                    ["Tactical"]           = true,
                    ["Lethal & Tactical"]  = true,
                    ["Launchers"]          = true,
                    ["Other"]              = true,
                }

                local cat = "Primary"
                local slot = wep.Slot or 2
                if slot == 1 or secondarySubcats[subcategory] or wep.Category == "Handguns" then
                    cat = "Secondary"
                end

                local name = wep.PrintName or class
                local desc = wep.Description or wep.Instructions or "An ARC9 weapon."

                table.insert(tbl, {
                    class = class,
                    name = name,
                    category = cat,
                    subCategory = subcategory,
                    desc = desc,
                    defaultUnlocked = false
                })
                added[class] = true
            end
        end
    end

    table.sort(tbl, function(a, b) return a.name < b.name end)
    Nexus.Proc.Weapons.List = tbl
end

PopulateWeapons()

hook.Add("InitPostEntity", "Nexus:Proc:PopulateWeapons", function()
    PopulateWeapons()
end)

-- Attachments that are free/default for all players (shortname = true)
-- Everything else requires explicit unlock via Nexus.Proc.Weapons:UnlockAttachment()
Nexus.Proc.Weapons.DefaultAttachments = Nexus.Proc.Weapons.DefaultAttachments or {}

-- Starter attachments pre-equipped on the M4 for new players (always free)
Nexus.Proc.Weapons.DefaultAttachments["cod2019_attach_muzzlemelee01"] = true
Nexus.Proc.Weapons.DefaultAttachments["cod2019_m4a1_barrel_short"]    = true
Nexus.Proc.Weapons.DefaultAttachments["cod2019_optic_reflex_west"]    = true

-- Keep LockedAttachments as an alias for compatibility (unused in new logic)
Nexus.Proc.Weapons.LockedAttachments = Nexus.Proc.Weapons.LockedAttachments or {}

-- Client-side unlock table (populated via net message from server)
if CLIENT then
    Nexus.Proc.Weapons.ClientUnlocks = Nexus.Proc.Weapons.ClientUnlocks or { weapons = {}, attachments = {} }
end

-- Helper functions
function Nexus.Proc.Weapons:IsWeaponUnlocked(ply, class)
    if SERVER then
        -- Check if it's a default-unlocked weapon in our list
        for _, w in ipairs(self.List) do
            if w.class == class and w.defaultUnlocked then return true end
        end
        -- Otherwise check PData
        return ply:GetPData("nexus_weapon_unlocked_" .. class, "0") == "1"
    else
        -- On client read from the server-synced table
        local unlocks = Nexus.Proc.Weapons.ClientUnlocks
        if unlocks.weapons[class] then return true end
        -- Default-unlocked weapons are always available
        for _, w in ipairs(self.List) do
            if w.class == class and w.defaultUnlocked then return true end
        end
        return false
    end
end

function Nexus.Proc.Weapons:IsAttachmentUnlocked(ply, attShortName)
    if SERVER then
        -- Free for everyone if in DefaultAttachments
        if self.DefaultAttachments[attShortName] then return true end
        -- Otherwise require explicit PData unlock
        return ply:GetPData("nexus_att_unlocked_" .. attShortName, "0") == "1"
    else
        -- On client read from the server-synced table
        local unlocks = Nexus.Proc.Weapons.ClientUnlocks
        if self.DefaultAttachments[attShortName] then return true end
        return unlocks.attachments[attShortName] == true
    end
end

-- Server command to unlock things (useful for end-of-round testing / future unlocks)
if SERVER then
    function Nexus.Proc.Weapons:UnlockWeapon(ply, class)
        ply:SetPData("nexus_weapon_unlocked_" .. class, "1")
        ply:ChatPrint("[Loadout] Unlocked weapon: " .. class)
        if self.SyncToClient then self.SyncToClient(ply) end
    end

    function Nexus.Proc.Weapons:UnlockAttachment(ply, attShortName)
        ply:SetPData("nexus_att_unlocked_" .. attShortName, "1")
        ply:ChatPrint("[Loadout] Unlocked attachment: " .. attShortName)
        if self.SyncToClient then self.SyncToClient(ply) end
    end
    
    -- Reset all progression command
    concommand.Add("nexus_reset_progression", function(ply, cmd, args)
        if IsValid(ply) and not ply:IsSuperAdmin() then return end
        local target = IsValid(ply) and ply or player.GetAll()[1]
        if not IsValid(target) then return end
        
        for _, w in ipairs(Nexus.Proc.Weapons.List) do
            target:RemovePData("nexus_weapon_unlocked_" .. w.class)
        end
        if ARC9 and ARC9.Attachments then
            for att, _ in pairs(ARC9.Attachments) do
                target:RemovePData("nexus_att_unlocked_" .. att)
            end
        end
        
        target:ChatPrint("[Loadout] All weapon/attachment progression has been reset!")
        if Nexus.Proc.Weapons.SyncToClient then Nexus.Proc.Weapons.SyncToClient(target) end
    end)

    -- Unlock everything command
    concommand.Add("nexus_unlock_all", function(ply, cmd, args)
        if IsValid(ply) and not ply:IsSuperAdmin() then return end
        
        local target = IsValid(ply) and ply or player.GetAll()[1]
        if not IsValid(target) then return end
        
        for _, w in ipairs(Nexus.Proc.Weapons.List) do
            target:SetPData("nexus_weapon_unlocked_" .. w.class, "1")
        end
        if ARC9 and ARC9.Attachments then
            for att, _ in pairs(ARC9.Attachments) do
                target:SetPData("nexus_att_unlocked_" .. att, "1")
            end
        end
        
        target:ChatPrint("[Loadout] All weapons and attachments unlocked!")
        if Nexus.Proc.Weapons.SyncToClient then Nexus.Proc.Weapons.SyncToClient(target) end
    end)
end

-- ====================================================================
-- PRICING: Per-item dynamic coin costs for unlockable weapons / attachments.
-- These functions are shared (run on both server and client).
-- ====================================================================

-- Returns the coin cost to buy a weapon by class.
-- Returns 0 for default-unlocked (free) weapons.
function Nexus.Proc.Weapons:GetWeaponPrice(class)
    for _, w in ipairs(self.List) do
        if w.class == class then
            -- Explicitly priced weapons use their price; free/starter weapons have price = 0.
            -- Dynamically-discovered weapons (no price field) default to $1000.
            return w.price or 1000
        end
    end
    return 1000 -- fallback for any weapon not in the list at all
end

-- Deterministic string hash -> integer in [0, range)
local function strHash(str, range)
    local h = 0
    for i = 1, #str do
        h = (h * 31 + string.byte(str, i)) % 65536
    end
    return h % range
end

-- Category keyword -> {base, variance} price bracket
-- Each attachment gets: base + strHash(shortname, variance), rounded to nearest $25
local ATTACHMENT_PRICE_BRACKETS = {
    { pattern = "optic",              base = 700,  var = 800  },  -- $700–$1500
    { pattern = "barrel",             base = 550,  var = 700  },  -- $550–$1250
    { pattern = "muzzle",             base = 350,  var = 500  },  -- $350–$850
    { pattern = "stock",              base = 300,  var = 500  },  -- $300–$800
    { pattern = "ammo",               base = 400,  var = 600  },  -- $400–$1000
    { pattern = "under",              base = 400,  var = 500  },  -- $400–$900
    { pattern = "grip",               base = 250,  var = 400  },  -- $250–$650
    { pattern = "laser",              base = 200,  var = 350  },  -- $200–$550
    { pattern = "muzzlemelee",        base = 100,  var = 250  },  -- $100–$350 (cosmetic melee)
}

-- Returns the coin cost to buy an attachment by shortname.
-- Returns 0 for default/free attachments.
function Nexus.Proc.Weapons:GetAttachmentPrice(shortname)
    -- Free starter attachments cost nothing
    if self.DefaultAttachments[shortname] then return 0 end

    local lower = string.lower(shortname)

    for _, bracket in ipairs(ATTACHMENT_PRICE_BRACKETS) do
        if string.find(lower, bracket.pattern, 1, true) then
            local raw = bracket.base + strHash(shortname, bracket.var)
            return math.floor(raw / 25 + 0.5) * 25
        end
    end

    -- Generic fallback: $400–$900
    return math.floor((400 + strHash(shortname, 500)) / 25 + 0.5) * 25
end
