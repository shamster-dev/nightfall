-- cl_hud.lua
-- Custom client-side health HUD using heart materials and scissor rect chopping.

Nexus.Proc = Nexus.Proc or {}

-- Initialize Materials
local matHeartFilled   = Material("filled_heart.png")
local matHeartDamaged  = Material("heart_damaged.png")
local matHudBg         = Material("hp_background.png")
local matAmmoBg        = Material("mini_rectangle_background.png")
local matBulletIcon    = Material("bullet.png")

-- Initialize Fonts
local fontHealth = Nexus:GetFont({size = 30, bold = true})
local fontLabel  = Nexus:GetFont({size = 12})

-- Hide the default health, armor, and ammo HUD
local hide = {
    ["CHudHealth"] = true,
    ["CHudBattery"] = true,
    ["CHudAmmo"] = true,
    ["CHudSecondaryAmmo"] = true,
}

hook.Add("HUDShouldDraw", "NexusProcHideDefaultHUD", function(name)
    if hide[name] then
        return false
    end
end)

-- Draw the custom health HUD
hook.Add("HUDPaint", "NexusProcCustomHUD", function()
    local ply = LocalPlayer()
    if not IsValid(ply) or not ply:Alive() then return end

    -- Fetch stats
    local hp = math.max(0, ply:Health())
    local maxHp = math.max(1, ply:GetMaxHealth())
    local hpPct = math.Clamp(hp / maxHp, 0, 1)

    -- HUD sizing & position (bottom-left)
    local w = Nexus:GetScale(260)
    local h = Nexus:GetScale(90)
    local x = Nexus:GetScale(25)
    local y = ScrH() - h - Nexus:GetScale(25)

    -- Draw the background panel
    surface.SetMaterial(matHudBg)
    surface.SetDrawColor(0, 0, 0, 220)
    surface.DrawTexturedRect(x, y, w, h)

    -- Heart dimensions & placement (with dynamic heartbeat animation)
    local baseW = Nexus:GetScale(56)
    local baseH = Nexus:GetScale(56)
    
    -- Dynamically scale beat speed from 0.8 (resting at full HP) to 3.0 (panic at low HP)
    local beatSpeed = Lerp(hpPct, 3.0, 0.8)

    -- Create a sharp double-thump pulse pattern (lub-dub) followed by a rest
    local phase = (RealTime() * beatSpeed) % 1
    local pulse = 0
    if phase < 0.15 then
        -- Primary thump
        pulse = math.sin((phase / 0.15) * math.pi) * 0.15
    elseif phase >= 0.18 and phase < 0.33 then
        -- Secondary thump (smaller)
        pulse = math.sin(((phase - 0.18) / 0.15) * math.pi) * 0.06
    end
    
    local scaleFactor = 1 + pulse
    local heartW = baseW * scaleFactor
    local heartH = baseH * scaleFactor
    
    -- Center-anchored scaling
    local centerX = x + Nexus:GetScale(20) + baseW / 2
    local centerY = y + (h - baseH) / 2 + baseH / 2
    local heartX = centerX - heartW / 2
    local heartY = centerY - heartH / 2

    -- 1. Draw damaged heart (background shadow)
    surface.SetMaterial(matHeartDamaged)
    surface.SetDrawColor(255, 0, 255, 255)
    surface.DrawTexturedRect(heartX, heartY, heartW, heartH)

    -- 2. Draw filled heart chopped by height (health percentage) from bottom up
    local visibleHeight = heartH * hpPct
    local scissorY = heartY + (heartH - visibleHeight)

    render.SetScissorRect(heartX, scissorY, heartX + heartW, heartY + heartH, true)
    surface.SetMaterial(matHeartFilled)
    surface.SetDrawColor(255, 0, 255, 255)
    surface.DrawTexturedRect(heartX, heartY, heartW, heartH)
    render.SetScissorRect(0, 0, 0, 0, false)

    -- 3. Draw text info
    local colorPanel = Nexus:GetColor("background") or Color(20, 20, 20, 240)
    local colorText = Nexus:GetTextColor(colorPanel) or color_white

    local textX = x + Nexus:GetScale(20) + baseW + Nexus:GetScale(15)
    local textY = y + h / 2

    draw.SimpleText("VITALITY", fontLabel, textX, textY - Nexus:GetScale(15), colorText, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    draw.SimpleText(hp .. "%", fontHealth, textX, textY + Nexus:GetScale(10), color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end)

-- Draw the custom Ammo HUD
hook.Add("HUDPaint", "NexusProcCustomAmmoHUD", function()
    local ply = LocalPlayer()
    if not IsValid(ply) or not ply:Alive() then return end

    local activeWep = ply:GetActiveWeapon()
    if not IsValid(activeWep) then return end

    -- Only draw if the weapon actually uses ammo
    local primaryType = activeWep:GetPrimaryAmmoType()
    if primaryType == -1 then return end

    local clip = activeWep:Clip1()
    local maxClip = activeWep:GetMaxClip1()
    local reserve = ply:GetAmmoCount(primaryType)

    -- Hide if it's a weapon that has no clip and no reserve
    if clip == -1 and reserve == 0 then return end

    -- HUD sizing & position (bottom-right)
    local w = Nexus:GetScale(260)
    local h = Nexus:GetScale(90)
    local x = ScrW() - w - Nexus:GetScale(25)
    local y = ScrH() - h - Nexus:GetScale(25)

    -- Draw the background panel
    surface.SetMaterial(matAmmoBg)
    surface.SetDrawColor(0, 0, 0, 220)
    surface.DrawTexturedRect(x, y, w, h)

    -- Font configuration
    local fontAmmo = Nexus:GetFont({size = 30, bold = true})
    local fontReserve = Nexus:GetFont({size = 18, bold = true})
    local fontWepName = Nexus:GetFont({size = 14, bold = true})

    local colorPanel = Nexus:GetColor("background") or Color(20, 20, 20, 240)
    local colorText = Nexus:GetTextColor(colorPanel) or color_white

    -- Draw text details
    local infoX = x + Nexus:GetScale(25)
    local textY = y + h / 2

    local wepName = string.upper(activeWep:GetPrintName() or activeWep:GetClass() or "WEAPON")
    draw.SimpleText(wepName, fontWepName, infoX, textY - Nexus:GetScale(15), colorText, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

    -- Format ammo string
    if clip >= 0 then
        local ammoText = tostring(clip)
        local reserveText = " / " .. tostring(reserve)
        
        surface.SetFont(fontAmmo)
        local tw1, th1 = surface.GetTextSize(ammoText)
        
        draw.SimpleText(ammoText, fontAmmo, infoX, textY + Nexus:GetScale(10), color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        draw.SimpleText(reserveText, fontReserve, infoX + tw1, textY + Nexus:GetScale(10), Color(160, 160, 160), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    else
        draw.SimpleText(tostring(reserve), fontAmmo, infoX, textY + Nexus:GetScale(10), color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    -- Draw high-tech ammo bars (bullet stack on the right side)
    local maxBars = math.min(maxClip, 30)
    if maxBars <= 0 then maxBars = 10 end

    local rowMax = 10
    local barW = Nexus:GetScale(5)
    local barH = Nexus:GetScale(20)
    local spacingX = Nexus:GetScale(3)
    local spacingY = Nexus:GetScale(3)

    -- Centering math for remaining space (to the right of weapon name/digits)
    local leftBound = x + Nexus:GetScale(125)
    local rightBound = x + w - Nexus:GetScale(25)
    local wContainer = rowMax * (barW + spacingX) - spacingX
    local barContainerX = leftBound + (rightBound - leftBound - wContainer) / 2

    -- Centering math for vertical space
    local totalRows = math.ceil(maxBars / rowMax)
    local barContainerY = y + h / 2 - barH / 2 + (totalRows - 1) * (barH + spacingY) / 2

    local function DrawRotatedBullet(bx, by, bw, bh, angle, col)
        local m = Matrix()
        m:Translate(Vector(bx, by, 0))
        m:Rotate(Angle(0, angle, 0))
        m:Scale(Vector(1, 1, 1))
        
        cam.PushModelMatrix(m)
            surface.SetMaterial(matBulletIcon)
            surface.SetDrawColor(col.r, col.g, col.b, col.a)
            surface.DrawTexturedRect(-bw/2, -bh/2, bw, bh)
        cam.PopModelMatrix()
    end

    -- Particle lists and tracker initialization
    local plyID = ply:SteamID64() or "bot"
    AmmoHUDParticles = AmmoHUDParticles or {}
    AmmoHUDParticles[plyID] = AmmoHUDParticles[plyID] or {}
    AmmoHUDLastClip = AmmoHUDLastClip or {}
    AmmoHUDLastWep = AmmoHUDLastWep or {}
    AmmoHUDLastTime = AmmoHUDLastTime or RealTime()

    local dt = math.Clamp(RealTime() - AmmoHUDLastTime, 0, 0.1)
    AmmoHUDLastTime = RealTime()

    local wepClass = activeWep:GetClass()
    if wepClass ~= AmmoHUDLastWep[plyID] then
        AmmoHUDLastClip[plyID] = clip
        AmmoHUDLastWep[plyID] = wepClass
    end
    if AmmoHUDLastClip[plyID] == nil then
        AmmoHUDLastClip[plyID] = clip
    end

    -- Determine how full the clip is
    local pct = 1
    if maxClip > 0 then
        pct = math.Clamp(clip / maxClip, 0, 1)
    end

    local activeBars = clip
    if maxClip > 30 then
        activeBars = math.ceil(pct * maxBars)
    end

    local barColor = Nexus:GetColor("red") or Color(220, 50, 50)
    if pct > 0.4 then
        barColor = Color(240, 240, 240)
    elseif pct > 0.15 then
        barColor = Color(240, 180, 50)
    end

    -- If bullets were consumed, spawn falling shells from their grid slot
    local oldClip = AmmoHUDLastClip[plyID]
    local oldActive = oldClip
    local newActive = clip
    if maxClip > 30 then
        local oldPct = oldClip / maxClip
        local newPct = clip / maxClip
        oldActive = math.ceil(oldPct * maxBars)
        newActive = math.ceil(newPct * maxBars)
    end

    oldActive = math.min(oldActive, maxBars)
    newActive = math.min(newActive, maxBars)

    if newActive < oldActive and newActive >= 0 and oldActive >= 0 and maxClip > 0 then
        for i = newActive + 1, oldActive do
            local row = math.ceil(i / rowMax)
            local col = (i - 1) % rowMax + 1
            local bx = barContainerX + (col - 1) * (barW + spacingX)
            local by = barContainerY - (row - 1) * (barH + spacingY)
            
            table.insert(AmmoHUDParticles[plyID], {
                x = bx + barW / 2,
                y = by + barH / 2,
                velX = math.random(-60, 60),
                velY = math.random(-180, -90),
                angle = 0,
                angVel = math.random(-360, 360),
                alpha = 255,
                color = barColor
            })
        end
    end
    AmmoHUDLastClip[plyID] = clip

    -- Draw bullet icons grid
    surface.SetMaterial(matBulletIcon)
    for i = 1, maxBars do
        local row = math.ceil(i / rowMax)
        local col = (i - 1) % rowMax + 1
        local bx = barContainerX + (col - 1) * (barW + spacingX)
        local by = barContainerY - (row - 1) * (barH + spacingY)
        
        if i <= activeBars then
            surface.SetDrawColor(barColor.r, barColor.g, barColor.b, 255)
        else
            surface.SetDrawColor(40, 40, 45, 100)
        end
        surface.DrawTexturedRect(bx, by, barW, barH)
    end

    -- Update and draw particles
    local activeParticles = AmmoHUDParticles[plyID]
    for i = #activeParticles, 1, -1 do
        local p = activeParticles[i]
        p.x = p.x + p.velX * dt
        p.y = p.y + p.velY * dt
        p.velY = p.velY + 500 * dt -- gravity
        p.angle = p.angle + p.angVel * dt
        p.alpha = p.alpha - 450 * dt

        if p.alpha <= 0 or p.y > ScrH() then
            table.remove(activeParticles, i)
        else
            local col = Color(p.color.r, p.color.g, p.color.b, p.alpha)
            DrawRotatedBullet(p.x, p.y, barW, barH, p.angle, col)
        end
    end
end)
