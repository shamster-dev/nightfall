-- cl_customizer.lua
-- Fullscreen character customizer panel class for the Nexus load-in menu.

local PANEL = {}

local PREFS_FILE = "nexus_proc/customizer_prefs.json"

local function loadPrefs()
    if file.Exists(PREFS_FILE, "DATA") then
        local data = file.Read(PREFS_FILE, "DATA")
        return util.JSONToTable(data) or {}
    end
    return {}
end

local function savePrefs(model, bodygroups)
    if not file.Exists("nexus_proc", "DATA") then
        file.CreateDir("nexus_proc")
    end
    local tbl = {
        model = model,
        bodygroups = bodygroups
    }
    file.Write(PREFS_FILE, util.TableToJSON(tbl))
end

local function hideCursorRecursive(pnl)
    if not IsValid(pnl) then return end
    pnl:SetCursor("blank")
    for _, child in ipairs(pnl:GetChildren()) do
        hideCursorRecursive(child)
    end
end

function PANEL:Init()
    self:SetSize(ScrW(), ScrH())
    self:SetPos(0, 0)
    
    -- Hidden system cursor
    self:SetCursor("blank")

    -- Left panel: Holds the massive 3D model preview (60% width)
    local leftPanel = self:Add("DPanel")
    leftPanel:Dock(LEFT)
    leftPanel:SetWide(ScrW() * 0.6)
    leftPanel.Paint = nil

    local prefs = loadPrefs()
    local savedModel = prefs.model
    local savedBgs = prefs.bodygroups or {}

    local models = {
        ["Assault"] = "models/styrofoam/bf4/us_assaultpm.mdl",
        ["Engineer"] = "models/styrofoam/bf4/us_engineerpm.mdl",
        ["Recon"] = "models/styrofoam/bf4/us_reconpm.mdl",
        ["Support"] = "models/styrofoam/bf4/us_supportpm.mdl",
    }
    self.SelectedModel = models["Assault"]
    local defaultName = "Assault"

    if savedModel then
        for name, path in pairs(models) do
            if path == savedModel then
                self.SelectedModel = savedModel
                defaultName = name
                break
            end
        end
    end

    -- 3D Model Panel Preview
    local modelPanel = leftPanel:Add("DModelPanel")
    modelPanel:Dock(FILL)
    modelPanel:DockMargin(Nexus:GetScale(50), Nexus:GetScale(50), Nexus:GetScale(50), Nexus:GetScale(50))
    modelPanel:SetModel(self.SelectedModel)
    modelPanel:SetFOV(22)
    modelPanel:SetCamPos(Vector(85, 0, 42))
    modelPanel:SetLookAt(Vector(0, 0, 36))
    modelPanel.LayoutEntity = function(s, ent)
        ent:SetSequence(ent:LookupSequence("idle_all_01") or 0)
        s:RunAnimation()
        ent:SetAngles(Angle(0, RealTime() * 12 % 360, 0))
    end
        if IsValid(modelPanel.Entity) then
            local mn, mx = modelPanel.Entity:GetRenderBounds()
            local size = 0
            size = math.max( size, math.abs(mn.x) + math.abs(mx.x) )
            size = math.max( size, math.abs(mn.y) + math.abs(mx.y) )
            size = math.max( size, math.abs(mn.z) + math.abs(mx.z) )

            modelPanel:SetFOV( 45 )
            modelPanel:SetCamPos( Vector( size, size, size ) )
            modelPanel:SetLookAt( (mn + mx) * 0.5 )
        end

    self.ModelPanel = modelPanel

    -- Right panel: Holds the customization sidebar (remaining width)
    local rightPanel = self:Add("DPanel")
    rightPanel:Dock(FILL)
    rightPanel.Paint = function(s, w, h)
        local sidebarCol = Color(6, 6, 8, 220)
        Nexus.RNDX.Draw(0, 0, 0, w, h, sidebarCol, nil, true)
        
        local highlight = Nexus:GetColor("accent")
        if highlight then
            Nexus.RNDX.Draw(0, 0, 0, Nexus:GetScale(4), h, highlight)
        end
    end

    local title = rightPanel:Add("DLabel")
    title:SetFont(Nexus:GetFont({size = 26, bold = true}))
    title:SetText("SURVIVOR CUSTOMIZATION")
    title:SetTextColor(Nexus:GetTextColor(Nexus:GetColor("background")))
    title:SetContentAlignment(5)
    title:Dock(TOP)
    title:DockMargin(0, Nexus:GetScale(40), 0, Nexus:GetScale(25))
    title:SizeToContents()

    -- Actual play button at bottom of customizer
    local enterBtnMat = Material("button_mat.png")
    local enterBtnFont = Nexus:GetFont({size = 20, font="Horror Font"}) or Nexus:GetFont({size = 16, bold = true})

    local enterBtn = rightPanel:Add("Nexus:V2:Button")
    enterBtn:SetText("")
    enterBtn:SetTall(Nexus:GetScale(70))
    enterBtn:Dock(BOTTOM)
    enterBtn:DockMargin(Nexus:GetScale(40), Nexus:GetScale(15), Nexus:GetScale(40), Nexus:GetScale(40))
    enterBtn:SetCursor("blank")
    enterBtn.Paint = function(s, w, h)
        surface.SetDrawColor(255, 255, 255, s:IsHovered() and 255 or 150)
        surface.SetMaterial(enterBtnMat)
        surface.DrawTexturedRect(0, 0, w, h)

        draw.SimpleText("ENTER THE NIGHTMARE", enterBtnFont, w/2, h/2, Nexus:GetTextColor(Nexus:GetColor("background")), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    enterBtn.DoClick = function()
        enterBtn:SetEnabled(false)
        surface.PlaySound("ambient/energy/zap1.wav")
        
        -- Send play command immediately so player spawns while menu is still fading
        net.Start("Nexus:Loadin:Play")
        net.WriteString(self.SelectedModel or "models/styrofoam/bf4/us_assaultpm.mdl")
        
        local bgTable = {}
        if IsValid(self.ModelPanel) and IsValid(self.ModelPanel.Entity) then
            for _, bg in ipairs(self.ModelPanel.Entity:GetBodyGroups()) do
                bgTable[bg.id] = self.ModelPanel.Entity:GetBodygroup(bg.id)
            end
        end
        net.WriteTable(bgTable)
        net.WriteTable(Nexus.Proc.GetSavedLoadout and Nexus.Proc.GetSavedLoadout() or {})
        net.SendToServer()
        
        -- Save preferences locally
        savePrefs(self.SelectedModel, bgTable)
        
        -- Remove the main menu parent panel
        local parentMenu = self:GetParent()
        if IsValid(parentMenu) then
            parentMenu:AlphaTo(0, 2, 0, function()
                if IsValid(parentMenu) then
                    parentMenu:Remove()
                end
            end)
        end
    end

    -- ScrollPanel for sliders
    local bgScroll = rightPanel:Add("Nexus:V2:ScrollPanel")
    bgScroll:Dock(FILL)
    bgScroll:DockMargin(Nexus:GetScale(40), 0, Nexus:GetScale(40), Nexus:GetMargin())



    local function RebuildBodygroups(ent)
        bgScroll:Clear()

        if IsValid(modelPanel.Entity) then
            local mn, mx = modelPanel.Entity:GetRenderBounds()
            local size = 0
            size = math.max( size, math.abs(mn.x) + math.abs(mx.x) )
            size = math.max( size, math.abs(mn.y) + math.abs(mx.y) )
            size = math.max( size, math.abs(mn.z) + math.abs(mx.z) )

            modelPanel:SetFOV( 45 )
            modelPanel:SetCamPos( Vector( size, size, size ) )
            modelPanel:SetLookAt( (mn + mx) * 0.5 )
        end

        if not IsValid(ent) then return end
        
        for _, bg in ipairs(ent:GetBodyGroups()) do
            if bg.num > 1 then
                local sliderContainer = bgScroll:Add("DPanel")
                sliderContainer:Dock(TOP)
                sliderContainer:DockMargin(0, 0, 0, Nexus:GetScale(15))
                sliderContainer:SetTall(Nexus:GetScale(55))
                sliderContainer.Paint = nil
                
                local label = sliderContainer:Add("DLabel")
                label:SetFont(Nexus:GetFont({size = 13}))
                label:SetText(string.upper(bg.name))
                label:SetTextColor(Color(160, 160, 160))
                label:Dock(TOP)
                
                local slider = sliderContainer:Add("Nexus:V2:NumSlider")
                slider:Dock(FILL)
                slider:SetMinMax(0, bg.num - 1)
                slider:SetValue(ent:GetBodygroup(bg.id))
                slider.OnChange = function(s, value)
                    if IsValid(ent) then
                        ent:SetBodygroup(bg.id, math.Round(value))
                    end
                end
                hideCursorRecursive(sliderContainer)
            end
        end
    end

    -- Model Selector ComboBox
    local selector = rightPanel:Add("Nexus:V2:ComboBox")
    selector:Dock(TOP)
    selector:DockMargin(Nexus:GetScale(40), 0, Nexus:GetScale(40), Nexus:GetMargin())
    selector:SetValue(defaultName)
    selector:SetFont(Nexus:GetFont({size = 15}))
    for name, path in pairs(models) do
        selector:AddChoice(name, function()
            self.SelectedModel = path
            if IsValid(self.ModelPanel) then
                self.ModelPanel:SetModel(path)
                -- Delay bodygroup build slightly so GMod can finish loading the new model entity
                timer.Simple(0.05, function()
                    if IsValid(self.ModelPanel) and IsValid(self.ModelPanel.Entity) then
                        RebuildBodygroups(self.ModelPanel.Entity)
                    end
                end)
            end
        end)
    end
    self.Selector = selector

    -- Initial load of bodygroups
    timer.Simple(0.1, function()
        if IsValid(self.ModelPanel) and IsValid(self.ModelPanel.Entity) then
            if savedBgs then
                for id, val in pairs(savedBgs) do
                    self.ModelPanel.Entity:SetBodygroup(tonumber(id), tonumber(val))
                end
            end
            RebuildBodygroups(self.ModelPanel.Entity)
        end
    end)

    -- Floating back button in the top left
    local backBtnMat = Material("small-404-316.png")
    local backBtn = self:Add("Nexus:V2:Button")
    backBtn:SetText("BACK")
    backBtn:SetFont(Nexus:GetFont({size = 18, bold = true}))
    backBtn:SetSize(Nexus:GetScale(70), Nexus:GetScale(55))
    backBtn:SetPos(Nexus:GetScale(20), Nexus:GetScale(20))
    backBtn:SetCursor("blank")
    backBtn.Paint = function(s, w, h)
        surface.SetDrawColor(255, 255, 255, s:IsHovered() and 95 or 50)
        surface.SetMaterial(backBtnMat)
        surface.DrawTexturedRect(0, 0, w, h)

        draw.SimpleText(s:GetText(), s:GetFont(), w/2, h/2, Nexus:GetTextColor(color_white), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    backBtn.DoClick = function()
        local parent = self:GetParent()
        if IsValid(parent) then
            parent.Customizing = false
            if IsValid(parent.PlayBtn) then
                parent.PlayBtn:SetVisible(true)
                parent.PlayBtn:AlphaTo(255, 0.4)
                parent.PlayBtn:SetEnabled(true)
            end
            if IsValid(parent.LeaveBtn) then
                parent.LeaveBtn:SetVisible(true)
                parent.LeaveBtn:AlphaTo(255, 0.4)
                parent.LeaveBtn:SetEnabled(true)
            end
        end
        self:AlphaTo(0, 0.4, 0, function()
            if IsValid(self) then self:Remove() end
        end)
    end

    -- Ensure all customizer elements hide the system hardware cursor
    hideCursorRecursive(self)
end

function PANEL:Paint(w, h)
    -- Round Information widget at the top-center
    local ROUND_WAITING = 0
    local ROUND_PREP    = 1
    local ROUND_ACTIVE  = 2
    local ROUND_VICTORY = 3
    local ROUND_DEFEAT  = 4

    local state = GetGlobalInt("NightFall:RoundState", ROUND_WAITING)
    local timeEnd = GetGlobalFloat("NightFall:Round:EndCurTime", 0)
    local timeLeft = math.max(0, timeEnd - CurTime())

    local stateText = "WAITING FOR PLAYERS"
    local stateColor = Color(180, 180, 180)
    local drawTimer = false

    if state == ROUND_PREP then
        stateText = "PREPARATION PHASE"
        stateColor = Color(200, 180, 50)
        drawTimer = true
    elseif state == ROUND_ACTIVE then
        stateText = "ROUND ACTIVE"
        stateColor = Color(220, 50, 50)
        drawTimer = true
    elseif state == ROUND_VICTORY or state == ROUND_DEFEAT then
        local won = NexusRoundStats and NexusRoundStats.won or (state == ROUND_VICTORY)
        if won then
            stateText = "VICTORY"
            stateColor = Color(50, 220, 50)
        else
            stateText = "DEFEATED"
            stateColor = Color(220, 50, 50)
        end
    end

    local widgetW, widgetH = Nexus:GetScale(320), Nexus:GetScale(60)
    local leftW = w * 0.6
    local widgetX, widgetY = leftW/2 - widgetW/2, Nexus:GetScale(40)

    -- Background Panel
    local hudBgMat = Material("hud_background.png")
    surface.SetDrawColor(255, 255, 255, 50)
    surface.SetMaterial(hudBgMat)
    surface.DrawTexturedRect(widgetX, widgetY, widgetW, widgetH)
    
    -- Text positioning
    local textX = widgetX + widgetW / 2
    local labelFont = Nexus:GetFont({size = 14, bold = true})
    local valFont = Nexus:GetFont({size = 18, bold = true})

    if drawTimer then
        local mins = math.floor(timeLeft / 60)
        local secs = math.floor(timeLeft % 60)
        local timerText = string.format("%02d:%02d", mins, secs)

        draw.SimpleText(stateText, labelFont, textX, widgetY + Nexus:GetScale(12), Nexus:GetTextColor(Nexus:GetColor("red")), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        draw.SimpleText(timerText, valFont, textX, widgetY + Nexus:GetScale(28), stateColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    else
        draw.SimpleText(stateText, valFont, textX, widgetY + widgetH / 2, stateColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
end

function PANEL:Think()
    -- Dynamically hide the system cursor and draw the custom hand cursor on the active ComboBox popup/dropdown menu if it exists
    if IsValid(self.Selector) and IsValid(self.Selector._DermaMenu) then
        local menu = self.Selector._DermaMenu
        if not menu.CursorSetToBlank then
            menu.CursorSetToBlank = true
            hideCursorRecursive(menu)
            
            -- Draw the custom hand cursor on top of the popup menu
            local cursorMat = Material("hand.png")
            menu.PaintOver = function(s, w, h)
                local mx, my = gui.MousePos()
                local x, y = s:ScreenToLocal(mx, my)
                local handSize = Nexus:GetScale(32)
                
                surface.SetDrawColor(255, 255, 255, 255)
                surface.SetMaterial(cursorMat)
                surface.DrawTexturedRect(x - handSize * 0.5, y - handSize * 0.5, handSize, handSize)
            end
        end
    end
end

vgui.Register("Nexus:Proc:Customizer", PANEL, "EditablePanel")
