-- sv_loadin.lua
-- Server-side loading and network hooks for the Nexus load-in menu.

util.AddNetworkString("Nexus:Loadin:OpenMenu")
util.AddNetworkString("Nexus:Loadin:Play")
util.AddNetworkString("Nexus:Loadin:SyncUnlocks")
util.AddNetworkString("Nexus:Loadin:SendLoadout")

-- Persist loadout to PData as JSON
local function SaveLoadoutToPData(ply, loadout)
    ply:SetPData("nexus_loadout", util.TableToJSON(loadout))
end

-- Restore loadout from PData; returns nil if none saved
local function LoadLoadoutFromPData(ply)
    local raw = ply:GetPData("nexus_loadout", "")
    if raw == "" then return nil end
    return util.JSONToTable(raw)
end

-- Sends the client their current unlock state from PData
Nexus.Proc.Weapons.SyncToClient = function(ply)
    local unlocks = { weapons = {}, attachments = {} }

    for _, w in ipairs(Nexus.Proc.Weapons.List) do
        if Nexus.Proc.Weapons:IsWeaponUnlocked(ply, w.class) then
            unlocks.weapons[w.class] = true
        end
    end

    -- Sync all known ARC9 attachment unlocks
    if ARC9 and ARC9.Attachments then
        for attShortName, _ in pairs(ARC9.Attachments) do
            if Nexus.Proc.Weapons:IsAttachmentUnlocked(ply, attShortName) then
                unlocks.attachments[attShortName] = true
            end
        end
    end

    local coins = (ply.StatsAggregated and ply.StatsAggregated.coins) or 0

    net.Start("Nexus:Loadin:SyncUnlocks")
    net.WriteTable(unlocks)
    net.WriteInt(coins, 32)
    net.Send(ply)
end

-- Far-away silent void position -- player is placed here so no map audio is audible
local SILENT_POS = Vector(10298.068359,  4585.605469, 6756.770020)

hook.Add("Nexus:FullyLoaded", "NexusProcPlayerInitialSpawnSpectate", function(ply)
    ply:StripWeapons()
    ply:Spectate(OBS_MODE_ROAMING)
    ply:SetTeam(TEAM_SPECTATOR)

    -- Teleport the player to the silent void position deferred by a brief timer
    -- to ensure the spawn sequence has finished and they cannot hear other players.
    timer.Simple(0.1, function()
        if IsValid(ply) then
            ply:SetPos(SILENT_POS)
        end
    end)

    -- Send menu open trigger to the joining client
    net.Start("Nexus:Loadin:OpenMenu")
    net.Send(ply)

    -- Restore saved loadout from PData and send it to the client
    local saved = LoadLoadoutFromPData(ply)
    if saved then
        ply.NexusLoadout = saved
        net.Start("Nexus:Loadin:SendLoadout")
        net.WriteTable(saved)
        net.Send(ply)
    end

    -- Sync this player's unlock state to the client
    Nexus.Proc.Weapons.SyncToClient(ply)
end)

hook.Add("PlayerSpawn", "NexusProc:SilentSpawn", function(ply)
    -- Only teleport players to the void if they are in the spectator/menu state
    if ply:Team() ~= TEAM_SPECTATOR then return end

    -- Defer the position set by one frame to allow the engine to finish spawning
    timer.Simple(0, function()
        if IsValid(ply) then
            ply:SetPos(SILENT_POS)
        end
    end)
end)

net.Receive("Nexus:Loadin:Play", function(len, ply)
    if not IsValid(ply) then return end
    if ply:Team() ~= TEAM_SPECTATOR then return end

    local modelPath = net.ReadString()
    local bodygroups = net.ReadTable()

    local state = GetGlobalInt("NightFall:RoundState", 0)

    if state == ROUND_ACTIVE then
        -- Mid-game join: keep them spectating until the next round preparation phase
        ply.IsReady = nil
        
        -- Find a default target player to spectate immediately
        local target = nil
        for _, p in ipairs(player.GetAll()) do
            if IsValid(p) and p ~= ply and p:Alive() and p:Team() ~= TEAM_SPECTATOR then
                target = p
                break
            end
        end

        if IsValid(target) then
            ply:Spectate(OBS_MODE_CHASE)
            ply:SpectateEntity(target)
            ply.NexusSpectateTarget = target
        else
            ply:Spectate(OBS_MODE_ROAMING)
            timer.Simple(0, function()
                if IsValid(ply) then ply:SetPos(SILENT_POS) end
            end)
        end
        
        net.Start("NightFall:Rounds:CloseMenu")
        net.Send(ply)
    else
        -- Pre-game or prep phase: spawn them immediately to move around
        ply.IsReady = true
        ply.SelectedModel = modelPath
        ply.SelectedBodygroups = bodygroups

        ply:UnSpectate()
        ply:SetTeam(TEAM_UNASSIGNED)
        ply:Spawn()
        net.Start("NightFall:Rounds:CloseMenu")
        net.Send(ply)
    end
end)

-- Apply the customizer settings when player sets their model
hook.Add("PlayerSetModel", "NexusProc:CustomizerModel", function(ply)
    if ply.SelectedModel then
        ply:SetModel(ply.SelectedModel)
        
        if ply.SelectedBodygroups then
            for id, val in pairs(ply.SelectedBodygroups) do
                ply:SetBodygroup(tonumber(id), tonumber(val))
            end
        end
        return true -- Override default sandboxed model sets
    end
end)

util.AddNetworkString("Nexus:Loadin:UpdateLoadout")
util.AddNetworkString("Nexus:Loadin:BuyWeapon")
util.AddNetworkString("Nexus:Loadin:BuyAttachment")

net.Receive("Nexus:Loadin:BuyWeapon", function(len, ply)
    if not IsValid(ply) or not ply.StatsAggregated then return end
    local class = net.ReadString()
    if not class or class == "" then return end

    if Nexus.Proc.Weapons:IsWeaponUnlocked(ply, class) then
        ply:ChatPrint("[Shop] Weapon already unlocked!")
        return
    end

    local cost = Nexus.Proc.Weapons:GetWeaponPrice(class)
    local stats = ply.StatsAggregated
    if (stats.coins or 0) < cost then
        ply:ChatPrint("[Shop] Not enough coins! Need $" .. cost)
        return
    end

    stats.coins = stats.coins - cost
    ply:SetPData("nexus_weapon_unlocked_" .. class, "1")
    Nexus.Proc.SavePlayerStats(ply)
    Nexus.Proc.Weapons.SyncToClient(ply)
    ply:EmitSound("items/ammo_pickup.wav", 60, 100)
    ply:ChatPrint("[Shop] Successfully purchased " .. class .. " for $" .. cost)
end)

net.Receive("Nexus:Loadin:BuyAttachment", function(len, ply)
    if not IsValid(ply) or not ply.StatsAggregated then return end
    local att = net.ReadString()
    if not att or att == "" then return end

    if Nexus.Proc.Weapons:IsAttachmentUnlocked(ply, att) then
        ply:ChatPrint("[Shop] Attachment already unlocked!")
        return
    end

    local cost = Nexus.Proc.Weapons:GetAttachmentPrice(att)
    local stats = ply.StatsAggregated
    if (stats.coins or 0) < cost then
        ply:ChatPrint("[Shop] Not enough coins! Need $" .. cost)
        return
    end

    stats.coins = stats.coins - cost
    ply:SetPData("nexus_att_unlocked_" .. att, "1")
    Nexus.Proc.SavePlayerStats(ply)
    Nexus.Proc.Weapons.SyncToClient(ply)
    ply:EmitSound("items/ammo_pickup.wav", 60, 100)
    ply:ChatPrint("[Shop] Successfully purchased " .. att .. " for $" .. cost)
end)

net.Receive("Nexus:Loadin:UpdateLoadout", function(len, ply)
    if not IsValid(ply) then return end
    local loadout = net.ReadTable()

    -- Server-side validation: strip any weapons/attachments the player doesn't own
    local primary = loadout.primary
    local secondary = loadout.secondary

    if primary and primary ~= "none" and not Nexus.Proc.Weapons:IsWeaponUnlocked(ply, primary) then
        print("[Nexus Loadout] Blocked unauthorized weapon equip: " .. tostring(primary) .. " by " .. ply:Nick())
        loadout.primary = "none"
    end
    if secondary and secondary ~= "none" and not Nexus.Proc.Weapons:IsWeaponUnlocked(ply, secondary) then
        print("[Nexus Loadout] Blocked unauthorized weapon equip: " .. tostring(secondary) .. " by " .. ply:Nick())
        loadout.secondary = "none"
    end

    if loadout.attachments then
        for wepClass, slots in pairs(loadout.attachments) do
            for slotStr, att in pairs(slots) do
                if att and att ~= "" and not Nexus.Proc.Weapons:IsAttachmentUnlocked(ply, att) then
                    print("[Nexus Loadout] Blocked unauthorized attachment: " .. tostring(att) .. " by " .. ply:Nick())
                    loadout.attachments[wepClass][slotStr] = nil
                end
            end
        end
    end

    ply.NexusLoadout = loadout
    -- Persist the validated loadout to PData so it survives reconnects
    SaveLoadoutToPData(ply, loadout)

    -- Apply attachments to the player's currently held weapons live
    -- so they don't need to respawn to see changes take effect
    timer.Simple(0, function()
        if not IsValid(ply) then return end
        for _, wep in ipairs(ply:GetWeapons()) do
            if not IsValid(wep) then continue end
            local class = wep:GetClass()
            local atts = loadout.attachments and loadout.attachments[class]
            if not atts then continue end

            wep.CanAttach = function() return true end
            wep.CanDetach = function() return true end

            -- Detach all existing attachments first
            if wep.Attachments then
                for i, slot in ipairs(wep.Attachments) do
                    if slot.Installed then
                        wep:Attach(i, nil, true)
                    end
                end
            end

            -- Re-apply validated attachments
            for slotStr, att in pairs(atts) do
                local slotIdx = tonumber(slotStr)
                if slotIdx and att and att ~= "" then
                    if Nexus.Proc.Weapons:IsAttachmentUnlocked(ply, att) then
                        wep:Attach(slotIdx, att, true)
                    end
                end
            end

            if wep.SendWeapon then wep:SendWeapon() end
        end
    end)

    -- Re-give weapons live if the primary/secondary selection has changed
    timer.Simple(0.1, function()
        if not IsValid(ply) or not ply:Alive() or ply:Team() == TEAM_SPECTATOR then return end

        -- Determine what weapon classes the player currently holds by category
        local currentPrimary, currentSecondary
        for _, wep in ipairs(ply:GetWeapons()) do
            if not IsValid(wep) then continue end
            local wepClass = wep:GetClass()
            local wepDef
            for _, w in ipairs(Nexus.Proc.Weapons.List or {}) do
                if w.class == wepClass then wepDef = w break end
            end
            if not wepDef then continue end
            if wepDef.category == "Primary" then currentPrimary = wep:GetClass()
            elseif wepDef.category == "Secondary" then currentSecondary = wep:GetClass() end
        end

        local newPrimary   = (loadout.primary   and loadout.primary   ~= "none") and loadout.primary   or nil
        local newSecondary = (loadout.secondary  and loadout.secondary ~= "none") and loadout.secondary or nil

        -- Only re-give if the selection actually changed
        if newPrimary == currentPrimary and newSecondary == currentSecondary then return end

        ply:StripWeapons()

        local function giveWeaponWithAtts(wepClass)
            if not wepClass then return end
            local wep = ply:Give(wepClass)
            if not IsValid(wep) then return end
            local atts = loadout.attachments and loadout.attachments[wepClass]
            if not atts then return end
            wep.CanAttach = function() return true end
            wep.CanDetach = function() return true end
            for slotStr, att in pairs(atts) do
                local slotIdx = tonumber(slotStr)
                if slotIdx and att and att ~= "" and Nexus.Proc.Weapons:IsAttachmentUnlocked(ply, att) then
                    wep:Attach(slotIdx, att, true)
                end
            end
            if wep.SendWeapon then wep:SendWeapon() end
        end

        giveWeaponWithAtts(newPrimary)
        giveWeaponWithAtts(newSecondary)

        -- Re-grant ammo pools
        ply:GiveAmmo(180, "Ar2")
        ply:GiveAmmo(180, "SMG1")
        ply:GiveAmmo(120, "Pistol")
        ply:GiveAmmo(180, "buckshot")
        ply:GiveAmmo(120, "357")
        ply:GiveAmmo(30, "slam")
        ply:GiveAmmo(30, "RPG_Round")
        ply:GiveAmmo(60, "grenade")
    end)
end)

hook.Add("PlayerLoadout", "NexusProc:PlayerLoadout", function(ply)
    if ply:Team() == TEAM_SPECTATOR then return true end

    ply:StripWeapons()

    local defaultLoadout = {
        primary = "arc9_cod2019_ar_m4",
        secondary = "arc9_cod2019_pi_x16",
        attachments = {
            ["arc9_cod2019_ar_m4"] = {
                ["1"] = "cod2019_attach_muzzlemelee01",
                ["2"] = "cod2019_m4a1_barrel_short",
                ["4"] = "cod2019_optic_reflex_west"
            }
        }
    }
    local loadout = ply.NexusLoadout or defaultLoadout

    local primary = loadout.primary or "arc9_cod2019_ar_m4"
    local secondary = loadout.secondary or "arc9_cod2019_pi_x16"

    -- Helper to give weapon and apply attachments
    local function giveWeaponWithAtts(class)
        if not class or class == "" or class == "none" then return end
        
        -- Make sure weapon class is unlocked
        if not Nexus.Proc.Weapons:IsWeaponUnlocked(ply, class) then
            -- Fallback to default
            if class == primary then
                class = "arc9_cod2019_ar_m4"
            else
                class = "arc9_cod2019_pi_x16"
            end
        end

        local wep = ply:Give(class)
        if IsValid(wep) then
            wep.CanAttach = function() return true end
            wep.CanDetach = function() return true end
            local atts = loadout.attachments and loadout.attachments[class]
            if atts then
                -- Defer attaching slightly to let the engine finish spawning the weapon
                timer.Simple(0, function()
                    if IsValid(wep) and IsValid(ply) and wep:GetOwner() == ply then
                        for slotStr, att in pairs(atts) do
                            local slotIdx = tonumber(slotStr)
                            if slotIdx and att and att ~= "" then
                                -- Check if attachment is unlocked
                                if Nexus.Proc.Weapons:IsAttachmentUnlocked(ply, att) then
                                    wep:Attach(slotIdx, att, true)
                                end
                            end
                        end
                        if wep.SendWeapon then
                            wep:SendWeapon()
                        end
                    end
                end)
            end
        end
    end

    giveWeaponWithAtts(primary)
    giveWeaponWithAtts(secondary)

    -- Give plenty of ammo for standard ARC9 modern warfare types
    ply:GiveAmmo(180, "Ar2")
    ply:GiveAmmo(180, "Pistol")
    ply:GiveAmmo(150, "SMG1")
    ply:GiveAmmo(32, "Buckshot")
    ply:GiveAmmo(24, "357")
    ply:GiveAmmo(15, "SniperPenetratedRound")

    return true
end)