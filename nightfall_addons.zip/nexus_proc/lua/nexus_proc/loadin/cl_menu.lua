local blur = Material("pp/blurscreen")
local buttonMat = Material("button_mat.png")
local cursorMat = Material("hand.png")
local function DrawBlur(panel, amount)
    local x, y = panel:LocalToScreen(0, 0)
    local scrW, scrH = ScrW(), ScrH()
    surface.SetDrawColor(255, 255, 255)
    surface.SetMaterial(blur)
    for i = 1, 3 do
        blur:SetFloat("$blur", (i / 3) * (amount or 6))
        blur:Recompute()
        render.UpdateScreenEffectTexture()
        surface.DrawTexturedRect(x * -1, y * -1, scrW, scrH)
    end
end

local PANEL = {}

function PANEL:Init()
    if IsValid(Nexus.Proc.WeaponsPanel) then
        Nexus.Proc.WeaponsPanel:Remove()
    end

    self:SetSize(ScrW(), ScrH())
    self:SetPos(0, 0)
    self:MakePopup()
    self:SetAlpha(0)
    self:AlphaTo(255, 4, 0)
    self:SetCursor("blank")

    self.CursorTrails = {}
    self.CursorDrips = {}
    self.LastCursorPos = {x = 0, y = 0}
    self.NextDrip = 0

    self.Raindrops = {}
    for i = 1, 300 do
        local depth = math.random(1, 3) -- 1 = close, 3 = far
        table.insert(self.Raindrops, {
            x = math.random(0, ScrW()),
            y = math.random(-ScrH(), ScrH()),
            speed = math.random(1200, 2200) / depth,
            length = math.random(40, 90) / depth,
            alpha = math.random(30, 100) / depth,
            depth = depth,
            thickness = 1
        })
    end

    self.NextThunder = CurTime() + math.random(3, 8)
    self.LightningFlash = 0
    self.LightningFlicker = 0

    sound.PlayFile("sound/nexus_menu_music.mp3", "noplay", function(station)
        if IsValid(station) and IsValid(self) then
            station:SetVolume(0.85)
            station:Play()
            self.MusicStation = station

            -- Use GetLength to set up a precise looping timer once duration is known
            local function scheduleLoop()
                local duration = station:GetLength()
                if duration and duration > 0 then
                    timer.Create("NexusMenuMusicLoop", duration - 0.05, 0, function()
                        if IsValid(station) then
                            station:SetTime(0)
                            station:Play()
                        else
                            timer.Remove("NexusMenuMusicLoop")
                        end
                    end)
                else
                    -- Duration not ready yet, retry on next frame
                    timer.Simple(0.25, scheduleLoop)
                end
            end
            scheduleLoop()
        elseif IsValid(station) then
            station:Stop()
        end
    end)
    
    sound.PlayFile("sound/rain.mp3", "noplay", function(station)
        if IsValid(station) and IsValid(self) then
            station:EnableLooping(true)
            station:SetVolume(0.25)
            station:Play()
            self.RainStation = station
        elseif IsValid(station) then
            station:Stop()
        end
    end)

    local btnFont = Nexus:GetFont({size = 20, font="Horror Font"})
    self.PlayBtn = vgui.Create("Nexus:V2:Button", self)
    self.PlayBtn:SetText("")
    self.PlayBtn:SetSize(Nexus:GetScale(400), Nexus:GetScale(100))
    self.PlayBtn:SetPos(ScrW()/2 - Nexus:GetScale(200), ScrH()/2 + Nexus:GetScale(80))
    self.PlayBtn:SetCursor("blank")
    self.PlayBtn.Paint = function(s, w, h)
        surface.SetDrawColor(255, 255, 255, s:IsHovered() and 255 or 150)
        surface.SetMaterial(buttonMat)
        surface.DrawTexturedRect(0, 0, w, h)

        draw.SimpleText("BEGIN", btnFont, w/2, h/2, Nexus:GetTextColor(Nexus:GetColor("background")), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    self.PlayBtn.PaintOver = nil

    self.LeaveBtn = vgui.Create("Nexus:V2:Button", self)
    self.LeaveBtn:SetText("")
    self.LeaveBtn:SetSize(Nexus:GetScale(400), Nexus:GetScale(50))
    self.LeaveBtn:SetPos(ScrW()/2 - Nexus:GetScale(200), ScrH()/2 + Nexus:GetScale(210))
    self.LeaveBtn:SetCursor("blank")
    self.LeaveBtn.Paint = function(s, w, h)
        draw.SimpleText("DISCONNECT", btnFont, w/2, h/2, Nexus:GetTextColor(Nexus:GetColor("background"), not s:IsHovered()), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    self.LeaveBtn.PaintOver = nil
    self.LeaveBtn.DoClick = function()
        RunConsoleCommand("disconnect")
    end

    -- Character Customizer Panel (Starts hidden and covers the entire screen)
    self.PlayBtn.DoClick = function()
        self.PlayBtn:SetEnabled(false)
        if IsValid(self.WeaponsBtn) then self.WeaponsBtn:SetEnabled(false) end
        if IsValid(self.LeaveBtn) then self.LeaveBtn:SetEnabled(false) end
        
        -- Fade out the Customize Character button
        self.PlayBtn:AlphaTo(0, 0.4, 0, function()
            if IsValid(self.PlayBtn) then self.PlayBtn:SetVisible(false) end
        end)

        -- Fade out the Weapons button
        if IsValid(self.WeaponsBtn) then
            self.WeaponsBtn:AlphaTo(0, 0.4, 0, function()
                if IsValid(self.WeaponsBtn) then self.WeaponsBtn:SetVisible(false) end
            end)
        end

        -- Fade out the Leave button
        if IsValid(self.LeaveBtn) then
            self.LeaveBtn:AlphaTo(0, 0.4, 0, function()
                if IsValid(self.LeaveBtn) then self.LeaveBtn:SetVisible(false) end
            end)
        end
        
        -- Create the fullscreen customizer panel as a child
        local customizer = vgui.Create("Nexus:Proc:Customizer", self)
        customizer:Dock(FILL)
        customizer:SetAlpha(0)
        customizer:AlphaTo(255, 0.6, 0)
        
        self.Customizing = true
    end
end

function PANEL:Think()
end

function PANEL:Paint(w, h)
    local bgColor = Nexus:GetColor("background")
        Nexus.RNDX.Draw(0, 0, 0, w, h, bgColor)

    if CurTime() >= self.NextThunder then
        self.NextThunder = CurTime() + math.random(5, 20)
        
        local thunders = {"sound/thunder1.mp3", "sound/thunder2.mp3", "sound/thunder3.mp3"}
        sound.PlayFile(table.Random(thunders), "noplay", function(station)
            if IsValid(station) and IsValid(self) then 
                station:SetVolume(0.9) 
                station:Play() 
                self.ThunderStation = station
            elseif IsValid(station) then
                station:Stop()
            end
        end)

        self.LightningFlash = 255
        self.LightningFlicker = CurTime() + 0.4
    end

    surface.SetDrawColor(200, 210, 230, 255)
    for _, drop in ipairs(self.Raindrops) do
        drop.y = drop.y + drop.speed * FrameTime()
        drop.x = drop.x - (drop.speed * 0.15) * FrameTime()
        
        if drop.y > h then
            drop.y = -drop.length
            drop.x = math.random(0, w + Nexus:GetScale(300))
        end
        
        -- Depth-based colour: close = bright cold white, mid = grey-blue, far = dark and faint
        local r, g, b
        if drop.depth == 1 then
            r, g, b = 200, 215, 240 -- bright, cold, close
        elseif drop.depth == 2 then
            r, g, b = 130, 140, 165 -- mid-grey blue
        else
            r, g, b = 60, 65, 80   -- dark, barely visible, far
        end
        surface.SetDrawColor(r, g, b, drop.alpha)
        surface.DrawLine(drop.x, drop.y, drop.x - (drop.length * 0.15), drop.y + drop.length)
    end

    if self.LightningFlash > 0 then
        surface.SetDrawColor(220, 230, 255, self.LightningFlash)
        surface.DrawRect(0, 0, w, h)
        self.LightningFlash = math.Approach(self.LightningFlash, 0, FrameTime() * 800)
    elseif self.LightningFlicker > CurTime() then
        if math.random(1, 4) == 1 then
            surface.SetDrawColor(220, 230, 255, math.random(50, 150))
            surface.DrawRect(0, 0, w, h)
        end
    end

    -- Skip drawing titles if customizing character
    if not self.Customizing then
        local titleFont = Nexus:GetFont({size = 120, bold = true})
        local subFont = Nexus:GetFont({size = 35})
        
        local titleColor = Nexus:GetTextColor(bgColor)
        local subColor = Nexus:GetColor("red")
        
        draw.SimpleText("N I G H T  F A L L ", titleFont, w/2, h/2 - Nexus:GetScale(180), titleColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
        draw.SimpleText("It is always watching.", subFont, w/2, h/2 - Nexus:GetScale(160), subColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

        -- Round Information widget at the top-center
        local ROUND_WAITING = 0
        local ROUND_PREP    = 1
        local ROUND_ACTIVE  = 2
        local ROUND_VICTORY = 3
        local ROUND_DEFEAT  = 4

        local state = GetGlobalInt("NightFall:RoundState", ROUND_WAITING)
        local timeEnd = GetGlobalFloat("NightFall:Round:EndCurTime", 0)
        local timeLeft = math.max(0, timeEnd - CurTime())

        local stateText = "WAITING FOR PLAYERS"
        local stateColor = Color(180, 180, 180)
        local drawTimer = false

        if state == ROUND_PREP then
            stateText = "PREPARATION PHASE"
            stateColor = Color(200, 180, 50)
            drawTimer = true
        elseif state == ROUND_ACTIVE then
            stateText = "ROUND ACTIVE"
            stateColor = Color(220, 50, 50)
            drawTimer = true
        elseif state == ROUND_VICTORY or state == ROUND_DEFEAT then
            local won = NexusRoundStats and NexusRoundStats.won or (state == ROUND_VICTORY)
            if won then
                stateText = "VICTORY"
                stateColor = Color(50, 220, 50)
            else
                stateText = "DEFEATED"
                stateColor = Color(220, 50, 50)
            end
        end

        local widgetW, widgetH = Nexus:GetScale(320), Nexus:GetScale(60)
        local widgetX, widgetY = w/2 - widgetW/2, Nexus:GetScale(40)

        -- Background Panel
        local hudBgMat = Material("hud_background.png")
        surface.SetDrawColor(255, 255, 255, 50)
        surface.SetMaterial(hudBgMat)
        surface.DrawTexturedRect(widgetX, widgetY, widgetW, widgetH)

        -- Text positioning
        local textX = widgetX + widgetW / 2
        local labelFont = Nexus:GetFont({size = 14, bold = true})
        local valFont = Nexus:GetFont({size = 18, bold = true})

        if drawTimer then
            local mins = math.floor(timeLeft / 60)
            local secs = math.floor(timeLeft % 60)
            local timerText = string.format("%02d:%02d", mins, secs)

            draw.SimpleText(stateText, labelFont, textX, widgetY + Nexus:GetScale(12), Color(180, 180, 180), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
            draw.SimpleText(timerText, valFont, textX, widgetY + Nexus:GetScale(28), stateColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        else
            draw.SimpleText(stateText, valFont, textX, widgetY + widgetH / 2, stateColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end
end

function PANEL:PaintOver(w, h)
    local mx, my = gui.MousePos()
    local x, y = self:ScreenToLocal(mx, my)

    local handSize = Nexus:GetScale(32)
    local cx = x
    local cy = y

    -- Bloody cursor trail on movement
    local dx = x - self.LastCursorPos.x
    local dy = y - self.LastCursorPos.y
    local dist = math.sqrt(dx*dx + dy*dy)
    if dist > Nexus:GetScale(6) then
        table.insert(self.CursorTrails, {
            x = cx,
            y = cy,
            size = Nexus:GetScale(math.random(2, 4)),
            life = 1.2
        })
        self.LastCursorPos = {x = x, y = y}
    end

    -- Dripping blood periodically
    if CurTime() > self.NextDrip then
        self.NextDrip = CurTime() + math.random(0.1, 0.25)
        table.insert(self.CursorDrips, {
            x = cx + math.random(Nexus:GetScale(-4), Nexus:GetScale(4)),
            y = cy + handSize * 0.5,
            speedY = Nexus:GetScale(math.random(120, 240)),
            speedX = Nexus:GetScale(math.random(-15, 15)),
            size = Nexus:GetScale(math.random(1, 2)),
            life = 1.0
        })
    end

    -- Draw trails
    for i = #self.CursorTrails, 1, -1 do
        local trail = self.CursorTrails[i]
        trail.life = trail.life - FrameTime()
        if trail.life <= 0 then
            table.remove(self.CursorTrails, i)
        else
            local alpha = (trail.life / 1.2) * 180
            draw.RoundedBox(trail.size / 2, trail.x - trail.size/2, trail.y - trail.size/2, trail.size, trail.size, Color(130, 10, 10, alpha))
        end
    end

    -- Draw drips with gravity
    for i = #self.CursorDrips, 1, -1 do
        local drip = self.CursorDrips[i]
        drip.life = drip.life - FrameTime()
        if drip.life <= 0 then
            table.remove(self.CursorDrips, i)
        else
            drip.y = drip.y + drip.speedY * FrameTime()
            drip.x = drip.x + drip.speedX * FrameTime()
            drip.speedY = drip.speedY + Nexus:GetScale(350) * FrameTime()
            local alpha = (drip.life / 1.0) * 220
            draw.RoundedBox(drip.size / 2, drip.x - drip.size/2, drip.y - drip.size/2, drip.size, drip.size, Color(150, 12, 12, alpha))
        end
    end

    -- Draw main hand cursor (centered on cursor coordinates)
    surface.SetDrawColor(255, 255, 255, 255)
    surface.SetMaterial(cursorMat)
    surface.DrawTexturedRect(x - handSize * 0.5, y - handSize * 0.5, handSize, handSize)
end

function PANEL:OnRemove()
    timer.Remove("NexusMenuMusicLoop")
    if IsValid(self.MusicStation) then self.MusicStation:Stop() end
    if IsValid(self.RainStation) then self.RainStation:Stop() end
    if IsValid(self.ThunderStation) then self.ThunderStation:Stop() end
end

vgui.Register("Nexus:Proc:Menu", PANEL, "EditablePanel")