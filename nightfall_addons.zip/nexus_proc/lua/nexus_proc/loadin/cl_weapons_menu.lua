-- cl_weapons_menu.lua
-- Weapons selection and attachment customizer menu.

local rectBackgroundMat = Material("rectangle_background.png")
local miniBackgroundMat = Material("mini_rectangle_background.png")
local PANEL = {}

local function wrapText(text, font, maxWidth)
    surface.SetFont(font)
    local words = string.Explode(" ", text)
    local lines = {}
    local currentLine = ""

    for _, word in ipairs(words) do
        local testLine = currentLine == "" and word or (currentLine .. " " .. word)
        local w, _ = surface.GetTextSize(testLine)
        if w > maxWidth then
            if currentLine ~= "" then
                table.insert(lines, currentLine)
            end
            currentLine = word
        else
            currentLine = testLine
        end
    end
    if currentLine ~= "" then
        table.insert(lines, currentLine)
    end
    return lines
end

local PREFS_FILE = "nexus_proc/loadout_prefs.json"

-- Receive server-synced unlock state
net.Receive("Nexus:Loadin:SyncUnlocks", function()
    local unlocks = net.ReadTable()
    local coins = net.ReadInt(32)
    Nexus.Proc.Weapons.ClientUnlocks = unlocks
    Nexus.Proc.Weapons.Coins = coins

    -- Refresh weapons panel if open
    if IsValid(Nexus.Proc.WeaponsPanel) and Nexus.Proc.WeaponsPanel.RebuildWeaponList then
        Nexus.Proc.WeaponsPanel:RebuildWeaponList()
        Nexus.Proc.WeaponsPanel:RebuildRightPanel()
    end
end)

local function loadPrefs()
    if file.Exists(PREFS_FILE, "DATA") then
        local data = file.Read(PREFS_FILE, "DATA")
        return util.JSONToTable(data) or {}
    end
    return {
        primary = "arc9_cod2019_ar_m4",
        secondary = "arc9_cod2019_pi_x16",
        attachments = {}
    }
end

local function savePrefs(loadout)
    if not file.Exists("nexus_proc", "DATA") then
        file.CreateDir("nexus_proc")
    end
    file.Write(PREFS_FILE, util.TableToJSON(loadout))
end

-- The character-entry request uses this to send the latest local selection
-- before the server begins spawning the player's weapons.
Nexus.Proc.GetSavedLoadout = function()
    return loadPrefs()
end

-- Slot keys may arrive as numbers after net.ReadTable, or as strings after
-- JSON persistence.  Always accept both so the customizer UI matches the
-- attachments that are actually applied to the weapon.
local function getEquippedAttachment(loadout, weaponClass, slotIdx)
    local attachments = loadout and loadout.attachments
    local slots = attachments and attachments[weaponClass]
    if not slots then return nil end

    return slots[tostring(slotIdx)] or slots[slotIdx]
end

local function clearEquippedAttachment(loadout, weaponClass, slotIdx)
    local attachments = loadout and loadout.attachments
    local slots = attachments and attachments[weaponClass]
    if not slots then return end

    slots[tostring(slotIdx)] = nil
    slots[slotIdx] = nil
end

-- Receive server-authoritative saved loadout (sent on join to restore previous session)
-- Defined here so savePrefs is in scope for the callback closure
net.Receive("Nexus:Loadin:SendLoadout", function()
    local loadout = net.ReadTable()
    -- Persist to local file so it's available if the menu is opened before the net msg arrives
    savePrefs(loadout)
    -- If the weapons menu is currently open, update it live
    for _, pnl in ipairs(vgui.GetWorldPanel():GetChildren()) do
        if pnl.ClassName == "Nexus:Proc:WeaponsMenu" and IsValid(pnl) then
            pnl.CurrentLoadout = loadout
            if pnl.RebuildWeaponList then pnl.RebuildWeaponList() end
            if pnl.RebuildRightPanel then pnl.RebuildRightPanel() end
        end
    end
end)

local function hideCursorRecursive(pnl)
    if not IsValid(pnl) then return end
    pnl:SetCursor("blank")
    for _, child in ipairs(pnl:GetChildren()) do
        hideCursorRecursive(child)
    end
end

-- Retrieve attachments compatible with a given category/categories from ARC9
local function GetAttachmentsForCategories(cats)
    if not cats then return {} end
    if not istable(cats) then cats = {cats} end

    local tbl = {}
    for shortname, att in pairs(ARC9.Attachments or {}) do
        if att.Free then continue end
        local attCats = att.Category
        if not attCats then continue end
        if not istable(attCats) then attCats = {attCats} end

        local match = false
        for _, c in ipairs(cats) do
            if table.HasValue(attCats, c) then
                match = true
                break
            end
        end
        if match then
            table.insert(tbl, {
                shortname = shortname,
                name = ARC9:GetPhraseForAtt(shortname, "PrintName") or att.PrintName or shortname,
                icon = att.Icon
            })
        end
    end

    -- Sort alphabetically
    table.sort(tbl, function(a, b) return a.name < b.name end)
    return tbl
end

function PANEL:Init()
    self:SetSize(ScrW(), ScrH())
    self:SetPos(0, 0)
    self:SetCursor("blank")

    self.CurrentLoadout = loadPrefs()
    self.SelectedWeaponClass = self.CurrentLoadout.primary or "arc9_cod2019_ar_m4"

    self.CursorTrails = {}
    self.CursorDrips = {}
    self.LastCursorPos = {x = 0, y = 0}
    self.NextDrip = 0

    -- Left panel: Weapons lists (40% width)
    local leftPanel = self:Add("DPanel")
    leftPanel:DockMargin(0, Nexus:GetScale(55 + 20) + Nexus:GetMargin(), 0, 0)
    leftPanel:Dock(LEFT)
    leftPanel:SetWide(ScrW() * 0.35)
    leftPanel.Paint = function(s, w, h)
        local sidebarCol = Color(6, 6, 8, 220)
        Nexus.RNDX.Draw(0, 0, 0, w, h, sidebarCol, nil, true)
        
        local highlight = Nexus:GetColor("accent")
        if highlight then
            Nexus.RNDX.Draw(w - Nexus:GetScale(4), 0, 0, Nexus:GetScale(4), h, highlight)
        end
    end

    self.CollapsedCategories = self.CollapsedCategories or {}
    self.SearchQuery = self.SearchQuery or ""
    self.ActiveCategory = self.ActiveCategory or "Primary"

    -- Tab Navbar: Primary / Secondary
    local navbar = leftPanel:Add("Nexus:V2:Navbar")
    navbar:Dock(TOP)
    navbar:DockMargin(Nexus:GetScale(25), Nexus:GetScale(15), Nexus:GetScale(25), 0)
    navbar:SetFullWide(true)

    navbar:AddItem("Primary Weapon", function()
        self.ActiveCategory = "Primary"
        self.CollapsedCategories = {}
        if self.RebuildWeaponList then self.RebuildWeaponList() end
    end, nil, 1)

    navbar:AddItem("Secondary Weapon", function()
        self.ActiveCategory = "Secondary"
        self.CollapsedCategories = {}
        if self.RebuildWeaponList then self.RebuildWeaponList() end
    end, nil, 2)

    -- Auto-select the tab matching the currently selected weapon
    timer.Simple(0, function()
        if not IsValid(navbar) then return end
        local wepDef
        for _, w in ipairs(Nexus.Proc.Weapons.List or {}) do
            if w.class == self.SelectedWeaponClass then wepDef = w break end
        end
        if wepDef and wepDef.category == "Secondary" then
            navbar:SelectItem(2)
        else
            navbar:SelectItem(1)
        end
    end)

    local searchInput = leftPanel:Add("Nexus:V2:TextEntry")
    searchInput:Dock(TOP)
    searchInput:SetTall(Nexus:GetScale(45))
    searchInput:DockMargin(Nexus:GetScale(25), Nexus:GetScale(10), Nexus:GetScale(25), Nexus:GetScale(10))
    searchInput:SetPlaceholder("Search weapons...")
    searchInput.OnChange = function(s)
        self.SearchQuery = s:GetValue() or ""
        self.RebuildWeaponList()
    end

    -- Left ScrollPanel
    local leftScroll = leftPanel:Add("Nexus:V2:ScrollPanel")
    leftScroll:Dock(FILL)
    leftScroll:DockMargin(Nexus:GetScale(25), 0, Nexus:GetScale(25), Nexus:GetScale(25))

    -- Right panel: Weapon details and Attachment slots (65% width)
    local rightPanel = self:Add("DPanel")
    rightPanel:Dock(FILL)
    rightPanel.Paint = nil

    self.RightPanel = rightPanel

    -- Rebuild function
    self.RebuildWeaponList = function()
        leftScroll:Clear()

        local query = string.lower(self.SearchQuery or "")
        local isSearching = query ~= ""

        local subCatsMap = {}
        for _, wep in ipairs(Nexus.Proc.Weapons.List or {}) do
            -- Filter by active tab category
            if wep.category ~= self.ActiveCategory then continue end
            if isSearching and not string.find(string.lower(wep.name), query, 1, true) then
                continue
            end
            local sc = wep.subCategory or "Other"
            subCatsMap[sc] = true
        end

        local subCats = {}
        for sc, _ in pairs(subCatsMap) do
            table.insert(subCats, sc)
        end

        local preferredOrder = {
            ["Assault Rifles"] = 1,
            ["Submachine Guns"] = 2,
            ["Shotguns"] = 3,
            ["Sniper Rifles"] = 4,
            ["Pistols"] = 5,
            ["Other"] = 99
        }

        table.sort(subCats, function(a, b)
            local orderA = preferredOrder[a] or 50
            local orderB = preferredOrder[b] or 50
            if orderA ~= orderB then
                return orderA < orderB
            end
            return a < b
        end)

        for _, subCat in ipairs(subCats) do
            local weaponsInSubcat = {}
            for _, wep in ipairs(Nexus.Proc.Weapons.List or {}) do
                if wep.category ~= self.ActiveCategory then continue end
                if (wep.subCategory or "Other") == subCat then
                    if not isSearching or string.find(string.lower(wep.name), query, 1, true) then
                        table.insert(weaponsInSubcat, wep)
                    end
                end
            end
            if #weaponsInSubcat == 0 then continue end

            local isCollapsed = self.CollapsedCategories[subCat] == true and not isSearching

            -- Header Button (for collapsing)
            local headerBtn = leftScroll:Add("DButton")
            headerBtn:SetText("")
            headerBtn:SetTall(Nexus:GetScale(35))
            headerBtn:Dock(TOP)
            headerBtn:DockMargin(0, Nexus:GetScale(15), 0, Nexus:GetScale(5))
            headerBtn.Paint = function(s, w, h)
                local arrow = isCollapsed and "▶" or "▼"
                local txt = arrow .. "  " .. string.upper(subCat)
                
                local textColor = s:IsHovered() and Nexus:GetColor("accent") or Nexus:GetColor("red")
                if not textColor then textColor = s:IsHovered() and Color(50, 200, 50) or Color(200, 50, 50) end
                
                draw.SimpleText(txt, Nexus:GetFont({size = 16, bold = true}), 0, h / 2, textColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            end
            headerBtn.DoClick = function()
                self.CollapsedCategories[subCat] = not self.CollapsedCategories[subCat]
                self.RebuildWeaponList()
                surface.PlaySound("common/talk.wav")
            end

            -- Render weapons in category
            if not isCollapsed then
                for _, wep in ipairs(weaponsInSubcat) do
                    local isUnlocked = Nexus.Proc.Weapons:IsWeaponUnlocked(LocalPlayer(), wep.class)
                    local isEquipped = (self.CurrentLoadout.primary == wep.class) or (self.CurrentLoadout.secondary == wep.class)
                    local isSelected = (self.SelectedWeaponClass == wep.class)

                    local btn = leftScroll:Add("Nexus:V2:Button")
                    btn:SetText("")
                    btn:SetTall(Nexus:GetScale(60))
                    btn:Dock(TOP)
                    btn:DockMargin(0, 0, 0, Nexus:GetScale(8))
                    btn:SetCursor("blank")

                    btn.Paint = function(s, w, h)
                        local bgCol = isSelected and Color(40, 40, 50, 200) or Color(15, 15, 20, 150)
                        if s:IsHovered() then bgCol = Color(50, 50, 60, 220) end

                        surface.SetDrawColor(bgCol.r, bgCol.g, bgCol.b, bgCol.a)
                        surface.SetMaterial(rectBackgroundMat)
                        surface.DrawTexturedRect(0, 0, w, h)

                        if isEquipped then
                            draw.RoundedBox(0, 0, 0, Nexus:GetScale(5), h, Nexus:GetColor("accent") or Color(50, 200, 50))
                        end

                        draw.SimpleText(wep.name, Nexus:GetFont({size = 16, bold = true, font="Lato"}), Nexus:GetScale(15), h / 2, isUnlocked and color_white or Color(120, 120, 120), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                        
                        if not isUnlocked then
                            local price = Nexus.Proc.Weapons:GetWeaponPrice(wep.class)
                            draw.SimpleText("$" .. price, Nexus:GetFont({size = 12, bold = true}), w - Nexus:GetScale(15), h / 2, Color(255, 200, 50), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
                        elseif isEquipped then
                            draw.SimpleText("EQUIPPED", Nexus:GetFont({size = 12, bold = true}), w - Nexus:GetScale(15), h / 2, Color(50, 200, 50), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
                        end
                    end

                    btn.DoClick = function()
                        self.SelectedWeaponClass = wep.class
                        self.RebuildWeaponList()
                        self.RebuildRightPanel()
                    end
                end
            end
        end
    end

    self.RebuildRightPanel = function()
        rightPanel:Clear()

        local modelPanel
        local wepDef
        for _, w in ipairs(Nexus.Proc.Weapons.List or {}) do
            if w.class == self.SelectedWeaponClass then
                wepDef = w
                break
            end
        end
        if not wepDef then return end

        local wepTable = weapons.Get(self.SelectedWeaponClass)

        local infoPanel = rightPanel:Add("DPanel")
        infoPanel:Dock(TOP)
        infoPanel:SetTall(Nexus:GetScale(260))
        infoPanel:DockMargin(Nexus:GetScale(40), Nexus:GetScale(40), Nexus:GetScale(40), 0)
        infoPanel.Paint = nil

        -- Left column inside infoPanel: Weapon details
        local leftInfo = infoPanel:Add("DPanel")
        leftInfo:Dock(LEFT)
        leftInfo:SetWide(Nexus:GetScale(400))
        leftInfo.Paint = function(s, w, h)
            local hoveredAtt = self.HoveredAttTable
            if hoveredAtt then
                draw.SimpleText(string.upper(hoveredAtt.PrintName or hoveredAtt.shortname or "ATTACHMENT"), Nexus:GetFont({size = 22, bold = true}), 0, 0, Nexus:GetColor("red"))

                local prosname, prosnum, consname, consnum = {}, {}, {}, {}
                if ARC9.GetProsAndCons then
                    prosname, prosnum, consname, consnum = ARC9.GetProsAndCons(hoveredAtt, modelPanel.Entity)
                end
                
                local y = Nexus:GetScale(35)
                
                if prosname and #prosname > 0 then
                    draw.SimpleText("PROS:", Nexus:GetFont({size = 11, bold = true, font="Lato"}), 0, y, Color(120, 255, 120))
                    y = y + Nexus:GetScale(15)
                    for i = 1, math.min(#prosname, 3) do
                        local txt = "  + " .. (prosname[i] or "")
                        if prosnum[i] and prosnum[i] ~= "" then
                            txt = txt .. " (" .. prosnum[i] .. ")"
                        end
                        draw.SimpleText(txt, Nexus:GetFont({size = 11, bold = true, font="Lato"}), 0, y, Color(160, 255, 160))
                        y = y + Nexus:GetScale(15)
                    end
                end
                
                y = y + Nexus:GetScale(10)
                
                if consname and #consname > 0 then
                    draw.SimpleText("CONS:", Nexus:GetFont({size = 11, bold = true, font="Lato"}), 0, y, Color(255, 120, 120))
                    y = y + Nexus:GetScale(15)
                    for i = 1, math.min(#consname, 3) do
                        local txt = "  - " .. (consname[i] or "")
                        if consnum[i] and consnum[i] ~= "" then
                            txt = txt .. " (" .. consnum[i] .. ")"
                        end
                        draw.SimpleText(txt, Nexus:GetFont({size = 11, bold = true, font="Lato"}), 0, y, Color(255, 160, 160))
                        y = y + Nexus:GetScale(15)
                    end
                end
            end
        end

        local wepName = leftInfo:Add("DLabel")
        wepName:SetFont(Nexus:GetFont({size = 36, bold = true}))
        wepName:SetText(wepDef.name)
        wepName:SetTextColor(color_white)
        wepName:Dock(TOP)
        wepName:SizeToContents()

        -- Equip button
        local isEquipped = (self.CurrentLoadout.primary == wepDef.class) or (self.CurrentLoadout.secondary == wepDef.class)
        local isWeaponUnlocked = Nexus.Proc.Weapons:IsWeaponUnlocked(LocalPlayer(), wepDef.class)
        local equipBtn = leftInfo:Add("Nexus:V2:Button")
        equipBtn:SetText("")
        equipBtn:SetSize(Nexus:GetScale(180), Nexus:GetScale(40))
        equipBtn:SetPos(0, wepName:GetY() + wepName:GetTall() + Nexus:GetMargin())
        equipBtn:SetCursor("blank")

        leftInfo.Think = function(s)
            local isHovering = (self.HoveredAttTable ~= nil)
            if IsValid(wepDesc) then wepDesc:SetVisible(not isHovering) end
            if IsValid(wepName) then wepName:SetVisible(not isHovering) end
            if IsValid(equipBtn) then equipBtn:SetVisible(not isHovering) end
        end
        equipBtn.Paint = function(s, w, h)
            local bg
            if not isWeaponUnlocked then
                bg = s:IsHovered() and Color(60, 60, 60, 220) or Color(40, 40, 40, 200)
            elseif isEquipped then
                bg = s:IsHovered() and Color(40, 100, 40, 220) or Color(30, 80, 30, 200)
            else
                bg = s:IsHovered() and Color(100, 40, 40, 220) or Color(80, 30, 30, 200)
            end
            surface.SetDrawColor(bg.r, bg.g, bg.b, bg.a)
            surface.SetMaterial(rectBackgroundMat)
            surface.DrawTexturedRect(0, 0, w, h)
            local text = (not isWeaponUnlocked) and "LOCKED (BUY)" or (isEquipped and "UNEQUIP" or "EQUIP WEAPON")
            local col = (not isWeaponUnlocked) and Color(200, 50, 50) or color_white
            draw.SimpleText(text, Nexus:GetFont({size = 14, bold = true}), w/2, h/2, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        equipBtn.DoClick = function()
            if not isWeaponUnlocked then
                -- Offer to buy the weapon with coins
                local cost = Nexus.Proc.Weapons:GetWeaponPrice(wepDef.class)
                local coins = Nexus.Proc.Weapons and Nexus.Proc.Weapons.Coins or 0
                if coins < cost then
                    Nexus:QueryPopup(
                        "You need $" .. cost .. " coins to unlock " .. wepDef.name .. "!\nYou only have $" .. coins .. ". Earn more by killing spiders.",
                        function() end, function() end,
                        "OK", "Close"
                    )
                else
                    Nexus:QueryPopup(
                        "Buy " .. wepDef.name .. " for $" .. cost .. " coins?\nYou have $" .. coins .. ".",
                        function()
                            net.Start("Nexus:Loadin:BuyWeapon")
                            net.WriteString(wepDef.class)
                            net.SendToServer()
                        end,
                        function() end,
                        "Buy ($" .. cost .. ")",
                        "Cancel"
                    )
                end
                return
            end
            if isEquipped then
                if wepDef.category == "Primary" then
                    self.CurrentLoadout.primary = "none"
                else
                    self.CurrentLoadout.secondary = "none"
                end
            else
                if wepDef.category == "Primary" then
                    self.CurrentLoadout.primary = wepDef.class
                else
                    self.CurrentLoadout.secondary = wepDef.class
                end
            end
            savePrefs(self.CurrentLoadout)
            self:SyncLoadout()
            self.RebuildWeaponList()
            self.RebuildRightPanel()
            surface.PlaySound("items/ammo_pickup.wav")
        end

        local function GetStats(ent)
            if not IsValid(ent) then return {} end
            return {
                Damage = ent:GetProcessedValue("DamageMax") or ent:GetProcessedValue("Damage") or 30,
                FireRate = ent:GetProcessedValue("RPM") or (60 / (ent:GetProcessedValue("CycleTime") or 0.1)),
                Spread = ent:GetProcessedValue("Spread") or 0.02,
                Recoil = ent:GetProcessedValue("Recoil") or 1,
                Range = ent:GetProcessedValue("RangeMax") or ent:GetProcessedValue("Range") or 3000,
                ADS = ent:GetProcessedValue("AimTime") or 0.3,
                MagSize = ent:GetProcessedValue("ClipSize") or 30,
                MuzzleVelocity = ent:GetProcessedValue("MuzzleVelocity") or 800
            }
        end

        -- Right column: Weapon Stats Comparison
        local statsPanel = infoPanel:Add("DPanel")
        statsPanel:Dock(FILL)
        statsPanel:DockMargin(Nexus:GetScale(60), 0, 0, 0)
        statsPanel.Think = function(s)
            s:InvalidateLayout(true)
        end
        statsPanel.Paint = function(s, w, h)
            if not IsValid(modelPanel.Entity) then return end

            local statsToDraw = {
                { name = "DAMAGE", key = "Damage", max = 100, unit = "" },
                { name = "FIRE RATE", key = "FireRate", max = 1200, unit = " RPM" },
                { name = "SPREAD", key = "Spread", max = 0.1, unit = "", invert = true },
                { name = "RECOIL", key = "Recoil", max = 5, unit = "", invert = true },
                { name = "RANGE", key = "Range", max = 5000, unit = "m" },
                { name = "ADS SPEED", key = "ADS", max = 1.0, unit = "s", invert = true },
                { name = "MAG CAPACITY", key = "MagSize", max = 150, unit = " rounds" },
                { name = "MUZZLE VELOCITY", key = "MuzzleVelocity", max = 1200, unit = " m/s" }
            }

            local curStats = GetStats(modelPanel.Entity)
            local hoverStats = self.HoveredStats

            local rowHeight = h / #statsToDraw
            for i, stat in ipairs(statsToDraw) do
                local y = (i - 1) * rowHeight
                
                local decimals = (stat.key == "ADS" or stat.key == "Recoil" or stat.key == "Spread") and 2 or 0
                local valStr = math.Round(curStats[stat.key], decimals) .. stat.unit
                if hoverStats then
                    local diff = hoverStats[stat.key] - curStats[stat.key]
                    if math.abs(diff) > 0.0005 then
                        local sign = diff > 0 and "+" or ""
                        local pctStr = ""
                        if curStats[stat.key] and curStats[stat.key] ~= 0 then
                            local pct = (diff / curStats[stat.key]) * 100
                            pctStr = " (" .. sign .. math.Round(pct, 0) .. "%)"
                        else
                            pctStr = " (" .. sign .. math.Round(diff, decimals) .. stat.unit .. ")"
                        end
                        valStr = valStr .. pctStr
                    end
                end
                
                draw.SimpleText(stat.name, Nexus:GetFont({size = 11, bold = true}), 0, y + 2, Color(160, 160, 160))
                draw.SimpleText(valStr, Nexus:GetFont({size = 11, bold = true}), w, y + 2, color_white, TEXT_ALIGN_RIGHT)

                local barY = y + 18
                local barH = Nexus:GetScale(6)
                draw.RoundedBox(2, 0, barY, w, barH, Color(40, 40, 45, 150))

                local curVal = curStats[stat.key]
                local hovVal = hoverStats and hoverStats[stat.key] or curVal

                if stat.invert then
                    curVal = stat.max - curVal
                    hovVal = stat.max - hovVal
                end

                local curFrac = math.Clamp(curVal / stat.max, 0, 1)
                local hovFrac = math.Clamp(hovVal / stat.max, 0, 1)

                local curW = w * curFrac
                local hovW = w * hovFrac

                if hovFrac > curFrac then
                    draw.RoundedBox(2, 0, barY, curW, barH, Color(220, 220, 220))
                    draw.RoundedBox(2, curW, barY, hovW - curW, barH, Color(50, 200, 50))
                elseif hovFrac < curFrac then
                    draw.RoundedBox(2, 0, barY, hovW, barH, Color(220, 220, 220))
                    draw.RoundedBox(2, hovW, barY, curW - hovW, barH, Color(200, 50, 50))
                else
                    draw.RoundedBox(2, 0, barY, curW, barH, Color(220, 220, 220))
                end
            end
        end

        -- Bottom Customizer Panel (Payday 3 Style) - Docked directly to rightPanel to span entire bottom space
        local bottomPanel = rightPanel:Add("DPanel")
        bottomPanel:Dock(BOTTOM)
        bottomPanel:SetTall(Nexus:GetScale(160))
        bottomPanel:DockMargin(0, 0, 0, 0)
        bottomPanel.Paint = function(s, w, h)
            draw.RoundedBox(0, 0, 0, w, h, Color(10, 10, 15, 235))
            surface.SetDrawColor(Nexus:GetColor("red"))
            surface.DrawRect(0, 0, w, 2)
        end

        -- Container for customization area (holds the 3D preview)
        local customArea = rightPanel:Add("DPanel")
        customArea:Dock(FILL)
        customArea:DockMargin(Nexus:GetScale(40), Nexus:GetScale(20), Nexus:GetScale(40), 0)
        customArea.Paint = nil

        -- 3D Weapon Model Preview (filling the customArea)
        modelPanel = customArea:Add("DPanel")
        modelPanel:Dock(FILL)
        modelPanel.DragAng = Angle(0, 0, 0)
        modelPanel.DragOffset = Vector(0, 0, 0)
        modelPanel.ZoomFactor = 1.0
        modelPanel.colAmbientLight = Color(50, 50, 50)
        modelPanel.DirectionalLight = {
            [BOX_TOP] = Color(255, 255, 255),
            [BOX_FRONT] = Color(150, 150, 150),
        }

        modelPanel.OnMousePressed = function(s, mouseCode)
            s.Dragging = true
            s.MouseCode = mouseCode
            s.LastMouseX, s.LastMouseY = gui.MousePos()
        end

        modelPanel.OnMouseReleased = function(s, mouseCode)
            s.Dragging = false
        end

        modelPanel.OnMouseWheeled = function(s, delta)
            s.ZoomFactor = math.Clamp(s.ZoomFactor - delta * 0.05, 0.2, 3.0)
        end

        modelPanel.Think = function(s)
            if s.Dragging then
                local mx, my = gui.MousePos()
                local dx = mx - s.LastMouseX
                local dy = my - s.LastMouseY
                
                if s.MouseCode == MOUSE_LEFT then
                    s.DragAng.y = s.DragAng.y - dx * 0.5
                    s.DragAng.p = s.DragAng.p + dy * 0.5
                elseif s.MouseCode == MOUSE_RIGHT then
                    s.DragOffset.y = s.DragOffset.y + dx * 0.03
                    s.DragOffset.z = s.DragOffset.z - dy * 0.03
                end
                
                s.LastMouseX = mx
                s.LastMouseY = my
            end
        end

        -- Spawn a clientside model and copy weapon methods to simulate a clientside weapon entity
        local modelPath = wepTable.ViewModel or wepTable.WorldModel or "models/weapons/w_rif_m4a1.mdl"
        local wepEnt = ClientsideModel(modelPath)
        print("[Loadout Debug] Creating ClientsideModel weapon: ", modelPath, IsValid(wepEnt))
        if IsValid(wepEnt) then
            wepEnt:SetNoDraw(true)

            -- Copy all weapon methods (including inherited ones from base classes)
            local base = weapons.Get(self.SelectedWeaponClass) or wepTable
            local baseClass = weapons.Get("arc9_base")
            local current = base
            while current do
                for k, v in pairs(current) do
                    if isfunction(v) and wepEnt[k] == nil then
                        wepEnt[k] = v
                    end
                end
                local mt = getmetatable(current)
                current = mt and mt.__index
            end

            -- Setup required weapon properties for ARC9
            wepEnt.Attachments = {}
            if wepTable.Attachments then
                for i, slot in ipairs(wepTable.Attachments) do
                    wepEnt.Attachments[i] = table.Copy(slot)
                    wepEnt.Attachments[i].Address = i
                end
            end

            wepEnt.CanAttach = function() return true end
            wepEnt.CanDetach = function() return true end
            wepEnt.AttPosCache = {}
            wepEnt.HasNoAffectors = {}
            wepEnt.StatCache = {}
            wepEnt.HookCache = {}
            wepEnt.PV_CacheLong = {}
            wepEnt.PV_Cache = {}
            wepEnt.PV_Tick = 0
            wepEnt.MirrorVMWM = true

            -- Mock owner/active sight/etc methods to prevent errors in ARC9 draw code
            wepEnt.GetOwner = function() return nil end
            wepEnt.GetActiveSightSlotTable = function(s) return {} end
            wepEnt.GetHiddenBones = function() return {} end
            wepEnt.GetProcessedValue = function(s, name, bool)
                local stat = nil
                if s[name] ~= nil then 
                    stat = s[name] 
                elseif base and base[name] ~= nil then 
                    stat = base[name] 
                elseif baseClass and baseClass[name] ~= nil then 
                    stat = baseClass[name] 
                end

                if type(stat) == "number" then
                    -- Process overrides
                    for _, slot in ipairs(s.Attachments or {}) do
                        if slot.Installed then
                            local attTable = ARC9.Attachments[slot.Installed]
                            if attTable then
                                if attTable[name .. "Override"] ~= nil then
                                    stat = attTable[name .. "Override"]
                                elseif name == "DamageMax" and attTable["DamageOverride"] ~= nil then
                                    stat = attTable["DamageOverride"]
                                elseif name == "RangeMax" and attTable["RangeOverride"] ~= nil then
                                    stat = attTable["RangeOverride"]
                                end
                            end
                        end
                    end
                    -- Process additives
                    for _, slot in ipairs(s.Attachments or {}) do
                        if slot.Installed then
                            local attTable = ARC9.Attachments[slot.Installed]
                            if attTable then
                                if attTable[name .. "Add"] ~= nil then
                                    stat = stat + attTable[name .. "Add"]
                                elseif name == "DamageMax" and attTable["DamageAdd"] ~= nil then
                                    stat = stat + attTable["DamageAdd"]
                                elseif name == "RangeMax" and attTable["RangeAdd"] ~= nil then
                                    stat = stat + attTable["RangeAdd"]
                                end
                            end
                        end
                    end
                    -- Process multipliers
                    for _, slot in ipairs(s.Attachments or {}) do
                        if slot.Installed then
                            local attTable = ARC9.Attachments[slot.Installed]
                            if attTable then
                                if attTable[name .. "Mult"] ~= nil then
                                    stat = stat * attTable[name .. "Mult"]
                                elseif name == "DamageMax" and attTable["DamageMult"] ~= nil then
                                    stat = stat * attTable["DamageMult"]
                                elseif name == "RangeMax" and attTable["RangeMult"] ~= nil then
                                    stat = stat * attTable["RangeMult"]
                                end
                            end
                        end
                    end
                end

                return stat
            end
            wepEnt.SetHoldType = function() end
            wepEnt.GetVM = function(s) return s end
            wepEnt.Clip1 = function() return 0 end
            wepEnt.Clip2 = function() return 0 end
            wepEnt.Ammo1 = function() return 0 end
            wepEnt.Ammo2 = function() return 0 end
            wepEnt.CallOnClient = function() end

            wepEnt.GetValue = function(s, val, baseVal, condition, amount)
                return s:GetProcessedValue(val)
            end
            
            -- Mapping of DT variables to their registered types
            local dtTypes = {
                RecoilAmount = "number", AnimLockTime = "number", NextIdle = "number", LastRecoilTime = "number",
                RecoilUp = "number", RecoilSide = "number", SprintAmount = "number", LastMeleeTime = "number",
                TriggerDelay = "number", ReloadTime = "number", ReloadFinishTime = "number", SightAmount = "number",
                HeatAmount = "number", MeleeAttackTime = "number", FinishFiremodeAnimTime = "number",
                IKTimeLineStart = "number", IKTime = "number", HolsterTime = "number", CycleFinishTime = "number",
                EnterBipodTime = "number", Breath = "number", SequenceCycle = "number", SequenceSpeed = "number",
                LastHolsterTime = "number", GrenadePrimedTime = "number", LockOnStartTime = "number",
                NearWallAmount = "number", ReadyTime = "number", BurstCount = "number", NthShot = "number",
                LoadedRounds = "number", Firemode = "number", NthReload = "number", MultiSight = "number",
                SequenceProxy = "number", HideBoneIndex = "number", SequenceIndex = "number",
                LastLoadedRounds = "number", PoseParameterIndex = "number", ReloadAmount = "number",
                Customize = "boolean", Reloading = "boolean", EndReload = "boolean", Safe = "boolean",
                Jammed = "boolean", Ready = "boolean", TriggerDown = "boolean", NeedTriggerPress = "boolean",
                UBGL = "boolean", EmptyReload = "boolean", InSights = "boolean", PrimedAttack = "boolean",
                Bash2 = "boolean", NeedsCycle = "boolean", Bipod = "boolean", HeatLockout = "boolean",
                LastWasSprinting = "boolean", RequestReload = "boolean", InMeleeAttack = "boolean",
                OutOfBreath = "boolean", Inspecting = "boolean", AfterShot = "boolean", GrenadePrimed = "boolean",
                GrenadeTossing = "boolean", GrenadeRecovering = "boolean", LockedOn = "boolean",
                Backstab = "boolean", DoAFastDraw = "boolean", NoPresets = "boolean", IsStatue = "boolean",
                FreeAimAngle = "angle", LastAimAngle = "angle", BipodAng = "angle",
                VisualRecoilPos = "vector", VisualRecoilPosVel = "vector", VisualRecoilPosAcc = "vector",
                BipodPos = "vector", VisualRecoilAng = "vector", VisualRecoilVel = "vector", VisualRecoilAcc = "vector",
                IKAnimation = "string", Holster_Entity = "entity", LungeEntity = "entity", ShieldEntity = "entity",
                LockOnTarget = "entity", DetonatorEntity = "entity"
            }

            -- Metatable fallback to dynamically mock any missing DT variables (Get/Set methods) on the Lua table
            local mockDT = {}
            setmetatable(mockDT, {
                __index = function(tbl, key)
                    if key == "Firemode" or key == "MultiSight" then return 1
                    elseif key == "Breath" then return 100
                    end
                    local t = dtTypes[key]
                    if t == "number" then return 0
                    elseif t == "boolean" then return false
                    elseif t == "string" then return ""
                    elseif t == "angle" then return Angle(0, 0, 0)
                    elseif t == "vector" then return Vector(0, 0, 0)
                    end
                    return nil
                end
            })
            wepEnt.dt = mockDT
            local fallbackMeta = {
                __index = function(s, key)
                    if string.StartsWith(key, "Get") then
                        local varName = string.sub(key, 4)
                        return function() 
                            if mockDT[key] ~= nil then return mockDT[key] end
                            if key == "GetCustomize" then return true end
                            if key == "GetFiremode" or key == "GetMultiSight" then return 1 end
                            if key == "GetBreath" then return 100 end
                            
                            local t = dtTypes[varName]
                            if t == "number" then return 0
                            elseif t == "boolean" then return false
                            elseif t == "string" then return ""
                            elseif t == "angle" then return Angle(0, 0, 0)
                            elseif t == "vector" then return Vector(0, 0, 0)
                            end
                            return nil
                        end
                    elseif string.StartsWith(key, "Set") then
                        return function(self, val) 
                            mockDT[key] = val 
                        end
                    end
                    
                    if base and base[key] ~= nil then
                        return base[key]
                    end

                    if baseClass and baseClass[key] ~= nil then
                        return baseClass[key]
                    end
                    
                    return nil
                end
            }
            setmetatable(wepEnt:GetTable(), fallbackMeta)

            -- Initialize simulated weapon
            if wepEnt.Initialize then wepEnt:Initialize() end
            
            -- Apply currently selected attachments to the preview entity
            local atts = self.CurrentLoadout.attachments[self.SelectedWeaponClass]
            if atts then
                for slotStr, att in pairs(atts) do
                    local slotIdx = tonumber(slotStr)
                    if slotIdx and att and att ~= "" then
                        if wepEnt.Attach then
                            wepEnt:Attach(slotIdx, att, true)
                        end
                    end
                end
            end

            -- Force ARC9 to build the customization/clientside attachment models
            if wepEnt.KillModel then wepEnt:KillModel() end
            if wepEnt.SetupModel then 
                wepEnt:SetupModel(true, 0, true) 
                print("[Loadout Debug] SetupModel run. CModel count: ", wepEnt.CModel and #wepEnt.CModel or "nil")
            end
            
            modelPanel.Entity = wepEnt
        else
            print("[Loadout Debug] Spawning clientside entity failed.")
        end

        modelPanel.OnRemove = function(s)
            if IsValid(s.Entity) then
                if s.Entity.KillModel then s.Entity:KillModel() end
                s.Entity:Remove()
            end
        end

        -- Customize Paint to draw ARC9 customization models (CModel) in 3D scene
        modelPanel.Paint = function(s, w, h)
            if not IsValid(s.Entity) then return end

            local x, y = s:LocalToScreen(0, 0)

            -- Get camera positioning parameters defined on the base weapon stats
            local campos = Vector(0, 0, 0)
            local camang = Angle(0, 0, 0)
            
            local custpos = s.Entity:GetProcessedValue("CustomizePos", true) or Vector(0, 0, 0)
            local snapshotpos = s.Entity.CustomizeSnapshotPos or s.Entity:GetProcessedValue("CustomizeSnapshotPos", true) or Vector(0, 0, 0)
            custpos = custpos + snapshotpos
            
            local custang = s.Entity:GetProcessedValue("CustomizeAng", true) or Angle(0, 0, 0)
            local snapshotang = s.Entity.CustomizeSnapshotAng or s.Entity:GetProcessedValue("CustomizeSnapshotAng", true) or Angle(0, 0, 0)
            custang = custang + snapshotang
            
            local fov = (s.Entity:GetProcessedValue("CustomizeSnapshotFOV") or s.Entity:GetProcessedValue("CustomizeFOV") or 35) * 0.65 * (s.ZoomFactor or 1)

            local pos = Vector(0, 0, 0)
            local ang = Angle(0, 0, 0)

            -- Combine CustomizeAng offset with mouse drag rotation
            local activeAng = Angle(ang.p + custang[2] + s.DragAng.p, ang.y + custang[1] + s.DragAng.y, ang.r + custang[3] + s.DragAng.r)

            -- Compute camera relative offset position of the weapon based on CustomizePos and DragOffset panning
            local dragOffset = s.DragOffset or Vector(0, 0, 0)
            local modelPos = pos + (camang:Right() * (custpos[1] + dragOffset.y)) + (camang:Forward() * custpos[2]) + (camang:Up() * (custpos[3] + dragOffset.z))

            cam.Start3D(campos, camang, fov, x, y, w, h, 1, 1024)
                render.SuppressEngineLighting(true)
                render.SetLightingOrigin(modelPos)
                render.ResetModelLighting(s.colAmbientLight.r / 255, s.colAmbientLight.g / 255, s.colAmbientLight.b / 255)
                
                for i = 0, 6 do
                    local col = s.DirectionalLight[i]
                    if col then
                        render.SetModelLighting(i, col.r / 255, col.g / 255, col.b / 255)
                    end
                end

                -- Force bones to setup on the main entity and invalidate cache
                s.Entity:SetupBones()
                s.Entity:InvalidateBoneCache()

                -- Force attachment positions to recalculate by clearing optimized cache and rebuilding bones
                if s.Entity.CModel then
                    for _, m in ipairs(s.Entity.CModel) do
                        m.OptimizPrevWMPos = nil
                        if IsValid(m) then
                            m:SetupBones()
                            m:InvalidateBoneCache()
                        end
                    end
                end

                -- Draw the customization models containing attachments
                if s.Entity.DrawCustomModel then
                    s.Entity:DrawCustomModel(true, modelPos, activeAng)
                else
                    s.Entity:SetPos(modelPos)
                    s.Entity:SetAngles(activeAng)
                    s.Entity:DrawModel()
                end

                render.SuppressEngineLighting(false)
            cam.End3D()
        end

        local slots = wepTable and wepTable.Attachments or {}

        local savedScroll = 0
        local function rebuildBottom()
            -- Save current horizontal scroll position
            if IsValid(bottomPanel.scroll) and IsValid(bottomPanel.scroll:GetVBar()) then
                savedScroll = bottomPanel.scroll:GetVBar():GetScroll() or 0
            end

            bottomPanel:Clear()

            if #slots == 0 then
                local noSlots = bottomPanel:Add("DLabel")
                noSlots:SetFont(Nexus:GetFont({size = 16}))
                noSlots:SetText("No customization slots available for this weapon.")
                noSlots:SetTextColor(Color(140, 140, 140))
                noSlots:Dock(FILL)
                noSlots:SetContentAlignment(5)
                return
            end

            local scroll = bottomPanel:Add("Nexus:V2:HorizontalScrollPanel")
            scroll:Dock(FILL)
            scroll:DockMargin(Nexus:GetScale(15), Nexus:GetScale(15), Nexus:GetScale(15), Nexus:GetScale(15))
            bottomPanel.scroll = scroll

            local addedPanels = {}
            local function addPanel(pnl)
                table.insert(addedPanels, pnl)
            end

            if not self.SelectedAttSlot then
                -- Show Slot Categories
                for slotIdx, slot in ipairs(slots) do
                    if slot.Hidden then continue end
                    local slotName = slot.PrintName or ("Slot " .. slotIdx)
                    self.CurrentLoadout.attachments[self.SelectedWeaponClass] = self.CurrentLoadout.attachments[self.SelectedWeaponClass] or {}
                    local equippedAtt = getEquippedAttachment(self.CurrentLoadout, self.SelectedWeaponClass, slotIdx)

                    local card = vgui.Create("Nexus:V2:Button", scroll)
                    card:SetWide(Nexus:GetScale(130))
                    card:SetText("")
                    card.Paint = function(s, w, h)
                        local isHover = s:IsHovered()
                        local bgCol = isHover and Color(30, 30, 40, 200) or Color(20, 20, 28, 150)
                        surface.SetDrawColor(bgCol.r, bgCol.g, bgCol.b, bgCol.a)
                        surface.SetMaterial(miniBackgroundMat)
                        surface.DrawTexturedRect(0, 0, w, h)
                        
                        draw.SimpleText(string.upper(slotName), Nexus:GetFont({size = 13, bold = true}), w/2, h/2 - 12, Nexus:GetColor("red"), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                        
                        local curText = "NONE"
                        if equippedAtt and equippedAtt ~= "" then
                            curText = ARC9:GetPhraseForAtt(equippedAtt, "PrintName") or equippedAtt
                        end
                        
                        local font = Nexus:GetFont({size = 11, font="Lato"})
                        local lines = wrapText(curText, font, w - Nexus:GetScale(10))
                        local startY = h/2 + 5
                        for idx, line in ipairs(lines) do
                            draw.SimpleText(line, font, w/2, startY + (idx - 1) * Nexus:GetScale(13), Color(200, 200, 200), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
                        end
                    end
                    card.DoClick = function()
                        self.SelectedAttSlot = slotIdx
                        savedScroll = 0 -- Reset scroll when entering new category
                        rebuildBottom()
                    end
                    addPanel(card)
                end
            else
                -- Show Attachments for the selected Slot Category
                local slotIdx = self.SelectedAttSlot
                local slot = slots[slotIdx]
                local slotName = slot.PrintName or ("Slot " .. slotIdx)

                -- Back Button Card
                local backCard = vgui.Create("Nexus:V2:Button", scroll)
                backCard:SetWide(Nexus:GetScale(80))
                backCard:SetText("")
                backCard.Paint = function(s, w, h)
                    local isHover = s:IsHovered()
                    local bgCol = isHover and Color(60, 20, 20, 200) or Color(40, 15, 15, 150)
                    surface.SetDrawColor(bgCol.r, bgCol.g, bgCol.b, bgCol.a)
                    surface.SetMaterial(miniBackgroundMat)
                    surface.DrawTexturedRect(0, 0, w, h)
                    draw.SimpleText("BACK", Nexus:GetFont({size = 14, bold = true}), w/2, h/2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                end
                backCard.DoClick = function()
                    self.SelectedAttSlot = nil
                    savedScroll = 0 -- Reset scroll when going back to categories
                    rebuildBottom()
                end
                addPanel(backCard)

                -- NONE (Unequip) Button Card
                local equippedAtt = getEquippedAttachment(self.CurrentLoadout, self.SelectedWeaponClass, slotIdx)
                local noneCard = vgui.Create("Nexus:V2:Button", scroll)
                noneCard:SetWide(Nexus:GetScale(130))
                noneCard:SetText("")
                noneCard.Paint = function(s, w, h)
                    local isHover = s:IsHovered()
                    local isEquipped = (not equippedAtt or equippedAtt == "")
                    local bgCol = isEquipped and Color(180, 50, 50, 100) or (isHover and Color(30, 30, 40, 200) or Color(20, 20, 28, 150))
                    surface.SetDrawColor(bgCol.r, bgCol.g, bgCol.b, bgCol.a)
                    surface.SetMaterial(miniBackgroundMat)
                    surface.DrawTexturedRect(0, 0, w, h)
                    draw.SimpleText("NONE", Nexus:GetFont({size = 13, bold = true}), w/2, h/2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                end
                noneCard.DoClick = function()
                    clearEquippedAttachment(self.CurrentLoadout, self.SelectedWeaponClass, slotIdx)
                    savePrefs(self.CurrentLoadout)
                    self:SyncLoadout()
                    
                    -- Rebuild the 3D model attachments instantly
                    if IsValid(modelPanel.Entity) then
                        if modelPanel.Entity.Attach then
                            modelPanel.Entity:Attach(slotIdx, nil, true)
                        end
                        if modelPanel.Entity.KillModel then modelPanel.Entity:KillModel() end
                        if modelPanel.Entity.SetupModel then modelPanel.Entity:SetupModel(true, 0, true) end
                    end
                    
                    rebuildBottom()
                end

                local noneCardWasHovered = false
                noneCard.Think = function(s)
                    local isHovered = s:IsHovered()
                    if isHovered ~= noneCardWasHovered then
                        noneCardWasHovered = isHovered
                        if isHovered then
                            if IsValid(modelPanel.Entity) then
                                local prevAtt = nil
                                if modelPanel.Entity.Attachments[slotIdx] then
                                    prevAtt = modelPanel.Entity.Attachments[slotIdx].Installed
                                    modelPanel.Entity.Attachments[slotIdx].Installed = nil
                                    if modelPanel.Entity.InvalidateCache then modelPanel.Entity:InvalidateCache() end
                                    if modelPanel.Entity.DoInvalidateCache then modelPanel.Entity:DoInvalidateCache() end
                                end
                                
                                self.HoveredStats = GetStats(modelPanel.Entity)
                                
                                if modelPanel.Entity.Attachments[slotIdx] then
                                    modelPanel.Entity.Attachments[slotIdx].Installed = prevAtt
                                    if modelPanel.Entity.InvalidateCache then modelPanel.Entity:InvalidateCache() end
                                    if modelPanel.Entity.DoInvalidateCache then modelPanel.Entity:DoInvalidateCache() end
                                end
                            end
                        else
                            self.HoveredStats = nil
                        end
                    end
                end
                addPanel(noneCard)

                -- Compatible Attachments Cards
                local compat = GetAttachmentsForCategories(slot.Category)
                for _, att in ipairs(compat) do
                    local isAttUnlocked = Nexus.Proc.Weapons:IsAttachmentUnlocked(LocalPlayer(), att.shortname)
                    local isEquipped = (equippedAtt == att.shortname)
                    
                    local attCard = vgui.Create("Nexus:V2:Button", scroll)
                    attCard:SetWide(Nexus:GetScale(130))
                    attCard:SetText("")

                    attCard.Paint = function(s, w, h)
                        local isHover = s:IsHovered()
                        local bgCol = Color(20, 20, 28, 150)
                        if isEquipped then
                            bgCol = Color(180, 50, 50, 150)
                        elseif not isAttUnlocked then
                            bgCol = Color(10, 10, 12, 100)
                        elseif isHover then
                            bgCol = Color(30, 30, 40, 200)
                        end

                        surface.SetDrawColor(bgCol.r, bgCol.g, bgCol.b, bgCol.a)
                        surface.SetMaterial(miniBackgroundMat)
                        surface.DrawTexturedRect(0, 0, w, h)

                        local font = Nexus:GetFont({size = 11, bold = true, font="Lato"})
                        local lines = wrapText(att.name, font, w - Nexus:GetScale(10))
                        
                        -- Draw each line centered horizontally
                        local startY = h - (#lines * Nexus:GetScale(13)) - Nexus:GetScale(15)
                        if not isAttUnlocked or isEquipped then
                            startY = startY - Nexus:GetScale(10) -- make room for locked/equipped tag
                        end
                        for idx, line in ipairs(lines) do
                            draw.SimpleText(line, font, w/2, startY + (idx - 1) * Nexus:GetScale(13), color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
                        end

                        if not isAttUnlocked then
                            local price = Nexus.Proc.Weapons:GetAttachmentPrice(att.shortname)
                            draw.SimpleText("$" .. price, Nexus:GetFont({size = 9, bold = true}), w/2, h - Nexus:GetMargin(), Color(255, 200, 50), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
                        elseif isEquipped then
                            draw.SimpleText("EQUIPPED", Nexus:GetFont({size = 9, bold = false}), w/2, h - Nexus:GetMargin(), Color(220, 220, 220), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
                        end
                    end
                    
                    -- Spawn rotating 3D model preview or 2D fallback icon inside the card
                    local attTable = ARC9.Attachments[att.shortname]
                    local attModel = attTable and (attTable.Model or attTable.ModelPath)
                    
                    if attModel and attModel ~= "" then
                        local iconModel = vgui.Create("DModelPanel", attCard)
                        iconModel:SetSize(Nexus:GetScale(120), Nexus:GetScale(90))
                        iconModel:SetPos(Nexus:GetScale(5), Nexus:GetScale(5))
                        iconModel:SetModel(attModel)
                        iconModel:SetFOV(40)
                        iconModel:SetCamPos(Vector(12, 12, 8))
                        iconModel:SetLookAt(Vector(0, 0, 0))
                        iconModel.LayoutEntity = function() end
                        iconModel:SetMouseInputEnabled(false)
                    else
                        local iconMat = attTable and attTable.Icon
                        if iconMat then
                            local iconImg = vgui.Create("DImage", attCard)
                            iconImg:SetSize(Nexus:GetScale(100), Nexus:GetScale(80))
                            iconImg:SetPos(Nexus:GetScale(15), Nexus:GetScale(10))
                            iconImg:SetMaterial(iconMat)
                            iconImg:SetMouseInputEnabled(false)
                        end
                    end
                    
                    local attCardWasHovered = false
                    attCard.Think = function(s)
                        local isHovered = s:IsHovered()
                        if isHovered ~= attCardWasHovered then
                            attCardWasHovered = isHovered
                            if isHovered then
                                if IsValid(modelPanel.Entity) then
                                    local prevAtt = nil
                                    if modelPanel.Entity.Attachments[slotIdx] then
                                        prevAtt = modelPanel.Entity.Attachments[slotIdx].Installed
                                        modelPanel.Entity.Attachments[slotIdx].Installed = att.shortname
                                        if modelPanel.Entity.InvalidateCache then modelPanel.Entity:InvalidateCache() end
                                        if modelPanel.Entity.DoInvalidateCache then modelPanel.Entity:DoInvalidateCache() end
                                    end
                                    
                                    self.HoveredStats = GetStats(modelPanel.Entity)
                                    self.HoveredAttTable = attTable
                                    
                                    if modelPanel.Entity.Attachments[slotIdx] then
                                        modelPanel.Entity.Attachments[slotIdx].Installed = prevAtt
                                        if modelPanel.Entity.InvalidateCache then modelPanel.Entity:InvalidateCache() end
                                        if modelPanel.Entity.DoInvalidateCache then modelPanel.Entity:DoInvalidateCache() end
                                    end
                                end
                            else
                                self.HoveredStats = nil
                                self.HoveredAttTable = nil
                            end
                        end
                    end

                    attCard.DoClick = function()
                        if not isAttUnlocked then
                            local cost = Nexus.Proc.Weapons:GetAttachmentPrice(att.shortname)
                            local coins = Nexus.Proc.Weapons and Nexus.Proc.Weapons.Coins or 0
                            if coins < cost then
                                Nexus:QueryPopup(
                                    "You need $" .. cost .. " coins to unlock this attachment!\nYou only have $" .. coins .. ". Earn more by killing spiders.",
                                    function() end, function() end,
                                    "OK", "Close"
                                )
                            else
                                Nexus:QueryPopup(
                                    "Buy " .. att.name .. " for $" .. cost .. " coins?\nYou have $" .. coins .. ".",
                                    function()
                                        net.Start("Nexus:Loadin:BuyAttachment")
                                        net.WriteString(att.shortname)
                                        net.SendToServer()
                                    end,
                                    function() end,
                                    "Buy ($" .. cost .. ")",
                                    "Cancel"
                                )
                            end
                            return
                        end

                        self.CurrentLoadout.attachments[self.SelectedWeaponClass][tostring(slotIdx)] = att.shortname
                        savePrefs(self.CurrentLoadout)
                        self:SyncLoadout()

                        -- Rebuild the 3D model attachments instantly
                        if IsValid(modelPanel.Entity) then
                            if modelPanel.Entity.Attach then
                                modelPanel.Entity:Attach(slotIdx, att.shortname, true)
                            end
                            if modelPanel.Entity.KillModel then modelPanel.Entity:KillModel() end
                            if modelPanel.Entity.SetupModel then modelPanel.Entity:SetupModel(true, 0, true) end
                        end

                        rebuildBottom()
                    end
                    addPanel(attCard)
                end
            end

            -- Layout the panels side-by-side inside the scroll canvas via PerformLayout
            scroll:GetCanvas().PerformLayout = function(s, w, h)
                local x = 0
                local spacing = Nexus:GetScale(15)
                local children = s:GetChildren()

                for _, pnl in ipairs(children) do
                    pnl:SetPos(x, 0)
                    pnl:SetTall(h)
                    x = x + pnl:GetWide() + spacing
                end
                s:SetWide(x - spacing)

                -- Call parent setup to calculate scroll bounds
                scroll:PerformLayoutInternal()
            end

            if savedScroll > 0 and IsValid(scroll:GetVBar()) then
                scroll:GetVBar():SetScroll(savedScroll)
            end

            hideCursorRecursive(bottomPanel)
        end

        rebuildBottom()
    end

    -- Floating back button in the top left
    local backBtnMat = Material("small-404-316.png")
    local backBtn = self:Add("Nexus:V2:Button")
    backBtn:SetText("BACK")
    backBtn:SetFont(Nexus:GetFont({size = 18, bold = true}))
    backBtn:SetSize(Nexus:GetScale(70), Nexus:GetScale(55))
    backBtn:SetPos(Nexus:GetScale(20), Nexus:GetScale(20))
    backBtn:SetCursor("blank")
    backBtn.Paint = function(s, w, h)
        surface.SetDrawColor(255, 255, 255, s:IsHovered() and 95 or 50)
        surface.SetMaterial(backBtnMat)
        surface.DrawTexturedRect(0, 0, w, h)
        draw.SimpleText(s:GetText(), s:GetFont(), w/2, h/2, Nexus:GetTextColor(color_white), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    backBtn.DoClick = function()
        self:AlphaTo(0, 0.4, 0, function()
            if IsValid(self) then self:Remove() end
        end)
    end

    -- Coin balance display (top right)
    local coinLabel = self:Add("DLabel")
    coinLabel:SetText("")
    coinLabel:SetPos(0, Nexus:GetScale(20) + Nexus:GetScale(55)/2 - Nexus:GetScale(15))
    coinLabel:SetSize(Nexus:GetScale(220), Nexus:GetScale(30))
    coinLabel:SetFont(Nexus:GetFont({size = 18, bold = true}))
    coinLabel:SetContentAlignment(6) -- right
    coinLabel.Think = function(s)
        local coins = Nexus.Proc.Weapons and Nexus.Proc.Weapons.Coins or 0
        s:SetText("$" .. coins .. " Coins")
        s:SetTextColor(Color(255, 215, 0))
    end
    coinLabel.Paint = function(s, w, h) end -- suppress default background

    self.RebuildWeaponList()
    self.RebuildRightPanel()

    hideCursorRecursive(self)
end

function PANEL:SyncLoadout()
    net.Start("Nexus:Loadin:UpdateLoadout")
    net.WriteTable(self.CurrentLoadout)
    net.SendToServer()
end

function PANEL:Think()
    -- Enable custom blank/hand cursor on dropdown menus
    for _, child in ipairs(self:GetChildren()) do
        if child.GetChildren then
            for _, subChild in ipairs(child:GetChildren()) do
                if subChild.ClassName == "DComboBox" and IsValid(subChild._DermaMenu) then
                    local menu = subChild._DermaMenu
                    if not menu.CursorSetToBlank then
                        menu.CursorSetToBlank = true
                        hideCursorRecursive(menu)
                        local cursorMat = Material("hand.png")
                        menu.PaintOver = function(s, w, h)
                            local mx, my = gui.MousePos()
                            local x, y = s:ScreenToLocal(mx, my)
                            local handSize = Nexus:GetScale(32)
                            surface.SetDrawColor(255, 255, 255, 255)
                            surface.SetMaterial(cursorMat)
                            surface.DrawTexturedRect(x - handSize * 0.5, y - handSize * 0.5, handSize, handSize)
                        end
                  
                    end
                end
            end
        end
    end
end

function PANEL:Paint(w, h)
    local bgColor = Nexus:GetColor("background")
        Nexus.RNDX.Draw(0, 0, 0, w, h, bgColor)
end

local cursorMat = Material("hand.png")

function PANEL:PaintOver(w, h)
    local mx, my = gui.MousePos()
    local x, y = self:ScreenToLocal(mx, my)

    local handSize = Nexus:GetScale(32)
    local cx = x
    local cy = y

    -- Bloody cursor trail on movement
    local dx = x - self.LastCursorPos.x
    local dy = y - self.LastCursorPos.y
    local dist = math.sqrt(dx*dx + dy*dy)
    if dist > Nexus:GetScale(6) then
        table.insert(self.CursorTrails, {
            x = cx,
            y = cy,
            size = Nexus:GetScale(math.random(2, 4)),
            life = 1.2
        })
        self.LastCursorPos = {x = x, y = y}
    end

    -- Dripping blood periodically
    if CurTime() > self.NextDrip then
        self.NextDrip = CurTime() + math.random(0.1, 0.25)
        table.insert(self.CursorDrips, {
            x = cx + math.random(Nexus:GetScale(-4), Nexus:GetScale(4)),
            y = cy + handSize * 0.5,
            speedY = Nexus:GetScale(math.random(120, 240)),
            speedX = Nexus:GetScale(math.random(-15, 15)),
            size = Nexus:GetScale(math.random(1, 2)),
            life = 1.0
        })
    end

    -- Draw trails
    for i = #self.CursorTrails, 1, -1 do
        local trail = self.CursorTrails[i]
        trail.life = trail.life - FrameTime()
        if trail.life <= 0 then
            table.remove(self.CursorTrails, i)
        else
            local alpha = (trail.life / 1.2) * 180
            draw.RoundedBox(trail.size / 2, trail.x - trail.size/2, trail.y - trail.size/2, trail.size, trail.size, Color(130, 10, 10, alpha))
        end
    end

    -- Draw drips with gravity
    for i = #self.CursorDrips, 1, -1 do
        local drip = self.CursorDrips[i]
        drip.life = drip.life - FrameTime()
        if drip.life <= 0 then
            table.remove(self.CursorDrips, i)
        else
            drip.y = drip.y + drip.speedY * FrameTime()
            drip.x = drip.x + drip.speedX * FrameTime()
            drip.speedY = drip.speedY + Nexus:GetScale(350) * FrameTime()
            local alpha = (drip.life / 1.0) * 220
            draw.RoundedBox(drip.size / 2, drip.x - drip.size/2, drip.y - drip.size/2, drip.size, drip.size, Color(150, 12, 12, alpha))
        end
    end

    -- Draw main hand cursor (centered on cursor coordinates)
    surface.SetDrawColor(255, 255, 255, 255)
    surface.SetMaterial(cursorMat)
    surface.DrawTexturedRect(x - handSize * 0.5, y - handSize * 0.5, handSize, handSize)
end
vgui.Register("Nexus:Proc:WeaponsMenu", PANEL, "EditablePanel")
