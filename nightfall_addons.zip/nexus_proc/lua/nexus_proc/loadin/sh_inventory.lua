-- sh_inventory.lua
-- Client-server inventory system for carryable items

if SERVER then
    util.AddNetworkString("Nexus:Inventory:Sync")
    util.AddNetworkString("Nexus:Inventory:Drop")

    -- Clean/initialize inventory for player
    function Nexus.Proc.InitPlayerInventory(ply)
        ply.NexusInventory = { [1] = nil, [2] = nil, [3] = nil }
        net.Start("Nexus:Inventory:Sync")
        net.WriteTable(ply.NexusInventory)
        net.Send(ply)
    end

    hook.Add("PlayerInitialSpawn", "NexusInventoryInitOnSpawn", function(ply)
        Nexus.Proc.InitPlayerInventory(ply)
    end)

    -- Intercept E (Use) on carryable entities to pick them up
    hook.Add("PlayerUse", "NexusInventoryPickup", function(ply, ent)
        if not IsValid(ent) then return end
        local class = ent:GetClass()
        if class == "nexus_drum" or class == "nexus_engine" then
            local state = GetGlobalInt("NightFall:RoundState", 0)
            if state ~= 2 --[[ ROUND_ACTIVE ]] then return end
            if not ply:Alive() or ply:Team() == TEAM_SPECTATOR then return end

            ply.NexusInventory = ply.NexusInventory or { [1] = nil, [2] = nil, [3] = nil }
            local pickedUp = false
            for i = 1, 3 do
                if ply.NexusInventory[i] == nil then
                    ply.NexusInventory[i] = class
                    ent:Remove()
                    pickedUp = true
                    
                    -- Sync to client
                    net.Start("Nexus:Inventory:Sync")
                    net.WriteTable(ply.NexusInventory)
                    net.Send(ply)

                    ply:EmitSound("physics/metal/metal_box_impact_bullet1.wav", 75, 120)
                    PrintMessage(HUD_PRINTTALK, "[Inventory] " .. ply:Nick() .. " picked up " .. (class == "nexus_drum" and "an Oil Drum" or "an Engine") .. ".")
                    break
                end
            end

            if not pickedUp then
                ply:ChatPrint("[Inventory] Your inventory is full!")
            end
            return false -- Suppress default pickup
        end
    end)

    -- Handle dropping items via network message
    net.Receive("Nexus:Inventory:Drop", function(len, ply)
        if not IsValid(ply) or not ply:Alive() or ply:Team() == TEAM_SPECTATOR then return end
        local slot = net.ReadUInt(4)
        if not slot or slot < 1 or slot > 3 then return end

        ply.NexusInventory = ply.NexusInventory or { [1] = nil, [2] = nil, [3] = nil }
        local class = ply.NexusInventory[slot]
        if class then
            ply.NexusInventory[slot] = nil

            -- Spawn the entity at the player's position to prevent clipping through walls
            local dropEnt = ents.Create(class)
            if IsValid(dropEnt) then
                local spawnPos = ply:GetPos() + Vector(0, 0, 10)
                dropEnt:SetPos(spawnPos)
                dropEnt:SetAngles(Angle(0, ply:GetAngles().y, 0)) -- drop flat on the ground relative to player heading
                dropEnt:Spawn()
                dropEnt:Activate()

                -- Apply a small drop wiggle/physics wake
                local phys = dropEnt:GetPhysicsObject()
                if IsValid(phys) then
                    phys:Wake()
                end
            end

            -- Sync to client
            net.Start("Nexus:Inventory:Sync")
            net.WriteTable(ply.NexusInventory)
            net.Send(ply)

            ply:EmitSound("physics/metal/metal_box_impact_bullet1.wav", 70, 90)
            PrintMessage(HUD_PRINTTALK, "[Inventory] " .. ply:Nick() .. " dropped " .. (class == "nexus_drum" and "an Oil Drum" or "an Engine") .. ".")
        end
    end)
end

if CLIENT then
    local miniBg = Material("mini_rectangle_background.png")
    local selectedSlot = 1
    local inventory = { [1] = nil, [2] = nil, [3] = nil }

    net.Receive("Nexus:Inventory:Sync", function()
        inventory = net.ReadTable() or { [1] = nil, [2] = nil, [3] = nil }
    end)

    local cursorToggled = false

    -- Key hooks for ALT + 1/2/3, G, and F3
    hook.Add("PlayerButtonDown", "NexusInventoryKeys", function(ply, button)
        if not IsFirstTimePredicted() then return end
        
        local altHeld = input.IsKeyDown(KEY_LALT) or input.IsKeyDown(KEY_RALT)
        if altHeld then
            if button == KEY_1 then
                selectedSlot = 1
                surface.PlaySound("common/talk.wav")
            elseif button == KEY_2 then
                selectedSlot = 2
                surface.PlaySound("common/talk.wav")
            elseif button == KEY_3 then
                selectedSlot = 3
                surface.PlaySound("common/talk.wav")
            end
        elseif button == KEY_G then
            -- Ensure player isn't typing in chat or menu
            if gui.IsGameUIVisible() or gui.IsConsoleVisible() then return end
            if inventory[selectedSlot] then
                net.Start("Nexus:Inventory:Drop")
                net.WriteUInt(selectedSlot, 4)
                net.SendToServer()
            end
        elseif button == KEY_F3 then
            if gui.IsGameUIVisible() or gui.IsConsoleVisible() then return end
            cursorToggled = not cursorToggled
            gui.EnableScreenClicker(cursorToggled)
            surface.PlaySound("common/talk.wav")
        end
    end)

    local wasMouseDown = false

    -- Draw the 3 slots at the bottom center of the screen
    hook.Add("HUDPaint", "NexusInventoryHUD", function()
        local ply = LocalPlayer()
        if not IsValid(ply) or not ply:Alive() or ply:Team() == TEAM_SPECTATOR then return end
        
        local state = GetGlobalInt("NightFall:RoundState", 0)
        if state == 3 or state == 4 then return end

        local slotW, slotH = Nexus:GetScale(70), Nexus:GetScale(70)
        local spacing = Nexus:GetScale(15)
        local totalW = (3 * slotW) + (2 * spacing)
        local startX = (ScrW() - totalW) / 2
        local startY = ScrH() - slotH - Nexus:GetScale(30)

        -- Track mouse click state in HUDPaint
        local isMouseDown = input.IsMouseDown(MOUSE_LEFT) or input.IsMouseDown(MOUSE_RIGHT)
        local clicked = isMouseDown and not wasMouseDown
        wasMouseDown = isMouseDown

        for i = 1, 3 do
            local x = startX + (i - 1) * (slotW + spacing)
            
            -- Detect hover when cursor is active (e.g. scoreboard is open)
            local isHovered = false
            if vgui.CursorVisible() then
                local mx, my = gui.MousePos()
                isHovered = mx >= x and mx <= x + slotW and my >= startY and my <= startY + slotH
            end

            -- Slot background
            surface.SetMaterial(miniBg)
            surface.SetDrawColor(180, 180, 180, 180)
            surface.DrawTexturedRect(x, startY, slotW, slotH)

            -- Hover overlay & click handler
            if isHovered then
                surface.SetDrawColor(255, 255, 255, 40)
                surface.DrawRect(x, startY, slotW, slotH)

                if clicked and inventory[i] then
                    net.Start("Nexus:Inventory:Drop")
                    net.WriteUInt(i, 4)
                    net.SendToServer()
                    surface.PlaySound("common/talk.wav")
                end
            end

            -- Slot Index Label
            draw.SimpleText(tostring(i), Nexus:GetFont({size = 11, bold = true}), x + Nexus:GetScale(8), startY + Nexus:GetScale(8), Color(0, 0, 0, 220), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

            -- Item representation
            local itemClass = inventory[i]
            if itemClass then
                local displayName = (itemClass == "nexus_drum") and "Drum" or "Engine"
                
                draw.SimpleText(displayName, Nexus:GetFont({size = 15, bold = true}), x + slotW / 2, startY + slotH / 2, Color(0, 0, 0, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            else
                draw.SimpleText("Empty", Nexus:GetFont({size = 10, bold = false}), x + slotW / 2, startY + slotH / 2, Color(0, 0, 0, 130), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
        end
    end)
end
