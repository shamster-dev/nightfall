-- cl_perk_menu.lua
-- Fullscreen interactive Perk Tree UI for the Nexus load-in menu.

local cursorMat = Material("hand.png")
local nodeBgMat = Material("mini_rectangle_background.png")
local PANEL = {}

function PANEL:Init()
    self:SetSize(ScrW(), ScrH())
    self:SetPos(0, 0)
    self:SetCursor("blank")
    self:SetAlpha(0)
    self:AlphaTo(255, 0.25, 0)

    self.CursorTrails = {}
    self.CursorDrips = {}
    self.LastCursorPos = {x = 0, y = 0}
    self.NextDrip = 0

    -- Panning offset variables for draggability
    self.OffsetX = 0
    self.OffsetY = 0
    self.Dragging = false
    self:SetMouseInputEnabled(true)
    self:MakePopup()

    -- Back Button
    local backBtnMat = Material("small-404-316.png")
    local backBtn = self:Add("Nexus:V2:Button")
    backBtn:SetText("BACK")
    backBtn:SetFont(Nexus:GetFont({size = 18, bold = true}))
    backBtn:SetSize(Nexus:GetScale(70), Nexus:GetScale(55))
    backBtn:SetPos(Nexus:GetScale(20), Nexus:GetScale(20))
    backBtn:SetCursor("blank")
    backBtn.Paint = function(s, w, h)
        surface.SetDrawColor(255, 255, 255, s:IsHovered() and 255 or 150)
        surface.SetMaterial(backBtnMat)
        surface.DrawTexturedRect(0, 0, w, h)

        draw.SimpleText(s:GetText(), s:GetFont(), w/2, h/2, Nexus:GetColor("background"), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    backBtn.DoClick = function()
        surface.PlaySound("ambient/machines/keyboard7_clicks.wav")
        self:AlphaTo(0, 0.2, 0, function()
            self:Remove()
            if IsValid(Nexus.Proc.LoadinMenuPanel) then
                -- Re-enable buttons on the main lobby menu
                if IsValid(Nexus.Proc.LoadinMenuPanel.PlayBtn) then Nexus.Proc.LoadinMenuPanel.PlayBtn:SetVisible(true) Nexus.Proc.LoadinMenuPanel.PlayBtn:SetEnabled(true) end
                if IsValid(Nexus.Proc.LoadinMenuPanel.WeaponsBtn) then Nexus.Proc.LoadinMenuPanel.WeaponsBtn:SetVisible(true) Nexus.Proc.LoadinMenuPanel.WeaponsBtn:SetEnabled(true) end
                if IsValid(Nexus.Proc.LoadinMenuPanel.LeaveBtn) then Nexus.Proc.LoadinMenuPanel.LeaveBtn:SetVisible(true) Nexus.Proc.LoadinMenuPanel.LeaveBtn:SetEnabled(true) end
                if IsValid(Nexus.Proc.LoadinMenuPanel.PerksBtn) then Nexus.Proc.LoadinMenuPanel.PerksBtn:SetVisible(true) Nexus.Proc.LoadinMenuPanel.PerksBtn:SetEnabled(true) end
            end
        end)
    end

    -- Create perk nodes
    self.Nodes = {}
    self:Refresh()
end

function PANEL:OnMousePressed(mouseCode)
    if mouseCode == MOUSE_LEFT then
        self.Dragging = true
        self.DragStartX, self.DragStartY = input.GetCursorPos()
    end
end

function PANEL:OnMouseReleased(mouseCode)
    if mouseCode == MOUSE_LEFT then
        self.Dragging = false
    end
end

function PANEL:Think()
    if self.Dragging then
        local mx, my = input.GetCursorPos()
        local dx = mx - self.DragStartX
        local dy = my - self.DragStartY

        self.OffsetX = (self.OffsetX or 0) + dx
        self.OffsetY = (self.OffsetY or 0) + dy

        self.DragStartX = mx
        self.DragStartY = my

        self:RepositionNodes()
    end
end

function PANEL:RepositionNodes()
    local nodeSize = Nexus:GetScale(64)
    local nodeHalf = nodeSize / 2
    for perkID, btn in pairs(self.Nodes) do
        if IsValid(btn) then
            local config = Nexus.Proc.Perks[perkID]
            if config then
                local x, y = self:GetNodePosition(config.GridPos.x, config.GridPos.y)
                btn:SetPos(x - nodeHalf, y - nodeHalf)
            end
        end
    end
end

function PANEL:GetNodePosition(gridX, gridY)
    local w, h = self:GetWide(), self:GetTall()
    local colOffset = 2 -- Align columns relative to Center
    local spacingX = Nexus:GetScale(220)
    local spacingY = Nexus:GetScale(160)
    
    local x = (w / 2) + (gridX - colOffset) * spacingX + (self.OffsetX or 0)
    local y = (h * 0.3) + gridY * spacingY + (self.OffsetY or 0)
    return x, y
end

function PANEL:Refresh()
    -- Clear existing nodes
    if self.Nodes then
        for _, btn in pairs(self.Nodes) do
            if IsValid(btn) then btn:Remove() end
        end
    end
    self.Nodes = {}

    -- Re-create perk nodes
    local nodeSize = Nexus:GetScale(64)
    local nodeHalf = nodeSize / 2
    local fontName = Nexus:GetFont({size = 14, bold = true})

    for perkID, config in pairs(Nexus.Proc.Perks) do
        local x, y = self:GetNodePosition(config.GridPos.x, config.GridPos.y)

        local btn = self:Add("DButton")
        btn:SetText("")
        btn:SetSize(nodeSize, nodeSize)
        btn:SetPos(x - nodeHalf, y - nodeHalf)
        btn:SetCursor("blank")
        -- Determine status
        local unlocked = Nexus.Proc.HasPerkUnlocked(perkID)
        local equipped = Nexus.Proc.HasPerk(perkID)
        local canUnlock = false
        if not unlocked and Nexus.Proc.PerkPoints >= config.Cost then
            if not config.Parent or Nexus.Proc.HasPerkUnlocked(config.Parent) then
                canUnlock = true
            end
        end

        btn.Paint = function(s, w, h)
            local nodeCol = Color(40, 40, 45, 200) -- Locked
            local borderCol = Color(80, 80, 80, 255)
            
            if equipped then
                nodeCol = Color(160, 130, 40, 220) -- Equipped (Golden)
                borderCol = Color(255, 215, 0, 255)
            elseif unlocked then
                nodeCol = Color(40, 120, 40, 220) -- Unlocked but not equipped (Green)
                borderCol = Color(100, 200, 100, 255)
            elseif canUnlock then
                nodeCol = Color(40, 100, 180, 220) -- Unlockable (Blue)
                borderCol = Color(100, 180, 255, 255)
            elseif s:IsHovered() then
                borderCol = Color(150, 150, 150, 255)
            end

            -- Textured slot background
            surface.SetDrawColor(nodeCol)
            surface.SetMaterial(nodeBgMat)
            surface.DrawTexturedRect(0, 0, w, h)
          
            -- Text snippet inside node (e.g. initials of name)
            local initials = ""
            for word in string.gmatch(config.Name, "%S+") do
                initials = initials .. string.sub(word, 1, 1)
            end
            draw.SimpleText(initials, fontName, w/2, h/2, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end

        btn.DoClick = function()
            if unlocked then
                if equipped or #Nexus.Proc.EquippedPerks < 3 then
                    Nexus.Proc.EquipPerk(perkID)
                else
                    surface.PlaySound("common/wpn_denyselect.wav")
                    chat.AddText(Color(255, 100, 100), "[Perks] You can only equip up to 3 perks at once!")
                end
                return
            end
            if not canUnlock then
                surface.PlaySound("common/wpn_denyselect.wav")
                return
            end

            Nexus:QueryPopup(
                "Unlock " .. config.Name .. " for " .. config.Cost .. " Perk Point(s)?",
                function()
                    Nexus.Proc.UnlockPerk(perkID)
                end,
                function() end,
                "Unlock",
                "Cancel"
            )
        end

        -- Detailed tooltip rendering
        btn.OnCursorEntered = function(s)
            s.HoveredTime = CurTime()
        end

        btn.PaintOver = function(s, w, h)
            if not s:IsHovered() then return end

            local fontTitle = Nexus:GetFont({size = 18, bold = true})
            local fontDesc = Nexus:GetFont({size = 14, font="Lato"})
            local fontCost = Nexus:GetFont({size = 14, bold = true, font="Lato"})

            -- Wrapped Description Text
            local descLines = {}
            local words = string.Explode(" ", config.Desc)
            local currentLine = ""
            surface.SetFont(fontDesc)
            local tipW = Nexus:GetScale(240)

            for _, word in ipairs(words) do
                local test = currentLine == "" and word or (currentLine .. " " .. word)
                local tw, _ = surface.GetTextSize(test)
                if tw > tipW - Nexus:GetScale(30) then
                    table.insert(descLines, currentLine)
                    currentLine = word
                else
                    currentLine = test
                end
            end
            table.insert(descLines, currentLine)

            -- Dynamic height calculation
            local lineCount = #descLines
            local headerSpace = Nexus:GetScale(40)
            local footerSpace = Nexus:GetScale(35)
            local lineSpace = lineCount * Nexus:GetScale(18)
            local tipH = headerSpace + lineSpace + footerSpace

            local tipX = w + Nexus:GetScale(10)
            local tipY = h/2 - tipH/2

            -- Flip tooltip to left side if it would bleed off screen
            local screenX, _ = s:LocalToScreen(tipX, tipY)
            if screenX + tipW > ScrW() then
                tipX = -tipW - Nexus:GetScale(10)
            end

            -- Render tooltip panel using rectangle_background.png
            DisableClipping(true)
            local bgMat = Material("rectangle_background.png")
            surface.SetDrawColor(255, 255, 255, 255)
            surface.SetMaterial(bgMat)
            surface.DrawTexturedRect(tipX, tipY, tipW, tipH)

            -- Draw subtle accent line
            local accentCol = equipped and Color(255, 215, 0) or (unlocked and Color(50, 220, 50) or (canUnlock and Color(50, 150, 255) or Color(120, 120, 120)))

            -- Perk details
            local textCol = color_black
            local descCol = color_black

            draw.SimpleText(config.Name, fontTitle, tipX + Nexus:GetScale(15), tipY + Nexus:GetScale(15), textCol)
            
            -- Render wrapped description lines
            for i, line in ipairs(descLines) do
                draw.SimpleText(line, fontDesc, tipX + Nexus:GetScale(15), tipY + Nexus:GetScale(40) + (i - 1) * Nexus:GetScale(18), descCol)
            end

            -- Cost & status
            local statusText = equipped and "EQUIPPED" or (unlocked and "(Unequipped)" or (canUnlock and "UNLOCKABLE" or "LOCKED"))
            draw.SimpleText("Cost: " .. config.Cost .. " Point(s)  |  " .. statusText, fontCost, tipX + Nexus:GetScale(15), tipY + tipH - Nexus:GetScale(25), color_black)
            DisableClipping(false)
        end

        self.Nodes[perkID] = btn
    end
end

function PANEL:Paint(w, h)
    -- Dark overlay background
    surface.SetDrawColor(6, 6, 8, 250)
    surface.DrawRect(0, 0, w, h)

    -- Header Info
    local fontHeader = Nexus:GetFont({size = 36, bold = true})
    local fontPoints = Nexus:GetFont({size = 22, bold = true})
    local fontSub = Nexus:GetFont({size = 15, font="Lato"})
    
    draw.SimpleText("SURVIVOR PERKS", fontHeader, w/2, h * 0.1, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    draw.SimpleText("AVAILABLE PERK POINTS: " .. Nexus.Proc.PerkPoints, fontPoints, w/2, h * 0.15, Color(220, 180, 50), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    draw.SimpleText("YOU MUST CLICK UNLOCKED PERKS TO EQUIP THEM (MAX 3 EQUIPPED PERKS ACTIVE)", fontSub, w/2, h * 0.9, Color(200, 60, 60), 1, 1)

    -- Draw connection lines first (rendered behind nodes)
    for perkID, config in pairs(Nexus.Proc.Perks) do
        if config.Parent then
            local parentConfig = Nexus.Proc.Perks[config.Parent]
            if parentConfig then
                local px, py = self:GetNodePosition(parentConfig.GridPos.x, parentConfig.GridPos.y)
                local cx, cy = self:GetNodePosition(config.GridPos.x, config.GridPos.y)

                -- Draw connecting lines
                local lineCol = Color(60, 60, 65, 255) -- Locked connection
                if Nexus.Proc.HasPerk(perkID) then
                    lineCol = Color(100, 255, 100, 255) -- Unlocked path
                elseif Nexus.Proc.HasPerk(config.Parent) then
                    lineCol = Color(100, 180, 255, 255) -- Unlockable path
                end

                surface.SetDrawColor(lineCol)
                -- Draw a thick line
                for i = -1, 1 do
                    surface.DrawLine(px + i, py, cx + i, cy)
                    surface.DrawLine(px, py + i, cx, cy + i)
                end
            end
        end
    end
end

function PANEL:PaintOver(w, h)
    local mx, my = gui.MousePos()
    local x, y = self:ScreenToLocal(mx, my)

    local handSize = Nexus:GetScale(32)
    local cx = x
    local cy = y

    -- Bloody cursor trail on movement
    local dx = x - self.LastCursorPos.x
    local dy = y - self.LastCursorPos.y
    local dist = math.sqrt(dx*dx + dy*dy)
    if dist > Nexus:GetScale(6) then
        table.insert(self.CursorTrails, {
            x = cx,
            y = cy,
            size = Nexus:GetScale(math.random(2, 4)),
            life = 1.2
        })
        self.LastCursorPos = {x = x, y = y}
    end

    -- Dripping blood periodically
    if CurTime() > self.NextDrip then
        self.NextDrip = CurTime() + math.random(0.1, 0.25)
        table.insert(self.CursorDrips, {
            x = cx + math.random(Nexus:GetScale(-4), Nexus:GetScale(4)),
            y = cy + handSize * 0.5,
            speedY = Nexus:GetScale(math.random(120, 240)),
            speedX = Nexus:GetScale(math.random(-15, 15)),
            size = Nexus:GetScale(math.random(1, 2)),
            life = 1.0
        })
    end

    -- Draw trails
    for i = #self.CursorTrails, 1, -1 do
        local trail = self.CursorTrails[i]
        trail.life = trail.life - FrameTime()
        if trail.life <= 0 then
            table.remove(self.CursorTrails, i)
        else
            local alpha = (trail.life / 1.2) * 180
            draw.RoundedBox(trail.size / 2, trail.x - trail.size/2, trail.y - trail.size/2, trail.size, trail.size, Color(130, 10, 10, alpha))
        end
    end

    -- Draw drips with gravity
    for i = #self.CursorDrips, 1, -1 do
        local drip = self.CursorDrips[i]
        drip.life = drip.life - FrameTime()
        if drip.life <= 0 then
            table.remove(self.CursorDrips, i)
        else
            drip.y = drip.y + drip.speedY * FrameTime()
            drip.x = drip.x + drip.speedX * FrameTime()
            drip.speedY = drip.speedY + Nexus:GetScale(350) * FrameTime()
            local alpha = (drip.life / 1.0) * 220
            draw.RoundedBox(drip.size / 2, drip.x - drip.size/2, drip.y - drip.size/2, drip.size, drip.size, Color(150, 12, 12, alpha))
        end
    end

    -- Draw main hand cursor (centered on cursor coordinates)
    surface.SetDrawColor(255, 255, 255, 255)
    surface.SetMaterial(cursorMat)
    surface.DrawTexturedRect(x - handSize * 0.5, y - handSize * 0.5, handSize, handSize)
end

vgui.Register("NexusRoundPerkTree", PANEL, "EditablePanel")
