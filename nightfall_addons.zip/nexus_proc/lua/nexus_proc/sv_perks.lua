-- sv_perks.lua
-- Centralized server-side authority for the Perk and Skill Tree system.

util.AddNetworkString("NightFall:Perks:Sync")
util.AddNetworkString("NightFall:Perks:Unlock")
util.AddNetworkString("NightFall:Perks:Equip")

-- Helper to check if a player has a specific perk equipped
function Nexus.Proc.HasPerk(ply, perkID)
    if not IsValid(ply) or ply:IsBot() then return false end
    if not ply.StatsAggregated or not ply.StatsAggregated.equippedPerks then return false end

    return table.HasValue(ply.StatsAggregated.equippedPerks, perkID)
end

-- Helper to check if a player has a specific perk unlocked
function Nexus.Proc.HasPerkUnlocked(ply, perkID)
    if not IsValid(ply) or ply:IsBot() then return false end
    if not ply.StatsAggregated or not ply.StatsAggregated.unlockedPerks then return false end

    return table.HasValue(ply.StatsAggregated.unlockedPerks, perkID)
end

-- Network player perks and points to client
function Nexus.Proc.SyncPerks(ply)
    if not IsValid(ply) or ply:IsBot() then return end
    if not ply.StatsAggregated then return end

    local points = ply.StatsAggregated.perkPoints or 0
    local unlocked = ply.StatsAggregated.unlockedPerks or {}
    local equipped = ply.StatsAggregated.equippedPerks or {}

    net.Start("NightFall:Perks:Sync")
        net.WriteInt(points, 32)
        net.WriteUInt(#unlocked, 16)
        for _, perkID in ipairs(unlocked) do
            net.WriteString(perkID)
        end
        net.WriteUInt(#equipped, 16)
        for _, perkID in ipairs(equipped) do
            net.WriteString(perkID)
        end
    net.Send(ply)
end

-- Hook into stats loading to sync perks on join
hook.Add("PlayerInitialSpawn", "NexusProcPerksLoadSync", function(ply)
    -- Wait a frame to ensure stats are loaded
    timer.Simple(0.5, function()
        if IsValid(ply) then
            Nexus.Proc.SyncPerks(ply)
            Nexus.Proc.ApplyPerks(ply)
        end
    end)
end)

-- Apply perk modifiers (MaxHP, Speed, Armor)
function Nexus.Proc.ApplyPerks(ply)
    if not IsValid(ply) or not ply:Alive() or ply:Team() == TEAM_SPECTATOR then return end
    if not ply.StatsAggregated then return end

    -- Base configurations
    local baseMaxHP = 100 -- Default to 100
    local baseWalkSpeed = 160
    local baseRunSpeed = 260

    local additionalMaxHP = 0
    local speedMultiplier = 1.0
    local startingArmor = 0

    -- Aggregate modifier values from equipped perks
    local equipped = ply.StatsAggregated.equippedPerks or {}
    for _, perkID in ipairs(equipped) do
        local config = Nexus.Proc.Perks[perkID]
        if config and config.Modifiers then
            if config.Modifiers.MaxHP then
                additionalMaxHP = additionalMaxHP + config.Modifiers.MaxHP
            end
            if config.Modifiers.SpeedMult then
                -- Additive speed multipliers (e.g. +10% and +10% = 1.2x speed)
                speedMultiplier = speedMultiplier + (config.Modifiers.SpeedMult - 1.0)
            end
            if config.Modifiers.Armor then
                startingArmor = startingArmor + config.Modifiers.Armor
            end
        end
    end

    -- Apply Health modifications
    local newMaxHP = baseMaxHP + additionalMaxHP
    ply:SetMaxHealth(newMaxHP)
    if ply:Health() < newMaxHP then
        ply:SetHealth(newMaxHP)
    end

    -- Adrenaline low health speed bonus (+25% speed multiplier)
    if ply.AdrenalineActive then
        speedMultiplier = speedMultiplier + 0.25
    end

    local finalWalkSpeed = baseWalkSpeed * speedMultiplier
    local finalRunSpeed = baseRunSpeed * speedMultiplier

    -- Marathon Runner sprint speed bonus (+15% run speed multiplier)
    if Nexus.Proc.HasPerk(ply, "sprint_boost") then
        finalRunSpeed = finalRunSpeed * 1.15
    end

    -- Apply Speed modifications
    ply:SetWalkSpeed(finalWalkSpeed)
    ply:SetRunSpeed(finalRunSpeed)
    ply:SetMaxSpeed(finalRunSpeed)

    -- Apply Armor modifications
    if startingArmor > 0 and ply:Armor() < startingArmor then
        ply:SetArmor(startingArmor)
    end
end

hook.Add("PlayerSpawn", "NexusProcApplyPerksOnSpawn", function(ply)
    timer.Simple(0.1, function()
        if IsValid(ply) then
            Nexus.Proc.ApplyPerks(ply)
        end
    end)
end)

-- Handle unlock requests from client
net.Receive("NightFall:Perks:Unlock", function(len, ply)
    if not IsValid(ply) or ply:IsBot() then return end
    if not ply.StatsAggregated then return end

    local perkID = net.ReadString()
    local config = Nexus.Proc.Perks[perkID]
    if not config then return end

    local stats = ply.StatsAggregated
    stats.unlockedPerks = stats.unlockedPerks or {}
    stats.perkPoints = stats.perkPoints or 0

    -- 1. Check if already unlocked
    if table.HasValue(stats.unlockedPerks, perkID) then
        ply:ChatPrint("[Perks] You have already unlocked this perk!")
        return
    end

    -- 2. Check if player has enough perk points
    if stats.perkPoints < config.Cost then
        ply:ChatPrint("[Perks] You do not have enough Perk Points!")
        return
    end

    -- 3. Check parent dependency
    if config.Parent then
        if not table.HasValue(stats.unlockedPerks, config.Parent) then
            ply:ChatPrint("[Perks] You must unlock the parent perk first!")
            return
        end
    end

    -- Deduct points and unlock
    stats.perkPoints = stats.perkPoints - config.Cost
    table.insert(stats.unlockedPerks, perkID)

    -- Save & Sync stats
    Nexus.Proc.SavePlayerStats(ply)
    Nexus.Proc.SyncPerks(ply)
    
    -- Apply effects
    Nexus.Proc.ApplyPerks(ply)

    ply:EmitSound("ambient/levels/citadel/d3_citadel_03.wav", 60, 120, 0.5)
    ply:ChatPrint("[Perks] Successfully unlocked perk: " .. config.Name)
end)

-- Handle equip requests from client
net.Receive("NightFall:Perks:Equip", function(len, ply)
    if not IsValid(ply) or ply:IsBot() then return end
    if not ply.StatsAggregated then return end

    local perkID = net.ReadString()
    local stats = ply.StatsAggregated
    stats.unlockedPerks = stats.unlockedPerks or {}
    stats.equippedPerks = stats.equippedPerks or {}

    -- 1. Check if unlocked
    if not table.HasValue(stats.unlockedPerks, perkID) then
        ply:ChatPrint("[Perks] You have not unlocked this perk yet!")
        return
    end

    -- 2. Toggle equip
    if table.HasValue(stats.equippedPerks, perkID) then
        table.RemoveByValue(stats.equippedPerks, perkID)
        ply:ChatPrint("[Perks] Unequipped perk: " .. (Nexus.Proc.Perks[perkID] and Nexus.Proc.Perks[perkID].Name or perkID))
    else
        -- Check limit (3)
        if #stats.equippedPerks >= 3 then
            ply:ChatPrint("[Perks] You can only equip up to 3 perks at once!")
            return
        end
        table.insert(stats.equippedPerks, perkID)
        ply:ChatPrint("[Perks] Equipped perk: " .. (Nexus.Proc.Perks[perkID] and Nexus.Proc.Perks[perkID].Name or perkID))
    end

    -- Save, Sync & Apply
    Nexus.Proc.SavePlayerStats(ply)
    Nexus.Proc.SyncPerks(ply)
    Nexus.Proc.ApplyPerks(ply)
    
    ply:EmitSound("buttons/combine_button1.wav", 60, 100)
end)

-- Weapon damage modifications (Heavy Hitter, Spider Hunter)
hook.Add("EntityTakeDamage", "NexusProcPerksDamageModifier", function(target, dmginfo)
    local attacker = dmginfo:GetAttacker()
    if not IsValid(attacker) or not attacker:IsPlayer() then return end

    local damageMult = 1.0

    -- Heavy Hitter perks
    if Nexus.Proc.HasPerk(attacker, "marksman_1") then
        damageMult = damageMult + 0.10
    end
    if Nexus.Proc.HasPerk(attacker, "marksman_2") then
        damageMult = damageMult + 0.10
    end
    if Nexus.Proc.HasPerk(attacker, "marksman_3") then
        damageMult = damageMult + 0.10
    end

    -- Spider Hunter perk
    local targetClass = target:GetClass()
    local isSpider = (targetClass == "nexus_spider" or targetClass == "nexus_jumping_spider" or targetClass == "nexus_mother_spider" or targetClass == "nexus_spider_egg")
    if isSpider then
        if Nexus.Proc.HasPerk(attacker, "hunter") then
            damageMult = damageMult + 0.25
        end
        -- Executioner perk (deal +20% damage if spider is below 50% max health)
        if Nexus.Proc.HasPerk(attacker, "executioner") and target:Health() < (target:GetMaxHealth() * 0.5) then
            damageMult = damageMult + 0.20
        end
    end

    if damageMult > 1.0 then
        dmginfo:ScaleDamage(damageMult)
    end
end)

-- Adrenaline health checker tick hook
hook.Add("PlayerTick", "NexusProcPerksLowHealthSpeed", function(ply)
    if not IsValid(ply) or not ply:Alive() or ply:Team() == TEAM_SPECTATOR then return end
    if not ply.StatsAggregated then return end

    if Nexus.Proc.HasPerk(ply, "adrenaline") then
        local isLow = ply:Health() < (ply:GetMaxHealth() * 0.35)
        if isLow and not ply.AdrenalineActive then
            ply.AdrenalineActive = true
            Nexus.Proc.ApplyPerks(ply)
        elseif not isLow and ply.AdrenalineActive then
            ply.AdrenalineActive = false
            Nexus.Proc.ApplyPerks(ply)
        end
    end
end)
