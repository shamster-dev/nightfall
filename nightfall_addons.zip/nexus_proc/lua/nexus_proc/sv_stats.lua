
-- Stats Tracking logic (Damage & Spiders Killed)
-- Stats Tracking logic (Damage Dealt)
hook.Add("EntityTakeDamage", "NexusProcTrackStats", function(target, dmginfo)
    local state = GetGlobalInt("NightFall:RoundState", ROUND_WAITING)
    if state ~= ROUND_ACTIVE then return end

    local attacker = dmginfo:GetAttacker()
    if not IsValid(attacker) or not attacker:IsPlayer() or not attacker.IsRoundParticipant then return end

    local class = target:GetClass()
    if class == "nexus_spider" or class == "nexus_jumping_spider" or class == "nexus_spider_egg" then
        local damage = dmginfo:GetDamage()
        attacker.StatDamageDealt = (attacker.StatDamageDealt or 0) + math.Round(damage)
    end
end)

-- Stats Tracking logic (Spiders Killed & Coin Earning)
hook.Add("OnNPCKilled", "NexusProcOnNPCKilled", function(npc, attacker, inflictor)
    local state = GetGlobalInt("NightFall:RoundState", ROUND_WAITING)
    if state ~= ROUND_ACTIVE then return end

    if IsValid(attacker) and attacker:IsPlayer() and attacker.IsRoundParticipant then
        local class = npc:GetClass()
        if class == "nexus_spider" or class == "nexus_jumping_spider" or class == "nexus_mother_spider" then
            attacker.StatSpidersKilled = (attacker.StatSpidersKilled or 0) + 1
            
            -- Earn coins per kill (e.g. 10 coins, using configured value)
            local coinReward = Nexus.Proc.CoinSettings and Nexus.Proc.CoinSettings.CoinsPerKill or 10
            attacker.StatCoinsEarned = (attacker.StatCoinsEarned or 0) + coinReward
            attacker:ChatPrint("[NightFall] +$" .. coinReward .. " Coins for killing a spider!")
        end
    end
end)

-- Stats Tracking logic (Distance Travelled)
timer.Create("NexusProcTrackDistance", 1.0, 0, function()
    local state = GetGlobalInt("NightFall:RoundState", ROUND_WAITING)
    if state ~= ROUND_ACTIVE then return end

    for _, ply in ipairs(player.GetAll()) do
        if IsValid(ply) and ply:Alive() and ply:Team() ~= TEAM_SPECTATOR and ply.IsRoundParticipant then
            local currentPos = ply:GetPos()
            if ply.StatLastPos then
                local dist = currentPos:Distance(ply.StatLastPos)
                -- Avoid giant jumps (teleports)
                if dist < 1000 then
                    ply.StatDistanceTravelled = (ply.StatDistanceTravelled or 0) + math.Round(dist)
                end
            end
            ply.StatLastPos = currentPos
        end
    end
end)

-- Stats Persistence (JSON Storage)
local function getStatsFilePath(ply)
    return "nexus_proc/stats/" .. ply:SteamID64() .. ".json"
end

local function loadPlayerStats(ply)
    if ply:IsBot() then return end
    
    local path = getStatsFilePath(ply)
    if file.Exists(path, "DATA") then
        local data = file.Read(path, "DATA")
        ply.StatsAggregated = util.JSONToTable(data) or {}
    else
        ply.StatsAggregated = {}
    end

    -- Initialize defaults
    local stats = ply.StatsAggregated
    stats.wins = stats.wins or 0
    stats.plays = stats.plays or 0
    stats.spiders = stats.spiders or 0
    stats.dmg = stats.dmg or 0
    stats.npcs = stats.npcs or 0
    stats.dist = stats.dist or 0
    stats.revived = stats.revived or 0
    stats.downed = stats.downed or 0
    stats.perkPoints = stats.perkPoints or 0
    stats.unlockedPerks = stats.unlockedPerks or {}
    stats.equippedPerks = stats.equippedPerks or {}
    stats.coins = stats.coins or 0
end

function Nexus.Proc.SavePlayerStats(ply)
    if ply:IsBot() or not ply.StatsAggregated then return end
    
    local path = getStatsFilePath(ply)
    file.CreateDir("nexus_proc/stats")
    file.Write(path, util.TableToJSON(ply.StatsAggregated, true))
end

hook.Add("PlayerInitialSpawn", "NexusProcLoadStats", function(ply)
    loadPlayerStats(ply)
end)

-- Receive scoreboard stats request from client
net.Receive("Nexus:Rounds:RequestScoreboard", function(len, ply)
    if not IsValid(ply) then return end

    local players = player.GetAll()
    net.Start("Nexus:Rounds:SyncScoreboard")
    net.WriteInt(#players, 8)
    for _, p in ipairs(players) do
        net.WriteEntity(p)
        net.WriteInt(p.StatSpidersKilled or 0, 32)
        net.WriteInt(p.StatDamageDealt or 0, 32)
    end
    net.Send(ply)
end)

