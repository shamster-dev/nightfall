hook.Add("PlayerDeath", "NexusProcDeathRagdoll", function(ply, inflictor, attacker)
    local state = GetGlobalInt("NightFall:RoundState", ROUND_WAITING)
    if state ~= ROUND_ACTIVE then return end

    -- Track Downed Count
    ply.StatDownedCount = (ply.StatDownedCount or 0) + 1

    -- Spawn a custom server-side prop_ragdoll entity
    local rag = ents.Create("prop_ragdoll")
    if not IsValid(rag) then return end
    
    rag:SetModel(ply:GetModel())
    rag:SetPos(ply:GetPos())
    rag:SetAngles(ply:GetAngles())
    rag:SetSkin(ply:GetSkin() or 0)
    rag:SetColor(ply:GetColor() or color_white)
    rag:SetMaterial(ply:GetMaterial() or "")
    
    -- Copy bodygroups
    for i = 0, ply:GetNumBodyGroups() - 1 do
        rag:SetBodygroup(i, ply:GetBodygroup(i))
    end
    
    rag:Spawn()
    
    -- Copy bone states & apply player's velocity to the physical bones
    local num = rag:GetPhysicsObjectCount()
    local plyVelocity = ply:GetVelocity()
    for i = 0, num - 1 do
        local phys = rag:GetPhysicsObjectNum(i)
        if IsValid(phys) then
            local bone = rag:TranslatePhysBoneToBone(i)
            local pos, ang = ply:GetBonePosition(bone)
            if pos and ang then
                phys:SetPos(pos)
                phys:SetAngles(ang)
            end
            phys:AddVelocity(plyVelocity * 0.8)
        end
    end
    
    rag.NexusOwner = ply
    rag.NexusReviveTime = CurTime() + 90
    rag:SetNWFloat("NexusReviveTime", rag.NexusReviveTime)
    rag:SetNWString("NexusOwnerName", ply:Nick())
    
    ply.NexusRagdoll = rag

    -- Remove default client-side engine ragdoll on the next frame
    timer.Simple(0, function()
        if IsValid(ply) then
            local defaultRag = ply:GetRagdollEntity()
            if IsValid(defaultRag) and defaultRag ~= rag then
                defaultRag:Remove()
            end
        end
    end)
end)

hook.Add("PlayerUse", "NexusProcReviveUse", function(ply, ent)
    if ent:GetClass() == "prop_ragdoll" and IsValid(ent.NexusOwner) and ent.NexusReviveTime and CurTime() < ent.NexusReviveTime then
        local victim = ent.NexusOwner
        if not victim:Alive() then
            victim:UnSpectate()
            victim.NexusAllowSpawn = true
            victim:Spawn()
            victim.NexusAllowSpawn = nil
            victim:SetPos(ent:GetPos() + Vector(0,0,10))
            victim:SetAngles(ent:GetAngles())
            
            -- Remove the ragdoll
            ent:Remove()
            
            -- Track Revived Count
            ply.StatRevivedCount = (ply.StatRevivedCount or 0) + 1

            -- Apply Medic perk effects
            if Nexus.Proc.HasPerk(ply, "reviver_1") then
                victim:SetHealth(victim:GetMaxHealth())
                victim:SetArmor(math.max(victim:Armor(), 25))
                ply:PrintMessage(HUD_PRINTTALK, "You revived " .. victim:Nick() .. " with full health and 25 armor!")
            else
                ply:PrintMessage(HUD_PRINTTALK, "You revived " .. victim:Nick() .. "!")
            end
            victim:PrintMessage(HUD_PRINTTALK, "You were revived by " .. ply:Nick() .. "!")
            return false
        end
    end
end)

hook.Add("Tick", "NexusProcReviveTick", function()
    local now = CurTime()
    for _, ent in ipairs(ents.FindByClass("prop_ragdoll")) do
        if ent.NexusReviveTime and now >= ent.NexusReviveTime then
            local victim = ent.NexusOwner
            ent.NexusReviveTime = nil
            
            if IsValid(victim) and not victim:Alive() then
                victim:Spectate(OBS_MODE_ROAMING)
                victim:SetTeam(TEAM_SPECTATOR)
                victim:SetPos(Nexus.Proc.VoidPosition)
            end
            ent:Remove()
        end
    end
end)

hook.Add("PlayerDisconnected", "NexusProcReviveDisconnect", function(ply)
    if IsValid(ply.NexusRagdoll) then
        ply.NexusRagdoll:Remove()
    end
end)
