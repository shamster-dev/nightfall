Nexus.Proc.RoundInformation = {
    [ROUND_WAITING] = {
        Duration = 60,
    },
    [ROUND_PREP] = {
        Duration = 60*4,
    },
    [ROUND_ACTIVE] = {
        Duration = 60*30,
    },
    [ROUND_VICTORY] = {
        Duration = 20,
    },
    [ROUND_DEFEAT] = {
        Duration = 20,
    },
}

// every x seconds spawn 1 - 3 spiders on the player
Nexus.Proc.SpiderSpawnTimer = 6

// How far away from the base walls we should spawn the spider
Nexus.Proc.SpiderSpawnDistance = {1500, 1800}

// Entities to cleanup after the round has ended
Nexus.Proc.CleanEntities = {
    "nexus_spider",
    "nexus_jumping_spider",
    "nexus_mother_spider",
    "nexus_spider_egg",
    "nexus_machine",
    "nexus_engine",
    "nexus_drum",
    "nexus_helicopter",
    "npc_helicopter",
}

// Spiders that can be spawned
Nexus.Proc.Spiders = {
    ["nexus_spider"] = 60,
    ["nexus_jumping_spider"] = 39.5,
    ["nexus_mother_spider"] = 0.5,
}

// Spiders that class as bosses
// These cannot spawn til 40% of the round has progressed
// and cannot spawn in an egg
Nexus.Proc.SpiderBosses = {
    ["nexus_mother_spider"] = true,
}

// Where players spawn in when they are in the main menu so they cannot hear audio
Nexus.Proc.VoidPosition = Vector(10298.068359, 4585.605469, 6756.770020)

// The helicopter extraction positions
Nexus.Proc.ExtractionPosition = {
    ["Start"] = Vector(1200.374878, 10864.482422, 2725.172119), // Spawn position for helicopter
    ["End"] = Vector(5758.748535, 3250.263916, 26.299183), // Extraction position
}

// Center of the home base
Nexus.Proc.HomeBase = Vector( 5767.911133, 1584.721924, -84.776932)
Nexus.Proc.BaseSafeRadius = 800

Nexus.Proc.Roles = {
    {
        Name = "Researcher", // Title of the role
        Class = "nexus_follower_researcher", // The entity class of the NPC
        Model = "models/Characters/hostage_03.mdl", // The model of the NPC
        Color = Color(255, 255, 255),
        StationText = "RESEARCHING", // The text the NPC will display when at their station
        ProgessionPerFix = {1.66, 3.66}, // The % increase per 3-5 seconds
        MachineModel = "models/props_lab/reciever01b.mdl", // The model of the NPCs machine
        OverheadYPos = Vector(0, 0, 30), // The offset of machine overhead
    },
    {
        Name = "Mechanic",
        Class = "nexus_follower_mechanic",
        Model = "models/Characters/hostage_03.mdl",
        Color = Color(255, 255, 255),
        WeaponModel = "models/weapons/w_crowbar.mdl",
        RequiresSocketedEquipment = true, // Does their machine require socketing
        OverheadYPos = Vector(0, 0, 30),
        OnMachineProgression = function(ent, closestMachine) // Do some event when the NPC repairs the machine
            ent:EmitSound("physics/metal/metal_solid_impact_bullet" .. math.random(1, 4) .. ".wav", 75, 100)

            local sparks = EffectData()
            sparks:SetOrigin(closestMachine:GetPos() + Vector(0, 0, 15))
            sparks:SetNormal(Vector(0, 0, 1))
            sparks:SetScale(1.5)
            sparks:SetMagnitude(2)
            util.Effect("Sparks", sparks)
        end,
        ProgessionPerFix = {1.66, 3.66},

        WaitingForSocketItem = "WAITING FOR ENGINE", // The npc text when waiting for the item to be socketed
        MachineModel = "models/gibs/airboat_broken_engine.mdl", // The machine model
        SocketEnt = "nexus_engine", // The machine will look for this item to update its socket status

        MachineRequired = "ENGINE REQUIRED", // The machine text when waiting for the item to be socketed
    },
    {
        Name = "Electrician",
        Class = "nexus_follower_electrician",
        Model = "models/Characters/hostage_03.mdl",
        Color = Color(255, 255, 255),
        WeaponModel = "models/weapons/w_stunbaton.mdl",
        ProgessionPerFix = {100.66, 300.66},
        MachineModel = "models/props_lab/reciever01b.mdl",
        Machines = {
            {pos = Vector(5944.409668, 1632.822876, -89.554573), sparkPos = Vector(5926.827637, 1630.422729, -105.140030)},
            {pos = Vector(5944.540039, 1696.223389, -89.451347), sparkPos = Vector(5923.626953, 1694.557373, -105.140030)},
        },
        MachineEffects = function(self, progress, roleData)
            if not roleData.Machines then return end
            if progress < 100 then return end

            local machineInt = self:GetNWInt("MachineInt", 1)
            local sparkPos = roleData.Machines[machineInt].sparkPos

            self.Emitter = self.Emitter or ParticleEmitter(sparkPos, false)

            self.NextSpark = self.NextSpark or 0
            if CurTime() >= self.NextSpark then
                self.NextSpark = CurTime() + math.Rand(0.15, 0.4)

                // Electric Sparks
                local effect = EffectData()
                effect:SetOrigin(sparkPos)
                effect:SetMagnitude(2)
                effect:SetScale(1.5)
                util.Effect("TeslaZap", effect)

                // Metal Sparks
                local sparks = EffectData()
                sparks:SetOrigin(sparkPos)
                sparks:SetMagnitude(1)
                sparks:SetScale(1)
                util.Effect("Sparks", sparks)
            end

            // Emit blue fog
            self.NextFog = self.NextFog or 0
            if CurTime() >= self.NextFog and self.Emitter then
                self.NextFog = CurTime() + math.Rand(0.08, 0.18)

                local p = self.Emitter:Add("particle/smokestack", sparkPos)
                if not p then return end
                p:SetDieTime(math.Rand(1.2, 2.0))
                p:SetStartAlpha(math.Rand(120, 180))
                p:SetEndAlpha(0)
                p:SetStartSize(math.Rand(5, 12))
                p:SetEndSize(math.Rand(25, 40))
                p:SetRoll(math.Rand(-180, 180))
                p:SetRollDelta(math.Rand(-2, 2))
                p:SetColor(0, 120, 255)
                p:SetVelocity(VectorRand() * 3 + Vector(0, 0, math.Rand(12, 28)))
                p:SetAirResistance(2)
            end
        end,
    },
    {
        Name = "Chemist",
        Class = "nexus_follower_chemist",
        Model = "models/Characters/hostage_03.mdl",
        Color = Color(255, 255, 255),
        WalkingToStationText = "MOVING TO SYNTHESISER", // leave blank for "MOVING TO STATION"
        RequiresSocketedEquipment = true,
        StationText = "SYNTHESISING",
        OnMachineProgression = function(ent, closestMachine)
            ent:EmitSound("physics/surfaces/slosh" .. math.random(1, 4) .. ".wav", 75, 100)

            local effect = EffectData()
            effect:SetOrigin(closestMachine:GetPos() + Vector(0, 0, 20))
            effect:SetNormal(Vector(0, 0, 1))
            util.Effect("cball_bounce", effect)
        end,
        ProgessionPerFix = {100.66, 300.66},
        WaitingForSocketItem = "WAITING FOR DRUM",
        MachineModel = "models/props_c17/oildrum001_explosive.mdl",
        SocketEnt = "nexus_drum",
        OverheadYPos = Vector(0, 20, 35),

        MachineTitle = "CHEMISTRY SYNTHESISER",
        MachineRequired = "DRUM REQUIRED", // requires socketed item
        MachineActive = "SYNTHESISING", // when socketed
    },
    {
        Name = "Pilot",
        Class = "nexus_follower_pilot",
        Model = "models/Characters/hostage_03.mdl",
        Color = Color(255, 255, 255),
        ProgessionPerFix = {1.66, 3.66},
        MachineModel = "models/props_lab/reciever01b.mdl",
    },
}

function Nexus.Proc:GetRoleData(name)
    for _, v in ipairs(Nexus.Proc.Roles) do
        if string.lower(v.Name) == string.lower(name) then
            return v
        end
    end

    return nil
end

Nexus.Proc.PerkSettings = {
    MechanicSpeedAdd = 0.25, -- +25% speed increase per nearby player with Chief Engineer
    MechanicMaxStack = 3,    -- Maximum 3 players stacking the Chief Engineer bonus
}

Nexus.Proc.CoinSettings = {
    CoinsPerKill = 2,    -- Coins earned per normal spider kill
    VictoryBonus = 0.20,  -- 20% bonus to coins earned during the round if team gets Victory
    -- Weapon and attachment costs are defined per-item in sh_weapons.lua
}

Nexus.Proc.Perks = {
    -- Survival Branch (Column 0, offsets for tree layout)
    ["vigor_1"] = {
        Name = "Vigor I",
        Desc = "Increase maximum health by 25.",
        Cost = 1,
        Parent = nil,
        GridPos = {x = 0, y = 0},
        Modifiers = { MaxHP = 25 }
    },
    ["vigor_2"] = {
        Name = "Vigor II",
        Desc = "Increase maximum health by another 25.",
        Cost = 2,
        Parent = "vigor_1",
        GridPos = {x = 0, y = 1},
        Modifiers = { MaxHP = 25 }
    },
    ["vigor_3"] = {
        Name = "Vigor III",
        Desc = "Increase maximum health by an additional 30.",
        Cost = 3,
        Parent = "vigor_2",
        GridPos = {x = 0, y = 2},
        Modifiers = { MaxHP = 30 }
    },
    ["reviver_1"] = {
        Name = "Medic",
        Desc = "Revive downed teammates with full health and starting armor.",
        Cost = 1,
        Parent = "vigor_1",
        GridPos = {x = -1, y = 1},
        Modifiers = { ReviveSpeed = 1.25 }
    },
    ["adrenaline"] = {
        Name = "Adrenaline",
        Desc = "Gain a 25% speed boost when your health falls below 35%.",
        Cost = 2,
        Parent = "reviver_1",
        GridPos = {x = -1, y = 2},
        Modifiers = { LowHealthSpeed = 1.25 }
    },
    ["ironclad"] = {
        Name = "Ironclad",
        Desc = "Spawn with 50 Armor.",
        Cost = 3,
        Parent = "vigor_3",
        GridPos = {x = 0, y = 3},
        Modifiers = { Armor = 50 }
    },

    -- Combat Branch (Column 2)
    ["marksman_1"] = {
        Name = "Heavy Hitter I",
        Desc = "Increase all weapon damage dealt by 10%.",
        Cost = 1,
        Parent = nil,
        GridPos = {x = 2, y = 0},
        Modifiers = { DamageMult = 1.10 }
    },
    ["marksman_2"] = {
        Name = "Heavy Hitter II",
        Desc = "Increase all weapon damage dealt by an additional 10%.",
        Cost = 2,
        Parent = "marksman_1",
        GridPos = {x = 2, y = 1},
        Modifiers = { DamageMult = 1.10 }
    },
    ["marksman_3"] = {
        Name = "Heavy Hitter III",
        Desc = "Increase all weapon damage dealt by an additional 10%.",
        Cost = 3,
        Parent = "marksman_2",
        GridPos = {x = 2, y = 2},
        Modifiers = { DamageMult = 1.10 }
    },
    ["hunter"] = {
        Name = "Spider Hunter",
        Desc = "Deal 25% bonus damage specifically against Spiders.",
        Cost = 3,
        Parent = "marksman_2",
        GridPos = {x = 1, y = 2},
        Modifiers = { SpiderDamageMult = 1.25 }
    },
    ["executioner"] = {
        Name = "Executioner",
        Desc = "Deal 20% more damage to spiders that are below 50% health.",
        Cost = 3,
        Parent = "marksman_3",
        GridPos = {x = 2, y = 3},
        Modifiers = { ExecutDmg = 1.20 }
    },

    -- Utility Branch (Column 4)
    ["runner_1"] = {
        Name = "Fleet Footed I",
        Desc = "Increase movement speed by 10%.",
        Cost = 1,
        Parent = nil,
        GridPos = {x = 4, y = 0},
        Modifiers = { SpeedMult = 1.10 }
    },
    ["runner_2"] = {
        Name = "Fleet Footed II",
        Desc = "Increase movement speed by an additional 10%.",
        Cost = 2,
        Parent = "runner_1",
        GridPos = {x = 4, y = 1},
        Modifiers = { SpeedMult = 1.10 }
    },
    ["mechanic_1"] = {
        Name = "Chief Engineer",
        Desc = "Increase generator/machine repairing speed by 25% per nearby player.",
        Cost = 2,
        Parent = "runner_1",
        GridPos = {x = 5, y = 1},
        Modifiers = { RepairSpeed = 1.25 }
    },
    ["mechanic_2"] = {
        Name = "Supercharger",
        Desc = "Chief Engineer speed bonus is increased to 35% speed per nearby player.",
        Cost = 3,
        Parent = "mechanic_1",
        GridPos = {x = 5, y = 2},
        Modifiers = { Supercharger = true }
    },
    ["sprint_boost"] = {
        Name = "Marathon Runner",
        Desc = "Gain +15% sprint speed increase.",
        Cost = 2,
        Parent = "runner_2",
        GridPos = {x = 4, y = 2},
        Modifiers = { SprintSpeed = 1.15 }
    },
    ["scavenger"] = {
        Name = "Base Scavenger",
        Desc = "Carryable items like engines and drums spawn closer to home base.",
        Cost = 2,
        Parent = "sprint_boost",
        GridPos = {x = 4, y = 3},
        Modifiers = { Scavenger = true }
    },
    ["lobbyist"] = {
        Name = "Lobbyist",
        Desc = "Rescuable survivor NPCs spawn much closer to home base.",
        Cost = 2,
        Parent = "mechanic_2",
        GridPos = {x = 5, y = 3},
        Modifiers = { Lobbyist = true }
    }
}