

-- Block manual respawning via clicking during active rounds
hook.Add("PlayerDeathThink", "NexusProcBlockClickSpawn", function(ply)
    local state = GetGlobalInt("NightFall:RoundState", ROUND_WAITING)
    if state == ROUND_ACTIVE then
        return false
    end
end)



-- Prevent players and bots from spawning unless authorized (revived or round start)
hook.Add("PlayerSpawn", "NexusProcBlockSpawnActiveRound", function(ply)
    local state = GetGlobalInt("NightFall:RoundState", ROUND_WAITING)
    if state == ROUND_ACTIVE then
        if not ply.NexusAllowSpawn then
            ply:KillSilent()
            timer.Simple(0.1, function()
                if not IsValid(ply) then return end
                ply:Spectate(OBS_MODE_ROAMING)
                ply:SetTeam(TEAM_SPECTATOR)
                timer.Simple(0, function()
                    if IsValid(ply) then ply:SetPos(Nexus.Proc.VoidPosition) end
                end)
            end)
        end
    end
end)

-- Block player-vs-player damage but allow players to damage bots
hook.Add("PlayerShouldTakeDamage", "NexusProcBlockPvP", function(ply, attacker)
    if IsValid(attacker) and attacker:IsPlayer() and not attacker:IsBot() then
        if ply:IsPlayer() and not ply:IsBot() then
            return false
        end
    end
end)