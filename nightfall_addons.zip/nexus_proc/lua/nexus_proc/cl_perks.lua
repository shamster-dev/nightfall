-- cl_perks.lua
-- Centralized client-side state and caching for the Perk and Skill Tree system.

Nexus.Proc.PerkPoints = Nexus.Proc.PerkPoints or 0
Nexus.Proc.UnlockedPerks = Nexus.Proc.UnlockedPerks or {}
Nexus.Proc.EquippedPerks = Nexus.Proc.EquippedPerks or {}

-- Network receiver to sync perks
net.Receive("NightFall:Perks:Sync", function()
    local points = net.ReadInt(32)
    local unlockedCount = net.ReadUInt(16)

    local unlocked = {}
    for i = 1, unlockedCount do
        table.insert(unlocked, net.ReadString())
    end

    local equippedCount = net.ReadUInt(16)
    local equipped = {}
    for i = 1, equippedCount do
        table.insert(equipped, net.ReadString())
    end

    Nexus.Proc.PerkPoints = points
    Nexus.Proc.UnlockedPerks = unlocked
    Nexus.Proc.EquippedPerks = equipped

    -- Refresh UI if open
    if IsValid(Nexus.Proc.PerkMenuPanel) then
        Nexus.Proc.PerkMenuPanel:Refresh()
    end
end)

-- Check if player has a perk equipped
function Nexus.Proc.HasPerk(perkID)
    return table.HasValue(Nexus.Proc.EquippedPerks, perkID)
end

-- Check if player has unlocked a perk
function Nexus.Proc.HasPerkUnlocked(perkID)
    return table.HasValue(Nexus.Proc.UnlockedPerks, perkID)
end

-- Send request to unlock perk
function Nexus.Proc.UnlockPerk(perkID)
    net.Start("NightFall:Perks:Unlock")
        net.WriteString(perkID)
    net.SendToServer()
end

-- Send request to equip / unequip perk
function Nexus.Proc.EquipPerk(perkID)
    net.Start("NightFall:Perks:Equip")
        net.WriteString(perkID)
    net.SendToServer()
end

-- Perk multiplier helpers
function Nexus.Proc.GetRepairSpeedMult()
    if Nexus.Proc.HasPerk("mechanic_1") then
        return 1.25
    end
    return 1.0
end

function Nexus.Proc.GetReviveSpeedMult()
    if Nexus.Proc.HasPerk("reviver_1") then
        return 1.25
    end
    return 1.0
end

-- Client command to open the perk menu directly for testing
concommand.Add("nexus_open_perks", function()
    if IsValid(Nexus.Proc.PerkMenuPanel) then
        Nexus.Proc.PerkMenuPanel:Remove()
    end
    Nexus.Proc.PerkMenuPanel = vgui.Create("NexusRoundPerkTree")
    Nexus.Proc.PerkMenuPanel:MakePopup()
end)
