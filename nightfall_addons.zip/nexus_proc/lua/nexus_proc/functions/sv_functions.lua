-- sv_functions.lua
-- Server-side helper functions and developer concommands for Nexus procedural entities.


local Spider = Nexus.Proc.Spider

-- ─────────────────────────────────────────────────────────────────────────────
-- Console Commands (Superadmin or Server Console only)
-- ─────────────────────────────────────────────────────────────────────────────

-- Spawns a standard procedural spider at trace location
concommand.Add("nexus_spawn_spider", function(ply, cmd, args)
    if IsValid(ply) and not ply:IsSuperAdmin() then
        ply:ChatPrint("[Nexus] You don't have permission to spawn spiders.")
        return
    end

    local spawnPos
    if IsValid(ply) then
        local tr = ply:GetEyeTrace()
        spawnPos = tr.HitPos + tr.HitNormal * 8
    else
        spawnPos = Vector(0, 0, 100)
    end

    local ent = ents.Create("nexus_spider")
    if not IsValid(ent) then
        if IsValid(ply) then ply:ChatPrint("[Nexus] Failed to create spider entity.") end
        return
    end

    ent:SetPos(spawnPos)
    ent:SetAngles(Angle(0, 0, 0))
    ent:Spawn()
    ent:Activate()

    if IsValid(ply) then
        ply:ChatPrint("[Nexus] Spider spawned! (health: " .. math.floor(ent.genes.health) .. ")")
    end
end)

-- Spawns a jumping procedural spider at trace location
concommand.Add("nexus_spawn_jumping_spider", function(ply, cmd, args)
    if IsValid(ply) and not ply:IsSuperAdmin() then
        ply:ChatPrint("[Nexus] You don't have permission to spawn jumping spiders.")
        return
    end

    local spawnPos
    if IsValid(ply) then
        local tr = ply:GetEyeTrace()
        spawnPos = tr.HitPos + tr.HitNormal * 8
    else
        spawnPos = Vector(0, 0, 100)
    end

    local ent = ents.Create("nexus_jumping_spider")
    if not IsValid(ent) then
        if IsValid(ply) then ply:ChatPrint("[Nexus] Failed to create jumping spider entity.") end
        return
    end

    ent:SetPos(spawnPos)
    ent:SetAngles(Angle(0, 0, 0))
    ent:Spawn()
    ent:Activate()

    if IsValid(ply) then
        ply:ChatPrint("[Nexus] Jumping Spider spawned! (health: " .. math.floor(ent.genes.health) .. ")")
    end
end)

-- Spawns a spider egg at trace location
concommand.Add("nexus_spawn_egg", function(ply, cmd, args)
    if IsValid(ply) and not ply:IsSuperAdmin() then
        ply:ChatPrint("[Nexus] You don't have permission to spawn eggs.")
        return
    end

    local spawnPos
    if IsValid(ply) then
        local tr = ply:GetEyeTrace()
        spawnPos = tr.HitPos + tr.HitNormal * 20
    else
        spawnPos = Vector(0, 0, 100)
    end

    local ent = ents.Create("nexus_spider_egg")
    if not IsValid(ent) then
        if IsValid(ply) then ply:ChatPrint("[Nexus] Failed to create egg entity.") end
        return
    end

    ent:SetPos(spawnPos)
    ent:SetAngles(Angle(-90, 0, 0))
    ent:Spawn()
    ent:Activate()

    if IsValid(ply) then
        ply:ChatPrint("[Nexus] Spider Egg spawned!")
    end
end)

-- Toggleable spawner test command
local spawnerActive = false

concommand.Add("nexus_spider_test", function(ply, cmd, args)
    if IsValid(ply) and not ply:IsSuperAdmin() then
        ply:ChatPrint("[Nexus] You don't have permission to use the spider test spawner.")
        return
    end

    spawnerActive = not spawnerActive

    if spawnerActive then
        local targetPly = IsValid(ply) and ply or player.GetAll()[1]
        if not IsValid(targetPly) then
            spawnerActive = false
            print("[Nexus] No player found to spawn spiders around.")
            return
        end

        if IsValid(ply) then ply:ChatPrint("[Nexus] Spider test spawner ENABLED! Spawning spiders every 2.5s...") end
        
        timer.Create("NexusSpiderTestSpawner", 2.5, 0, function()
            if not IsValid(targetPly) or not targetPly:Alive() then return end
            
            -- Keep total count of spiders under 15 to avoid lag
            local currentSpiders = #ents.FindByClass("nexus_spider") + #ents.FindByClass("nexus_jumping_spider")
            if currentSpiders >= 15 then return end

            -- Calculate a random ground point in radius 300 to 750 around player
            local angle = math.Rand(0, 360)
            local dist = math.Rand(300, 750)
            local offset = Vector(math.cos(math.rad(angle)) * dist, math.sin(math.rad(angle)) * dist, 120)
            local spawnPos = targetPly:GetPos() + offset
            
            -- Trace to find the actual ground geometry
            local tr = util.TraceLine({
                start = spawnPos,
                endpos = spawnPos - Vector(0, 0, 500),
                mask = MASK_SOLID_BRUSHONLY
            })
            
            local finalPos = tr.Hit and tr.HitPos + tr.HitNormal * 8 or targetPly:GetPos()

            -- Randomize spawn: 50% normal, 50% jumping
            local class = math.random() > 0.5 and "nexus_jumping_spider" or "nexus_spider"
            local spider = ents.Create(class)
            if IsValid(spider) then
                spider:SetPos(finalPos)
                spider:Spawn()
                spider:Activate()
            end
        end)
    else
        timer.Remove("NexusSpiderTestSpawner")
        if IsValid(ply) then ply:ChatPrint("[Nexus] Spider test spawner DISABLED.") end
    end
end)

-- Automatically cast eye traces across the entire map to generate egg spawn points
concommand.Add("nexus_generate_map_eggs", function(ply, cmd, args)
    if IsValid(ply) and not ply:IsSuperAdmin() then
        ply:ChatPrint("[Nexus] You don't have permission to generate map eggs.")
        return
    end

    local count = tonumber(args[1]) or 80 -- generate up to 80 points by default
    local spawnedCount = 0
    local attempts = 0
    local maxAttempts = count * 20

    -- Estimate map boundaries or fall back to standard Garry's Mod skybox bounds
    local minX, maxX = -8000, 8000
    local minY, maxY = -8000, 8000
    local startZ = 2000

    -- Try to find active players to base the map area on, or just use general bounds
    local activePlayers = player.GetAll()
    if #activePlayers > 0 then
        -- Find a player to query local area, or query map brush entities
    end

    -- Clear existing spawns or notify
    local msg = "[Nexus] Generating egg spawn points across the map... this might take a moment."
    if IsValid(ply) then ply:ChatPrint(msg) else print(msg) end

    -- Generate a table of generated points
    local newPoints = {}

    while spawnedCount < count and attempts < maxAttempts do
        attempts = attempts + 1

        local rx = math.random(minX, maxX)
        local ry = math.random(minY, maxY)
        local rz = startZ

        -- Trace down to find floor geometry
        local tr = util.TraceLine({
            start = Vector(rx, ry, rz),
            endpos = Vector(rx, ry, rz - 6000),
            mask = MASK_SOLID_BRUSHONLY
        })

        if tr.Hit and not tr.HitSky then
            local pos = tr.HitPos
            -- Check if it is a reasonable flat surface (not vertical walls)
            if tr.HitNormal.z > 0.7 then
                -- Check proximity to existing generated points to prevent overlapping bases
                local tooClose = false
                for _, otherPos in ipairs(newPoints) do
                    if pos:DistToSqr(otherPos) < (200 * 200) then
                        tooClose = true
                        break
                    end
                end

                if not tooClose then
                    table.insert(newPoints, pos)
                    spawnedCount = spawnedCount + 1
                end
            end
        end
    end

    if spawnedCount > 0 then
        Nexus.Proc.EggSpawns = newPoints
        if SERVER and Nexus.Proc.SaveEggSpawns then
            Nexus.Proc.SaveEggSpawns()
        end

        -- Sync to all clients if holding toolgun
        net.Start("Nexus:EggSpawns:Sync")
        net.WriteTable(Nexus.Proc.EggSpawns)
        net.Broadcast()

        local finalMsg = "[Nexus] Successfully auto-generated " .. spawnedCount .. " egg spawn points after " .. attempts .. " trace checks!"
        if IsValid(ply) then ply:ChatPrint(finalMsg) else print(finalMsg) end
    else
        local failMsg = "[Nexus] Failed to find any suitable map surfaces for egg generation."
        if IsValid(ply) then ply:ChatPrint(failMsg) else print(failMsg) end
    end
end)

-- Admin command to spawn the friendly hunter helicopter flying along its coordinates path and force extraction
concommand.Add("nexus_spawn_helicopter", function(ply, cmd, args)
    if IsValid(ply) and not ply:IsSuperAdmin() then
        ply:ChatPrint("[Nexus] You don't have permission to spawn the helicopter.")
        return
    end

    -- Force round state to ROUND_ACTIVE if not already running to ensure extraction UI and logic is enabled
    local state = GetGlobalInt("NightFall:RoundState", 0)
    if state ~= 2 --[[ ROUND_ACTIVE ]] then
        Nexus.Proc.Rounds.SetState(2 --[[ ROUND_ACTIVE ]], 480)
    end

    -- Force extraction phase variables
    Nexus.Proc.IsExtractionActive = true
    SetGlobalFloat("NightFall:SetExtractionEndTime", CurTime() + 60)

    -- Alert players
    for _, p in ipairs(player.GetAll()) do
        p:EmitSound("ambient/alarms/siren.wav", 55, 100)
        p:ChatPrint("[System] ADMIN FORCED EXTRACTION! HELICOPTER APPROACHING!")
    end

    local heli = ents.Create("nexus_helicopter")
    if IsValid(heli) then
        -- Spawn at the designated starting position
        heli:SetPos(Vector(8382.583984, 10023.673828, 2256.562012))
        heli:Spawn()
        heli:Activate()

        local msg = "[Nexus] Helicopter spawned at 8382 10023 2256, flying to 5758 3250 26!"
        if IsValid(ply) then ply:ChatPrint(msg) else print(msg) end
    else
        local msg = "[Nexus] Failed to create helicopter entity."
        if IsValid(ply) then ply:ChatPrint(msg) else print(msg) end
    end
end)

hook.Add("PlayerSpawnProp", "Nexus:StopProp", function(ply, cmd, args)
    if ( not ply:IsSuperAdmin() ) then
        return false
    end 
end)