hook.Add("ContextMenuOpen", "Nexus:StopCMenu", function()
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    if ( not ply:IsSuperAdmin() ) then
        return false
    end 
end)

hook.Add("SpawnMenuEnabled", "Nexus:StopSpawnmenu", function()
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    if ( not ply:IsSuperAdmin() ) then
        return false
    end 
end)