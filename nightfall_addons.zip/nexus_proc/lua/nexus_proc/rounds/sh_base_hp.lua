-- sh_base_hp.lua
-- Shared config and utility functions for the Base HP system

Nexus.Proc.Base.DefaultHealth = 10000
Nexus.Proc.Base.AddPerPlayer = 2500
Nexus.Proc.Base.CappedHealth = 50000

Nexus.Proc.Base.EggsPerPlayer = 40

Nexus.Proc.Base.GetMaxSpiders = function()
    return #Nexus.Proc.Rounds:GetAlivePlayers() * 10
end

-- Segment definitions
-- 5183.968750 1976.861084 -125.316010 to 5183.968750 1126.231079 -116.849915
-- 6368.031250 1121.661011 -121.530830 to 6368.031250 1977.452148 -121.663620
-- 6208.270996 2144.031250 -120.776268 to 5633.323730 2144.031250 -122.112450
Nexus.Proc.Base.Walls = {
    {
        startPos = Vector(5183.968750, 1976.861084, -125.316010),
        endPos = Vector(5183.968750, 1126.231079, -116.849915)
    },
    {
        startPos = Vector(6368.031250, 1121.661011, -121.530830),
        endPos = Vector(6368.031250, 1977.452148, -121.663620)
    },
    {
        startPos = Vector(6208.270996, 2144.031250, -120.776268),
        endPos = Vector(5633.323730, 2144.031250, -122.112450)
    }
}

-- Check distance from a position to a line segment defined by two points
function Nexus.Proc.Base:GetClosestWallPoint(pos)
    local closestPoint = nil
    local closestDistSqr = math.huge
    local closestWallIdx = nil

    for idx, wall in ipairs(self.Walls) do
        local A = wall.startPos
        local B = wall.endPos
        local AB = B - A
        local AP = pos - A
        local ab_len_sqr = AB:LengthSqr()

        local t = 0
        if ab_len_sqr > 0 then
            t = math.Clamp(AP:Dot(AB) / ab_len_sqr, 0, 1)
        end

        local proj = A + AB * t
        local distSqr = pos:DistToSqr(proj)

        if distSqr < closestDistSqr then
            closestDistSqr = distSqr
            closestPoint = proj
            closestWallIdx = idx
        end
    end

    return closestPoint, closestDistSqr, closestWallIdx
end
