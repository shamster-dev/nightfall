local BaseDamagePulseTime = 0
net.Receive("NightFall:Base:DamageEffect", function()
    BaseDamagePulseTime = CurTime()
end)

local colorPrep    = Nexus:GetColor("red")
local colorActive  = Nexus:GetColor("red")
local colorVictory = Nexus:GetColor("blue")
local colorDefeat  = Nexus:GetColor("red")
local colorPanel   = Nexus:GetColor("background")
local colorText    = Nexus:GetTextColor(colorPanel)

local fontTitle = Nexus:GetFont({size = 22, bold = true})
local fontTimer = Nexus:GetFont({size = 28, bold = true})
local fontStat  = Nexus:GetFont({size = 14})

-- We need local ActiveSpiders reference since cl_spider.lua registers them here:
-- (ActiveSpiders is defined globally in cl_spider.lua, but we check if it is active)
local function getActiveSpidersCount()
    local spiderCount = 0
    -- Find active spiders via ents list if ActiveSpiders registry is missing
    if ActiveSpiders then
        for ent, _ in pairs(ActiveSpiders) do
            if IsValid(ent) and not ent:GetNWBool("IsDead", false) then
                spiderCount = spiderCount + 1
            end
        end
    else
        for _, ent in ipairs(ents.FindByClass("nexus_spider")) do
            if IsValid(ent) and not ent:GetNWBool("IsDead", false) then
                spiderCount = spiderCount + 1
            end
        end
        for _, ent in ipairs(ents.FindByClass("nexus_jumping_spider")) do
            if IsValid(ent) and not ent:GetNWBool("IsDead", false) then
                spiderCount = spiderCount + 1
            end
        end
    end
    return spiderCount
end



hook.Add("HUDPaint", "NexusProcRoundHUD", function()
    local state = GetGlobalInt("NightFall:RoundState", ROUND_WAITING)
    if state == ROUND_WAITING then return end -- Don't draw if just waiting for players

    local timeEnd = GetGlobalFloat("NightFall:Round:EndCurTime", 0)
    local timeLeft = math.max(0, timeEnd - CurTime())

    -- HUD box sizing & placement (top left)
    local r = Nexus:GetMargin()
    local w, h = Nexus:GetScale(250), Nexus:GetScale(100)
    local x = Nexus:GetScale(25)
    local y = Nexus:GetScale(25)

    local hudBgMat = Material("hud_background.png")
    surface.SetDrawColor(0, 0, 0, 200)
    surface.SetMaterial(hudBgMat)
    surface.DrawTexturedRect(x, y, w, h)

    -- Determine label and timer color based on state
    local stateText = "UNKNOWN"
    local hudColor = colorText
    if state == ROUND_PREP then
        stateText = "PREPARE"
        hudColor = colorPrep
    elseif state == ROUND_ACTIVE then
        stateText = "SURVIVE!"
        hudColor = colorActive
    elseif state == ROUND_VICTORY or state == ROUND_DEFEAT then
        local won = NexusRoundStats and NexusRoundStats.won or (state == ROUND_VICTORY)
        if won then
            stateText = "VICTORY"
            hudColor = colorVictory
        else
            stateText = "ROUND LOST"
            hudColor = colorDefeat
        end
    end

    local textX = x + Nexus:GetScale(50)

    -- Draw state label
    draw.SimpleText(stateText, fontTitle, textX, y + Nexus:GetScale(35), hudColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

    -- Draw minutes:seconds timer
    local mins = math.floor(timeLeft / 60)
    local secs = math.floor(timeLeft % 60)
    local timerText = string.format("%02d:%02d", mins, secs)
    
    if state == ROUND_VICTORY or state == ROUND_DEFEAT then
        timerText = "--:--" -- Freeze timer display
    end

    draw.SimpleTextOutlined(timerText, fontTimer, textX, y + Nexus:GetScale(30) + Nexus:GetScale(35), colorText, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, color_black)

    -- Draw BASE HP in the top middle of the screen during active rounds
    if state == ROUND_ACTIVE or state == ROUND_DEFEAT then
        local maxHP = GetGlobalInt("NightFall:BaseMaxHP", Nexus.Proc.Base.DefaultHealth or 10000)
        local baseHP = GetGlobalInt("NightFall:BaseHP", maxHP)
        local ratio = math.Clamp(baseHP / maxHP, 0, 1)

        -- Calculate damage pulse effects (shake and scale up)
        local pulseDuration = 0.35
        local timeSincePulse = CurTime() - (BaseDamagePulseTime or 0)
        local pulseFrac = 0
        if timeSincePulse < pulseDuration then
            pulseFrac = 1 - (timeSincePulse / pulseDuration)
        end

        -- Bar Dimensions
        local baseW, baseH = Nexus:GetScale(360), Nexus:GetScale(35)
        
        -- Scale bar up slightly when hit (max 3%)
        local scaleFactor = 1 + (pulseFrac * 0.03)
        local barW = baseW * scaleFactor
        local barH = baseH * scaleFactor

        -- Shake bar position when hit (gentle shaking)
        local shakeX = math.sin(RealTime() * 40) * Nexus:GetScale(2.5) * pulseFrac
        local shakeY = math.cos(RealTime() * 35) * Nexus:GetScale(1.5) * pulseFrac

        local barX = ScrW() / 2 - barW / 2 + shakeX
        local barY = Nexus:GetScale(25) + shakeY

        -- Background container
        local bgMat = Material("rectangle_background.png")
        -- Flash background slightly red when hit
        local bgR = 12 + pulseFrac * 40
        surface.SetDrawColor(bgR, 12, 16, 220)
        surface.SetMaterial(bgMat)
        surface.DrawTexturedRect(barX, barY, barW, barH)

        -- Inner health fill
        local fillW = (barW - Nexus:GetMargin("small")*2) * ratio
        if fillW > 0 then
            -- Base health color: Pulsing red if low HP (< 25%), or normal accent color
            local hpCol = Nexus:GetColor("accent") or Color(50, 200, 50)
            if ratio < 0.25 then
                local wave = math.abs(math.sin(RealTime() * 6))
                hpCol = Color(180 + wave * 75, 20, 20, 255)
            elseif pulseFrac > 0 then
                -- Lerp health color toward bright red when hit
                local r = Lerp(pulseFrac, hpCol.r, 255)
                local g = Lerp(pulseFrac, hpCol.g, 50)
                local b = Lerp(pulseFrac, hpCol.b, 50)
                hpCol = Color(r, g, b, 255)
            end

            surface.SetDrawColor(hpCol.r, hpCol.g, hpCol.b, hpCol.a)
            surface.SetMaterial(bgMat)
            surface.DrawTexturedRect(barX + Nexus:GetMargin("small"), barY + Nexus:GetMargin("small"), fillW, barH - Nexus:GetMargin("small")*2)
        end

        -- Health text overlay
        local hpText = "BASE HEALTH: " .. string.Comma(baseHP) .. " / " .. string.Comma(maxHP)
        draw.SimpleTextOutlined(hpText, Nexus:GetFont({size = 12, bold = true}), ScrW() / 2 + shakeX, barY + barH / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
    end

    -- Draw EXTRACTION overlay if the extraction phase is running
    local extEnd = GetGlobalFloat("NightFall:SetExtractionEndTime", 0)
    if extEnd > 0 then
        local timeLeft = math.max(0, extEnd - CurTime())
        local mins = math.floor(timeLeft / 60)
        local secs = math.floor(timeLeft % 60)
        local timeStr = string.format("%02d:%02d", mins, secs)

        local extText = "EXTRACTION " .. timeStr
        
        -- Pulse text size/alpha alert
        local alpha = 200 + math.sin(RealTime() * 8) * 55
        local size = 32 + math.sin(RealTime() * 8) * 2

        draw.SimpleTextOutlined(extText, Nexus:GetFont({size = size, bold = true, dontScale = true}), ScrW() / 2, Nexus:GetScale(80), Color(255, 60, 60, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 2, color_black)
    end

    -- Draw Spectator target controls overlay if player is dead
    local ply = LocalPlayer()
    if IsValid(ply) and (ply:Team() == TEAM_SPECTATOR or not ply:Alive()) then
        local target = ply:GetObserverTarget()
        if IsValid(target) and target:IsPlayer() then
            local specText = "SPECTATING: " .. string.upper(target:Nick())
            local controlsText = "[Left-Click / Space] Cycle Players   [Right-Click] Cycle Camera Mode"
            
            draw.SimpleTextOutlined(specText, Nexus:GetFont({size = 20, bold = true}), ScrW() / 2, ScrH() - Nexus:GetScale(100), Nexus:GetTextColor(Nexus:GetColor("background")), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, color_black)
            draw.SimpleTextOutlined(controlsText, Nexus:GetFont({size = 14, font = "Lato"}), ScrW() / 2, ScrH() - Nexus:GetScale(75), Nexus:GetTextColor(Nexus:GetColor("background")), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, color_black)
        end
    end
end)

-- Server tells us to re-open the intro menu (on prep phase or after death)
net.Receive("NightFall:Rounds:OpenMenu", function()
    -- Close victory/defeat end screen if it's currently open
    if IsValid(Nexus.Proc.RoundEndPanel) then
        Nexus.Proc.RoundEndPanel:Remove()
        Nexus.Proc.RoundEndPanel = nil
    end

    -- Don't open a second menu if one is already showing
    if IsValid(Nexus.Proc.LoadinMenuPanel) then return end

    Nexus.Proc.LoadinMenuPanel = vgui.Create("Nexus:Proc:Menu")
end)

-- Server tells us the round is active: close the intro menu and fade it out
net.Receive("NightFall:Rounds:CloseMenu", function()
    if IsValid(Nexus.Proc.LoadinMenuPanel) then
        Nexus.Proc.LoadinMenuPanel:AlphaTo(0, 1.5, 0, function()
            if IsValid(Nexus.Proc.LoadinMenuPanel) then
                Nexus.Proc.LoadinMenuPanel:Remove()
                Nexus.Proc.LoadinMenuPanel = nil
            end
        end)
    end
end)

-- Add GMinimap radar blip for the survivor NPC revealed by the researcher
net.Receive("NightFall:Researcher:AddBlip", function()
    local ent = net.ReadEntity()
    local pos = net.ReadVector()

    if GMinimap and GMinimap.AddBlip then
        -- Add blip referencing the entity. 
        -- If entity is not fully rendered yet on client due to PVS, bind it by ID or position.
        GMinimap:AddBlip({
            id = "survivor_scan_" .. (IsValid(ent) and ent:EntIndex() or tostring(pos)),
            parent = IsValid(ent) and ent or nil,
            position = pos,
            icon = "icon16/user.png", -- green user icon/marker
            color = Color(50, 225, 50, 255),
            scale = 1.3,
            indicateAlt = true,
            indicateAng = true
        })
    end
end)

local currentMusicPath = ""
local currentMusicStation = nil

local function PlayRoundMusic(path)
    if currentMusicPath == path then return end
    currentMusicPath = path

    -- Stop current music
    if IsValid(currentMusicStation) then
        currentMusicStation:Stop()
        currentMusicStation = nil
    end

    if path == "" then return end

    sound.PlayFile(path, "noplay", function(station)
        if not IsValid(station) then return end
        if currentMusicPath ~= path then
            station:Stop()
            return
        end

        station:EnableLooping(true)
        station:SetVolume(0.5)
        station:Play()
        currentMusicStation = station
    end)
end

local lastSpiderSeenTime = 0

hook.Add("Think", "NexusProcRoundMusic", function()
    local state = GetGlobalInt("NightFall:RoundState", ROUND_WAITING)
    local ply = LocalPlayer()

    -- Let players and spectators hear the victory/defeat screen music
    if state == ROUND_VICTORY or state == ROUND_DEFEAT then
        local won = NexusRoundStats and NexusRoundStats.won
        if won == nil then
            won = (state == ROUND_VICTORY)
        end
        if won then
            PlayRoundMusic("sound/music/hl2_song16.mp3")
        else
            PlayRoundMusic("sound/music/hl2_song12.mp3")
        end
        return
    end

    if not IsValid(ply) or not ply:Alive() or ply:Team() == TEAM_SPECTATOR then
        PlayRoundMusic("")
        lastSpiderSeenTime = 0
        return
    end

    if state == ROUND_PREP then
        PlayRoundMusic("sound/music_preperation.mp3")
        lastSpiderSeenTime = 0
    elseif state == ROUND_ACTIVE then
        -- Check if any spider is within 700 units of the player
        local spiderClose = false
        local plyPos = ply:GetPos()
        local closeDistSqr = 700 * 700
        local homeBase = Nexus.Proc.HomeBase
        local safeRadius = Nexus.Proc.BaseSafeRadius or 800
        local isPlayerInBase = homeBase and plyPos:DistToSqr(homeBase) < (safeRadius * safeRadius)

        if ActiveSpiders then
            for ent, _ in pairs(ActiveSpiders) do
                if IsValid(ent) and not ent:GetNWBool("IsDead", false) then
                    local entPos = ent:GetPos()
                    if entPos:DistToSqr(plyPos) <= closeDistSqr then
                        local isSpiderInBase = homeBase and entPos:DistToSqr(homeBase) < (safeRadius * safeRadius)
                        if not isPlayerInBase or isSpiderInBase then
                            spiderClose = true
                            break
                        end
                    end
                end
            end
        else
            local function checkEnt(ent)
                if IsValid(ent) and not ent:GetNWBool("IsDead", false) then
                    local entPos = ent:GetPos()
                    if entPos:DistToSqr(plyPos) <= closeDistSqr then
                        local isSpiderInBase = homeBase and entPos:DistToSqr(homeBase) < (safeRadius * safeRadius)
                        if not isPlayerInBase or isSpiderInBase then
                            return true
                        end
                    end
                end
                return false
            end

            for _, ent in ipairs(ents.FindByClass("nexus_spider")) do
                if checkEnt(ent) then
                    spiderClose = true
                    break
                end
            end
            if not spiderClose then
                for _, ent in ipairs(ents.FindByClass("nexus_jumping_spider")) do
                    if checkEnt(ent) then
                        spiderClose = true
                        break
                    end
                end
            end
        end

        if spiderClose then
            lastSpiderSeenTime = CurTime()
        end

        -- Keep playing attack music for 7 seconds after last spider was close to prevent snapping
        local inCombat = spiderClose or (lastSpiderSeenTime > 0 and (CurTime() - lastSpiderSeenTime) < 7)

        if inCombat then
            PlayRoundMusic("sound/music_spider_attack.mp3")
        else
            PlayRoundMusic("sound/music_gameplay.mp3")
        end
    else
        PlayRoundMusic("")
        lastSpiderSeenTime = 0
    end
end)

hook.Add("ShutDown", "NexusProcRoundMusicShutdown", function()
    if IsValid(currentMusicStation) then
        currentMusicStation:Stop()
    end
end)

-- Client-side HUD drawing for player death ragdolls
surface.CreateFont("ReviveHugeFont", {
    font = "Arial",
    size = 80,
    weight = 800,
    shadow = true,
    antialias = true
})
surface.CreateFont("ReviveMediumFont", {
    font = "Arial",
    size = 40,
    weight = 700,
    shadow = true,
    antialias = true
})

hook.Add("PostDrawOpaqueRenderables", "NexusProcDrawReviveText", function(bDrawingDepth, bDrawingSkybox)
    if bDrawingDepth or bDrawingSkybox then return end

    for _, ent in ipairs(ents.FindByClass("prop_ragdoll")) do
        if not IsValid(ent) then continue end

        local reviveTime = ent:GetNWFloat("NexusReviveTime", 0)
        if reviveTime <= 0 or CurTime() >= reviveTime then continue end

        local ownerName = ent:GetNWString("NexusOwnerName", "Player")
        local timeLeft = math.ceil(reviveTime - CurTime())

        -- Position above the ragdoll
        local pos = ent:GetPos() + Vector(0, 0, 50)

        local eyePos = EyePos()
        local dir = (eyePos - pos):Angle()
        local ang = Angle(0, dir.y + 90, 90)

        cam.IgnoreZ(true)
        cam.Start3D2D(pos, ang, 0.15)
            draw.SimpleText(ownerName, Nexus:GetFont({size = 80, dontScale = true}), 1, -40+1, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            draw.SimpleText(ownerName, Nexus:GetFont({size = 80, dontScale = true}), 0, -40, Color(255, 75, 75, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

            draw.SimpleText("REVIVE (" .. timeLeft .. "s)", Nexus:GetFont({size = 45, dontScale = true}), 0+1, 30+1, color_black, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            draw.SimpleText("REVIVE (" .. timeLeft .. "s)", Nexus:GetFont({size = 45, dontScale = true}), 0, 30, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        cam.End3D2D()
        cam.IgnoreZ(false)
    end
end)

-- Dedicated Fullscreen Victory & Defeat Screen
local cardBgMat = Material("mini_rectangle_background.png")
local unlockBgMat = Material("rectangle_background.png")

net.Receive("NightFall:Rounds:SendStats", function()
    local won = net.ReadBool()
    local isParticipant = net.ReadBool()
    local teamWon = net.ReadBool()
    local npcs = net.ReadInt(32)
    local spiders = net.ReadInt(32)
    local dmg = net.ReadInt(32)
    local dist = net.ReadInt(32)
    local revived = net.ReadInt(32)
    local downed = net.ReadInt(32)

    local unlocksCount = net.ReadUInt(8)
    local unlocks = {}
    for i = 1, unlocksCount do
        local uType = net.ReadString()
        local uClass = net.ReadString()
        local name = uClass

        if uType == "weapon" then
            for _, w in ipairs(Nexus.Proc.Weapons.List or {}) do
                if w.class == uClass then
                    name = w.name or name
                    break
                end
            end
        elseif uType == "attachment" then
            if ARC9 and ARC9.Attachments and ARC9.Attachments[uClass] then
                name = ARC9.Attachments[uClass].PrintName or name
            end
        end

        table.insert(unlocks, {
            type = uType,
            class = uClass,
            name = name
        })
    end

    NexusRoundStats = {
        won = won,
        isParticipant = isParticipant,
        teamWon = teamWon,
        npcs = npcs,
        spiders = spiders,
        dmg = dmg,
        dist = dist,
        revived = revived,
        downed = downed,
        unlocks = unlocks
    }
end)

local lastState = 0
hook.Add("Think", "NexusProcRoundStatsReset", function()
    local state = GetGlobalInt("NightFall:RoundState", 0)
    if state ~= lastState then
        if state == 1 --[[ ROUND_PREP ]] or state == 0 --[[ ROUND_WAITING ]] or state == 2 --[[ ROUND_ACTIVE ]] then
            NexusRoundStats = nil
        end
        lastState = state
    end
end)

local function wrapText(text, font, maxWidth)
    surface.SetFont(font)
    local words = string.Explode(" ", text)
    local lines = {}
    local currentLine = ""

    for _, word in ipairs(words) do
        local testLine = currentLine == "" and word or (currentLine .. " " .. word)
        local w, _ = surface.GetTextSize(testLine)
        if w > maxWidth and currentLine ~= "" then
            table.insert(lines, currentLine)
            currentLine = word
        else
            currentLine = testLine
        end
    end
    if currentLine ~= "" then
        table.insert(lines, currentLine)
    end
    return lines
end

local PANEL = {}

function PANEL:Init()
    self:SetSize(ScrW(), ScrH())
    self:SetPos(0, 0)
    
    self.StartTime = CurTime()
    self.AlphaVal = 0

end

function PANEL:BuildUnlocks()
    if self.UnlockPanelsBuilt then return end
    if not NexusRoundStats or not NexusRoundStats.unlocks then return end
    if NexusRoundStats.isParticipant == false then return end
    self.UnlockPanelsBuilt = true

    local unlocks = NexusRoundStats.unlocks
    if #unlocks == 0 then return end

    local w, h = self:GetWide(), self:GetTall()
    local cardW, cardH = Nexus:GetScale(220), Nexus:GetScale(140)
    local spacing = Nexus:GetScale(30)
    local startY = h * 0.35
    local rowSpacing = Nexus:GetScale(20)
    local unlocksStartY = startY + 2 * (cardH + rowSpacing) + Nexus:GetScale(40)

    local unlockCardW, unlockCardH = Nexus:GetScale(260), Nexus:GetScale(160)
    local unlockSpacing = Nexus:GetScale(20)
    local totalUnlocksW = (#unlocks * unlockCardW) + ((#unlocks - 1) * unlockSpacing)
    local unlockStartX = (w - totalUnlocksW) / 2
    local unlockY = unlocksStartY + Nexus:GetScale(35)

    self.UnlockPanels = self.UnlockPanels or {}

    for i, unlock in ipairs(unlocks) do
        local uCardX = unlockStartX + (i - 1) * (unlockCardW + unlockSpacing)

        local card = vgui.Create("DPanel", self)
        card:SetSize(unlockCardW, unlockCardH)
        card:SetPos(uCardX, unlockY)
        
        card.Paint = function(s, w, h)
            local timeElapsed = CurTime() - self.StartTime
            local sectionAlpha = math.Clamp((timeElapsed - 1.2) * 3, 0, 1) * self.AlphaVal
            if sectionAlpha <= 0 then return end

            -- Draw textured card background
            surface.SetMaterial(unlockBgMat)
            local accentColor = (unlock.type == "weapon") and Color(230, 180, 50, sectionAlpha) or Color(50, 180, 230, sectionAlpha)
            surface.SetDrawColor(accentColor.r, accentColor.g, accentColor.b, sectionAlpha)
            surface.DrawTexturedRect(0, 0, w, h)

            -- Value: Display Name
            local fontVal = Nexus:GetFont({size = 14, bold = true})
            draw.SimpleText(unlock.name, fontVal, w / 2, h - Nexus:GetScale(18), Color(255, 255, 255, sectionAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end

        local modelPath = nil
        if unlock.type == "weapon" then
            local wepTable = weapons.Get(unlock.class)
            modelPath = wepTable and wepTable.WorldModel
        elseif unlock.type == "attachment" then
            local attTable = ARC9.Attachments[unlock.class]
            modelPath = attTable and (attTable.Model or attTable.ModelPath)
        end

        if modelPath and modelPath ~= "" and modelPath ~= "models/weapons/w_rif_m4a1.mdl" then
            local modelPanel = vgui.Create("DModelPanel", card)
            modelPanel:SetSize(unlockCardW - Nexus:GetScale(20), unlockCardH - Nexus:GetScale(60))
            modelPanel:SetPos(Nexus:GetScale(10), Nexus:GetScale(30))
            modelPanel:SetModel(modelPath)
            modelPanel:SetFOV(45)
            modelPanel:SetCamPos(Vector(20, 20, 10))
            modelPanel:SetLookAt(Vector(0, 0, 0))
            
            modelPanel.LayoutEntity = function(s, ent)
                ent:SetAngles(Angle(0, RealTime() * 30, 0))
            end
            
            modelPanel:SetMouseInputEnabled(false)

            local oldPaint = modelPanel.Paint
            modelPanel.Paint = function(s, w, h)
                local timeElapsed = CurTime() - self.StartTime
                local sectionAlpha = math.Clamp((timeElapsed - 1.2) * 3, 0, 1) * self.AlphaVal
                if sectionAlpha <= 0 then return end
                oldPaint(s, w, h)
            end
        else
            local iconMat = nil
            if unlock.type == "attachment" then
                local attTable = ARC9.Attachments[unlock.class]
                iconMat = attTable and attTable.Icon
            end

            if iconMat then
                local iconImg = vgui.Create("DImage", card)
                iconImg:SetSize(Nexus:GetScale(80), Nexus:GetScale(60))
                iconImg:SetPos((unlockCardW - Nexus:GetScale(80)) / 2, Nexus:GetScale(35))
                iconImg:SetMaterial(iconMat)
                iconImg:SetMouseInputEnabled(false)

                local oldPaint = iconImg.Paint
                iconImg.Paint = function(s, w, h)
                    local timeElapsed = CurTime() - self.StartTime
                    local sectionAlpha = math.Clamp((timeElapsed - 1.2) * 3, 0, 1) * self.AlphaVal
                    if sectionAlpha <= 0 then return end
                    oldPaint(s, w, h)
                end
            end
        end

        table.insert(self.UnlockPanels, card)
    end
end

function PANEL:Paint(w, h)
    local state = GetGlobalInt("NightFall:RoundState", 0)
    -- Dark background blur
    Derma_DrawBackgroundBlur(self, self.StartTime)
    
    -- Fade-in background
    self.AlphaVal = Lerp(FrameTime() * 3, self.AlphaVal, 220)
    surface.SetDrawColor(15, 15, 17, self.AlphaVal)
    surface.DrawRect(0, 0, w, h)

    -- Determine text and color
    local isParticipant = NexusRoundStats and NexusRoundStats.isParticipant
    if isParticipant == nil then
        isParticipant = true -- Default to participant view while loading
    end

    local teamWon = NexusRoundStats and NexusRoundStats.teamWon
    if teamWon == nil then
        teamWon = (state == ROUND_VICTORY)
    end

    local titleText = ""
    local titleColor = Color(200, 200, 200, self.AlphaVal)
    local subText = ""

    if isParticipant == false then
        titleText = "ROUND OVER"
        titleColor = Color(160, 160, 170, self.AlphaVal)
        subText = teamWon and "The active squad successfully extracted from the sector." or "The extraction helicopter departed without the squad."
    else
        local won = NexusRoundStats and NexusRoundStats.won
        if won == nil then
            won = (state == ROUND_VICTORY)
        end
        titleText = won and "VICTORY" or "DEFEATED"
        titleColor = won and Color(50, 220, 50, self.AlphaVal) or Color(220, 50, 50, self.AlphaVal)
        subText = won and "You successfully escaped the sector." or "The extraction helicopter departed without you."
    end

    -- Animate title floating down slightly
    local timeElapsed = CurTime() - self.StartTime
    local titleY = h * 0.2 - math.Clamp(Nexus:GetScale(50) - (timeElapsed * Nexus:GetScale(150)), 0, Nexus:GetScale(50))
    
    local fontTitle = Nexus:GetFont({size = 72, bold = true})
    local fontLabel = Nexus:GetFont({size = 20, bold = true})
    local fontValue = Nexus:GetFont({size = 36, bold = true})

    draw.SimpleTextOutlined(titleText, fontTitle, w / 2, titleY, titleColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 2, Color(0, 0, 0, self.AlphaVal))

    -- Subtitle (Wrapped)
    local subLines = wrapText(subText, fontLabel, w * 0.8)
    for i, line in ipairs(subLines) do
        draw.SimpleTextOutlined(line, fontLabel, w / 2, titleY + Nexus:GetScale(60) + (i - 1) * Nexus:GetScale(24), Color(200, 200, 200, self.AlphaVal), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, self.AlphaVal))
    end

    -- Draw Stats or Spectator summary
    local cardW, cardH = Nexus:GetScale(220), Nexus:GetScale(140)
    local rowSpacing = Nexus:GetScale(20)
    local startY = h * 0.35

    if isParticipant == false then
        -- Draw spectator specific banner
        local bannerW, bannerH = Nexus:GetScale(500), Nexus:GetScale(120)
        local bannerX = (w - bannerW) / 2
        local bannerY = h * 0.4

        surface.SetMaterial(unlockBgMat)
        local statusColor = teamWon and Color(50, 220, 50, self.AlphaVal) or Color(220, 50, 50, self.AlphaVal)
        surface.SetDrawColor(statusColor.r, statusColor.g, statusColor.b, self.AlphaVal)
        surface.DrawTexturedRect(bannerX, bannerY, bannerW, bannerH)

        local fontStatusLabel = Nexus:GetFont({size = 16, bold = true})
        local fontStatusVal = Nexus:GetFont({size = 28, bold = true})

        draw.SimpleText("SQUAD MISSION RESULT", fontStatusLabel, w / 2, bannerY + Nexus:GetScale(30), Color(240, 240, 240, self.AlphaVal), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText(teamWon and "SUCCESSFUL EXTRACTION" or "MISSION FAILED", fontStatusVal, w / 2, bannerY + bannerH - Nexus:GetScale(40), Color(255, 255, 255, self.AlphaVal), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    else
        -- Draw Stats Cards
        local spacing = Nexus:GetScale(30)

        local rows = {
            {
                { label = "SPIDERS KILLED", val = tostring(NexusRoundStats and NexusRoundStats.spiders or 0), color = Color(220, 100, 100) },
                { label = "DAMAGE DEALT", val = tostring(NexusRoundStats and NexusRoundStats.dmg or 0), color = Color(240, 150, 50) },
                { label = "NPCs FOLLOWED", val = tostring(NexusRoundStats and NexusRoundStats.npcs or 0), color = Color(100, 180, 240) },
                { label = "DIST. TRAVELLED", val = string.format("%.0fm", (NexusRoundStats and NexusRoundStats.dist or 0) / 39.37), color = Color(100, 220, 150) }
            },
            {
                { label = "TEAMMATES REVIVED", val = tostring(NexusRoundStats and NexusRoundStats.revived or 0), color = Color(100, 200, 220) },
                { label = "TIMES DOWNED", val = tostring(NexusRoundStats and NexusRoundStats.downed or 0), color = Color(220, 120, 50) }
            }
        }

        local cardIndex = 0
        for rowIndex, rowItems in ipairs(rows) do
            local rowW = (#rowItems * cardW) + ((#rowItems - 1) * spacing)
            local startX = (w - rowW) / 2
            local rowY = startY + (rowIndex - 1) * (cardH + rowSpacing)

            for colIndex, stat in ipairs(rowItems) do
                cardIndex = cardIndex + 1
                local cardDelay = 0.5 + (cardIndex * 0.12)
                local cardAlpha = math.Clamp((timeElapsed - cardDelay) * 3, 0, 1) * self.AlphaVal

                if cardAlpha > 0 then
                    local cardX = startX + (colIndex - 1) * (cardW + spacing)
                    local slideY = rowY + math.Clamp(Nexus:GetScale(30) - ((timeElapsed - cardDelay) * Nexus:GetScale(120)), 0, Nexus:GetScale(30))

                    -- Card Textured Background
                    surface.SetMaterial(cardBgMat)
                    surface.SetDrawColor(stat.color.r, stat.color.g, stat.color.b, cardAlpha)
                    surface.DrawTexturedRect(cardX, slideY, cardW, cardH)

                    -- Text (Label wrapped if needed)
                    local labelLines = wrapText(stat.label, fontLabel, cardW*.75)
                    local labelStartY = slideY + Nexus:GetScale(20)
                    for j, line in ipairs(labelLines) do
                        draw.SimpleText(line, fontLabel, cardX + cardW/2, labelStartY + (j - 1) * Nexus:GetScale(22), Color(240, 240, 240, cardAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                    end

                    -- Value drawn below label
                    local valY = slideY + cardH - Nexus:GetScale(40)
                    draw.SimpleText(stat.val, fontValue, cardX + cardW/2, valY, Color(255, 255, 255, cardAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                end
            end
        end
    end

    -- Draw Unlocks Section
    if isParticipant ~= false then
        if not self.UnlockPanelsBuilt and NexusRoundStats and NexusRoundStats.unlocks then
            self:BuildUnlocks()
        end

        local unlocks = NexusRoundStats and NexusRoundStats.unlocks or {}
        local unlocksStartY = startY + 2 * (cardH + rowSpacing) + Nexus:GetScale(40)
        
        local fontSection = Nexus:GetFont({size = 24, bold = true})

        local sectionAlpha = math.Clamp((timeElapsed - 1.2) * 3, 0, 1) * self.AlphaVal
        if sectionAlpha > 0 then
            draw.SimpleTextOutlined("NEW UNLOCKS", fontSection, w / 2, unlocksStartY, Color(240, 240, 240, sectionAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, sectionAlpha))

            if #unlocks == 0 then
                draw.SimpleText("ALL WEAPONS & ATTACHMENTS UNLOCKED", fontLabel, w / 2, unlocksStartY + Nexus:GetScale(40), Color(150, 150, 150, sectionAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
        end
    end

    -- Timer showing prep transition
    local timeEnd = GetGlobalFloat("NightFall:Round:EndCurTime", 0)
    local timeLeft = math.max(0, timeEnd - CurTime())
    local timerText = string.format("Next round begins in %.1fs...", timeLeft)
    draw.SimpleText(timerText, fontLabel, w / 2, h * 0.92, Color(150, 150, 150, self.AlphaVal), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

vgui.Register("NexusRoundEndScreen", PANEL, "EditablePanel")

hook.Add("Think", "NexusProcRoundEndScreenManager", function()
    local state = GetGlobalInt("NightFall:RoundState", 0)
    if state == 3 --[[ ROUND_VICTORY ]] or state == 4 --[[ ROUND_DEFEAT ]] then
        if not IsValid(Nexus.Proc.RoundEndPanel) then
            Nexus.Proc.RoundEndPanel = vgui.Create("NexusRoundEndScreen")
            Nexus.Proc.RoundEndPanel:MakePopup()
        end
    else
        if IsValid(Nexus.Proc.RoundEndPanel) then
            Nexus.Proc.RoundEndPanel:Remove()
            Nexus.Proc.RoundEndPanel = nil
        end
    end
end)

-- Custom Scoreboard VGUI Panel
local SCORE_PANEL = {}
NexusScoreboardStats = NexusScoreboardStats or {}

net.Receive("Nexus:Rounds:SyncScoreboard", function()
    local count = net.ReadInt(8)
    for i = 1, count do
        local ply = net.ReadEntity()
        if IsValid(ply) then
            NexusScoreboardStats[ply] = {
                spiders = net.ReadInt(32),
                dmg = net.ReadInt(32)
            }
        else
            -- Discard unneeded bytes if player disconnected/invalidated
            net.ReadInt(32)
            net.ReadInt(32)
        end
    end
    
    if IsValid(scoreboardInstance) then
        scoreboardInstance:Refresh()
    end
end)

function SCORE_PANEL:Init()
    self.StartTime = CurTime()

    local w, h = Nexus:GetScale(950), Nexus:GetScale(600)
    self:SetSize(w, h)
    self:Center()
    
    self:SetAlpha(0)
    self:AlphaTo(255, 0.15, 0)
    
    -- Default DockPadding to allow custom overriding
    self:DockPadding(Nexus:GetScale(40), Nexus:GetScale(20), Nexus:GetScale(20), Nexus:GetScale(40))

    -- Docked Header Panel
    self.Header = vgui.Create("DPanel", self)
    self.Header:Dock(TOP)
    self.Header:DockMargin(0, Nexus:GetScale(20), 0, 0)
    self.Header:SetTall(Nexus:GetScale(60))
    self.Header.Paint = function(s, w, h)
        local tw, th = draw.SimpleText("N I G H T  F A L L", Nexus:GetFont({size = 20, bold = true}), 0, 0, Nexus:GetColor("red"), TEXT_ALIGN_LEFT, 0)

        local fontHeader = Nexus:GetFont({size = 12, bold = true})
        local headerY = th + Nexus:GetScale(30)
        draw.SimpleText("PLAYER", fontHeader, 0, headerY, Nexus:GetTextColor(Nexus:GetColor("background")), 0, TEXT_ALIGN_CENTER)
        draw.SimpleText("KILLS", fontHeader, w * 0.45, headerY, Nexus:GetTextColor(Nexus:GetColor("background")), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText("DAMAGE", fontHeader, w * 0.65, headerY, Nexus:GetTextColor(Nexus:GetColor("background")), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText("PING", fontHeader, w * 0.82, headerY, Nexus:GetTextColor(Nexus:GetColor("background")), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    self.Scroll = vgui.Create("Nexus:V2:ScrollPanel", self)
    self.Scroll:Dock(FILL)
    self.Scroll:DockMargin(0, Nexus:GetScale(10), 0, 0)
    
    self:Refresh()
    
    -- Request immediate stats on opening
    net.Start("Nexus:Rounds:RequestScoreboard")
    net.SendToServer()
    
    self.NextRefresh = CurTime() + 1.0
end

function SCORE_PANEL:Refresh()
    if not IsValid(self.Scroll) then return end
    self.Rows = self.Rows or {}
    
    local players = player.GetAll()
    table.sort(players, function(a, b)
        local aData = NexusScoreboardStats[a]
        local bData = NexusScoreboardStats[b]
        local aDmg = (aData and tonumber(aData.dmg)) or 0
        local bDmg = (bData and tonumber(bData.dmg)) or 0
        return aDmg > bDmg
    end)
    
    -- Remove rows for players who disconnected
    for ply, row in pairs(self.Rows) do
        if not IsValid(ply) or not table.HasValue(players, ply) then
            if IsValid(row) then row:Remove() end
            self.Rows[ply] = nil
        end
    end
    
    local rowH = Nexus:GetScale(55)
    local spacing = Nexus:GetScale(8)
    
    for index, ply in ipairs(players) do
        if not IsValid(ply) then continue end
        local targetPlayer = ply
        
        local row = self.Rows[targetPlayer]
        if not IsValid(row) then
            row = self.Scroll:Add("DPanel")
            row:SetSize(self.Scroll:GetWide(), rowH)
            row:Dock(TOP)
            row:DockMargin(0, 0, 0, spacing)
            
            local teamColor = team.GetColor(targetPlayer:Team())
            row.Paint = function(s, w, h)
                if not IsValid(targetPlayer) then return end
                
                surface.SetMaterial(cardBgMat)
                if targetPlayer == LocalPlayer() then
                    surface.SetDrawColor(35, 45, 55, 235)
                else
                    surface.SetDrawColor(25, 25, 30, 220)
                end
                surface.DrawTexturedRect(0, 0, w, h)
                
                surface.SetDrawColor(teamColor.r, teamColor.g, teamColor.b, 255)
                surface.DrawRect(0, 0, Nexus:GetScale(4), h)
                
                local valFont = Nexus:GetFont({size = 15, bold = true})
                local pStats = NexusScoreboardStats[targetPlayer] or {}
                local kills = pStats.spiders or 0
                local dmg = pStats.dmg or 0
                local ping = targetPlayer:Ping()
                
                draw.SimpleText(tostring(kills), valFont, w * 0.45, h/2, Color(240, 240, 240), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                draw.SimpleText(tostring(dmg), valFont, w * 0.65, h/2, Color(240, 240, 240), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                draw.SimpleText(tostring(ping), valFont, w * 0.82, h/2, Color(240, 240, 240), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            
            local avatar = vgui.Create("AvatarMaterial", row)
            avatar:SetSize(Nexus:GetScale(40), Nexus:GetScale(40))
            avatar:SetPos(Nexus:GetScale(15), (rowH - Nexus:GetScale(40)) / 2)
            avatar:SetPlayer(targetPlayer, 64)
            
            local name = vgui.Create("DLabel", row)
            name:SetFont(Nexus:GetFont({size = 15, bold = true}))
            name:SetTextColor(Color(255, 255, 255))
            name:SetText(targetPlayer:Nick())
            name:SetPos(Nexus:GetScale(65), 0)
            name:SetSize(Nexus:GetScale(180), rowH)
            name:SetContentAlignment(4)

            -- Mute/Unmute button (only for other players and not bots)
            if targetPlayer ~= LocalPlayer() then
                local muteBtn = vgui.Create("DImageButton", row)
                muteBtn:SetSize(Nexus:GetScale(20), Nexus:GetScale(20))
                muteBtn.Player = targetPlayer
                
                muteBtn.DoClick = function(s)
                    local p = targetPlayer
                    if IsValid(p) then
                        p:SetMuted(not p:IsMuted())
                    end
                end

                muteBtn.Think = function(s)
                    local p = targetPlayer
                    if IsValid(p) then
                        if p:IsMuted() then
                            s:SetImage("icon16/sound_mute.png")
                        else
                            s:SetImage("icon16/sound.png")
                        end
                    end
                end

                row.PerformLayout = function(s, w, h)
                    if IsValid(muteBtn) then
                        muteBtn:SetPos(w - Nexus:GetScale(90), (h - Nexus:GetScale(20)) / 2)
                    end
                end
            end
            
            self.Rows[targetPlayer] = row
        end
        
        if IsValid(row) then
            row:SetZPos(index)
        end
    end
end

function SCORE_PANEL:Think()
    if CurTime() > self.NextRefresh then
        net.Start("Nexus:Rounds:RequestScoreboard")
        net.SendToServer()
        self.NextRefresh = CurTime() + 1.0
    end
end

function SCORE_PANEL:Paint(w, h)
    surface.SetMaterial(cardBgMat)
    surface.SetDrawColor(20, 20, 25, 245)
    surface.DrawTexturedRect(0, 0, w, h)
end

vgui.Register("NexusScoreboard", SCORE_PANEL, "EditablePanel")

scoreboardInstance = scoreboardInstance or nil

hook.Add("ScoreboardShow", "NexusProcScoreboardShow", function()
    if IsValid(scoreboardInstance) then scoreboardInstance:Remove() end
    scoreboardInstance = vgui.Create("NexusScoreboard")
    scoreboardInstance:SetVisible(true)
    
    -- Request update immediately on show
    net.Start("Nexus:Rounds:RequestScoreboard")
    net.SendToServer()
    
    gui.EnableScreenClicker(true)
    return true
end)

hook.Add("ScoreboardHide", "NexusProcScoreboardHide", function()
    if IsValid(scoreboardInstance) then
        gui.EnableScreenClicker(false)
        local curInstance = scoreboardInstance
        curInstance:AlphaTo(0, 0.15, 0, function()
            if IsValid(curInstance) then
                curInstance:SetVisible(false)
                curInstance:Remove()
            end
        end)
        scoreboardInstance = nil
    end
    return true
end)

-- Dedicated console variable to highlight NPCs & Entities
CreateClientConVar("cl_nexus_highlight", "0", true, false, "Toggle highlighting of all NPCs and key entities through the map.")

hook.Add("PreDrawHalos", "NexusEntityHighlightHalos", function()
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    -- Always highlight drums and engines for everyone, but NOT through walls
    local objectivesNormal = {}
    for _, ent in ipairs(ents.FindByClass("nexus_drum")) do
        if IsValid(ent) then table.insert(objectivesNormal, ent) end
    end
    for _, ent in ipairs(ents.FindByClass("nexus_engine")) do
        if IsValid(ent) then table.insert(objectivesNormal, ent) end
    end

    if #objectivesNormal > 0 then
        halo.Add(objectivesNormal, Color(50, 255, 50), 2, 2, 2, true, false) -- Green outline, NOT through walls
    end

    -- Admin ESP highlighting (through walls)
    if GetConVar("cl_nexus_highlight"):GetInt() == 1 and ply:IsAdmin() then
        local npcs = {}
        local machines = {}
        local objectivesAdmin = {}

        for _, ent in ipairs(ents.GetAll()) do
            if not IsValid(ent) then continue end
            local class = ent:GetClass()

            if ent:IsNPC() or class == "npc_spider" or string.find(class, "spider") or string.find(class, "follower") then
                table.insert(npcs, ent)
            elseif class == "nexus_machine" then
                table.insert(machines, ent)
            elseif class == "nexus_engine" or class == "nexus_drum" or class == "nexus_helicopter" or class == "nexus_spider_egg" then
                table.insert(objectivesAdmin, ent)
            end
        end

        if #npcs > 0 then
            halo.Add(npcs, Color(255, 50, 50), 2, 2, 2, true, true) -- Red for Spiders/Followers/NPCs
        end
        if #machines > 0 then
            halo.Add(machines, Color(50, 180, 255), 2, 2, 2, true, true) -- Cyan for active Machines
        end
        if #objectivesAdmin > 0 then
            halo.Add(objectivesAdmin, Color(50, 255, 50), 2, 2, 2, true, true) -- Green for objectives, eggs, and helicopter
        end
    end
end)
