-- Spawn NPCs at all custom toolgun points on server startup/prep
function spawnNPCsAtPoints()
    local points = Nexus.Proc.NpcSpawns or {}
    if #points == 0 then return end

    -- Organize points by role
    local spawnPointsByRole = {
        ["Random"] = {},
        ["Researcher"] = {},
        ["Mechanic"] = {},
        ["Electrician"] = {},
        ["Chemist"] = {},
        ["Pilot"] = {}
    }

    for _, spawn in ipairs(points) do
        local r = spawn.role or "Random"
        if spawnPointsByRole[r] then
            table.insert(spawnPointsByRole[r], spawn.pos)
        end
    end

    local rolesToSpawn = {"Chemist", "Electrician", "Mechanic", "Pilot", "Researcher"}
    local roleToClass = {
        ["Researcher"] = "nexus_follower_researcher",
        ["Mechanic"] = "nexus_follower_mechanic",
        ["Electrician"] = "nexus_follower_electrician",
        ["Chemist"] = "nexus_follower_chemist",
        ["Pilot"] = "nexus_follower_pilot"
    }

    -- Shuffle the roles to spawn so fallback assignment to "Random" points is randomized
    for i = #rolesToSpawn, 2, -1 do
        local j = math.random(i)
        rolesToSpawn[i], rolesToSpawn[j] = rolesToSpawn[j], rolesToSpawn[i]
    end

    local hasLobbyist = false
    for _, ply in ipairs(player.GetAll()) do
        if Nexus.Proc.HasPerk(ply, "lobbyist") then
            hasLobbyist = true
            break
        end
    end

    if hasLobbyist then
        local homeBase = Nexus.Proc.HomeBase
        for role, plist in pairs(spawnPointsByRole) do
            table.sort(plist, function(a, b)
                return a:DistToSqr(homeBase) < b:DistToSqr(homeBase)
            end)
        end
    end

    for _, role in ipairs(rolesToSpawn) do
        local pos = nil

        -- 1. Try to pick from role-specific points first
        if #spawnPointsByRole[role] > 0 then
            local idx = hasLobbyist and 1 or math.random(#spawnPointsByRole[role])
            pos = spawnPointsByRole[role][idx]
            table.remove(spawnPointsByRole[role], idx)
        -- 2. Fall back to generic "Random" points
        elseif #spawnPointsByRole["Random"] > 0 then
            local idx = hasLobbyist and 1 or math.random(#spawnPointsByRole["Random"])
            pos = spawnPointsByRole["Random"][idx]
            table.remove(spawnPointsByRole["Random"], idx)
        end

        -- Spawn the NPC if we found a valid position
        if pos then
            local class = roleToClass[role]
            local npc = ents.Create(class)
            if IsValid(npc) then
                npc:SetPos(pos + Vector(0, 0, 10))
                npc:Spawn()
                npc:Activate()
            end
        end
    end
end

-- Spawn machines at their designated positions
function spawnMachines()
    -- Clean up existing machines, engines, and drums first to prevent duplicates
    for _, ent in ipairs(ents.FindByClass("nexus_machine")) do
        if IsValid(ent) then ent:Remove() end
    end
    for _, ent in ipairs(ents.FindByClass("nexus_engine")) do
        if IsValid(ent) then ent:Remove() end
    end
    for _, ent in ipairs(ents.FindByClass("nexus_drum")) do
        if IsValid(ent) then ent:Remove() end
    end

    -- Electrician machines
    local machinePositions = {
        { pos = Vector(5944.409668, 1632.822876, -89.554573), sparkPos = Vector(5926.827637, 1630.422729, -105.140030) },
        { pos = Vector(5944.540039, 1696.223389, -89.451347), sparkPos = Vector(5923.626953, 1694.557373, -105.140030) }
    }
    for int, data in ipairs(machinePositions) do
        local mach = ents.Create("nexus_machine")
        if IsValid(mach) then
            mach:SetPos(data.pos)
            mach:SetNWString("Role", "Electrician")
            mach:SetNWFloat("Progress", math.random(0, 30))  -- Random starting progress 0-30%
            mach:SetNWInt("MachineInt", int)
            mach:Spawn()
            mach:Activate()
        end
    end

    -- Mechanic machine (broken airboat engine)
    local mechMach = ents.Create("nexus_machine")
    if IsValid(mechMach) then
        mechMach:SetPos(Vector(6067.820801, 1804.301758, -81.415100))
        mechMach:SetAngles(Angle(0.018, -15.586, 0.017))
        mechMach:SetNWString("Role", "Mechanic")
        mechMach:SetNWFloat("Progress", math.random(0, 30))  -- Random starting progress 0-30%
        mechMach:SetNWBool("IsSocketed", false)
        mechMach:Spawn()
        mechMach:Activate()
    end

    -- Chemist machines (explosive oil drums)
    local chemistPositions = {
        { pos = Vector(6180.840332, 1655.810791, -79.890900), ang = Angle(85.204, -3.138, -89.545) },
        { pos = Vector(6178.056641, 1587.597168, -80.409500), ang = Angle(14.525, 174.656, 89.991) }
    }
    for _, data in ipairs(chemistPositions) do
        local mach = ents.Create("nexus_machine")
        if IsValid(mach) then
            mach:SetNWString("Role", "Chemist")
            mach:SetPos(data.pos)
            mach:SetAngles(data.ang)
            mach:SetNWFloat("Progress", math.random(0, 30))  -- Random starting progress 0-30%
            mach:SetNWBool("IsSocketed", false)
            mach:Spawn()
            mach:Activate()
        end
    end

    -- Determine spawn positions for carryable items (1x engine, 2x drums)
    local enginePos = Vector(5850.0, 1650.0, -85.0)
    local drumPos = {
        Vector(6040, 1655, -80),
        Vector(6040, 1587, -80)
    }

    if Nexus.Proc.ItemSpawns and #Nexus.Proc.ItemSpawns >= 3 then
        local pool = {}
        for _, p in ipairs(Nexus.Proc.ItemSpawns) do
            table.insert(pool, p.pos)
        end

        local hasScavenger = false
        for _, ply in ipairs(player.GetAll()) do
            if Nexus.Proc.HasPerk(ply, "scavenger") then
                hasScavenger = true
                break
            end
        end

        if hasScavenger then
            table.sort(pool, function(a, b)
                return a:DistToSqr(Nexus.Proc.HomeBase) < b:DistToSqr(Nexus.Proc.HomeBase)
            end)
        end

        local chosenPoints = {}
        for i = 1, 3 do
            local idx = hasScavenger and 1 or math.random(1, #pool)
            table.insert(chosenPoints, table.remove(pool, idx))
        end

        enginePos = chosenPoints[1]
        drumPos = { chosenPoints[2], chosenPoints[3] }
    end

    -- Spawn the carryable engine item
    local carryEng = ents.Create("nexus_engine")
    if IsValid(carryEng) then
        carryEng:SetPos(enginePos + Vector(0, 0, 10))
        carryEng:Spawn()
        carryEng:Activate()
    end

    -- Spawn empty carryable drums
    for _, pos in ipairs(drumPos) do
        local drum = ents.Create("nexus_drum")
        if IsValid(drum) then
            drum:SetPos(pos + Vector(0, 0, 10))
            drum:Spawn()
            drum:Activate()
        end
    end

    -- Researcher machine station
    local resMach = ents.Create("nexus_machine")
    if IsValid(resMach) then
        resMach:SetPos(Vector(5602.710938, 1472.927246, -90.200165))
        resMach:SetNWString("Role", "Researcher")
        resMach:SetNWFloat("Progress", math.random(0, 30))  -- Random starting progress 0-30%
        resMach:Spawn()
        resMach:Activate()
    end
end

-- Spawn eggs at all custom toolgun points on server startup
function spawnEggsAtPoints()
    local points = Nexus.Proc.EggSpawns or {}
    for _, basePos in ipairs(points) do
        -- Choose cluster size: 1, 2, or 3 eggs
        local clusterSize = math.random(1, 3)
        for i = 1, clusterSize do
            local egg = ents.Create("nexus_spider_egg")
            if IsValid(egg) then
                -- Add minor random offset for eggs 2 and 3 so they form a cluster without clipping perfectly
                local offset = (i == 1) and Vector(0, 0, 0) or Vector(math.random(-25, 25), math.random(-25, 25), 0)
                egg:SetPos(basePos + offset + Vector(0, 0, 10))
                egg:SetAngles(Angle(-90, math.random(0, 360), 0))
                egg:Spawn()
                egg:Activate()
            end
        end
    end
end

hook.Add("InitPostEntity", "NexusProcSpawnInitialEggs", function()
    -- Ensure points are loaded
    if not Nexus.Proc.EggSpawns or #Nexus.Proc.EggSpawns == 0 then
        local filePath = "nexus_proc/egg_spawns_" .. game.GetMap() .. ".json"
        if file.Exists(filePath, "DATA") then
            local data = file.Read(filePath, "DATA")
            Nexus.Proc.EggSpawns = util.JSONToTable(data) or {}
        end
    end

    if not Nexus.Proc.NpcSpawns or #Nexus.Proc.NpcSpawns == 0 then
        local npcFilePath = "nexus_proc/npc_spawns_" .. game.GetMap() .. ".json"
        if file.Exists(npcFilePath, "DATA") then
            local data = file.Read(npcFilePath, "DATA")
            local raw = util.JSONToTable(data) or {}
            Nexus.Proc.NpcSpawns = {}
            for _, v in ipairs(raw) do
                if v.pos and v.role then
                    table.insert(Nexus.Proc.NpcSpawns, {
                        pos = Vector(v.pos[1], v.pos[2], v.pos[3]),
                        role = v.role
                    })
                end
            end
        end
    end
end)
