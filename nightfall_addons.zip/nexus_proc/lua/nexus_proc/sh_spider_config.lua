-- sh_spider_config.lua
-- Shared constants, gene system, and IK math for Nexus procedural spider enemies.
-- Loaded on BOTH server and client. Both sides call GenerateGenes(seed) with
-- the same seed so visual properties are identical without extra networking.

Nexus.Proc        = Nexus.Proc or {}
Nexus.Proc.Spider = Nexus.Proc.Spider or {}
local Spider      = Nexus.Proc.Spider

-- ─────────────────────────────────────────────────────────────────────────────
-- Net string identifiers (util.AddNetworkString called in sv_spider.lua)
-- ─────────────────────────────────────────────────────────────────────────────
Spider.NET_SYNC  = "NexusProc:Spider:Sync"
Spider.NET_SPAWN = "NexusProc:Spider:Spawn"
Spider.NET_DIE   = "NexusProc:Spider:Die"

-- ─────────────────────────────────────────────────────────────────────────────
Spider.DETECT_RANGE  = 1200   -- units: player enters awareness
Spider.CHASE_RANGE   = 900    -- units: full sprint chase begins
Spider.ATTACK_RANGE  = 70     -- units: melee reach
Spider.ATTACK_RATE   = 1.2    -- seconds between bites

-- ─────────────────────────────────────────────────────────────────────────────
-- Leg / IK Constants
-- ─────────────────────────────────────────────────────────────────────────────
Spider.LEG_COUNT       = 8
Spider.STEP_THRESHOLD  = 35    -- units the body moves before triggering a step
Spider.STEP_DURATION   = 0.06  -- seconds per step arc
Spider.STEP_ARC_HEIGHT = 20    -- units a foot rises during a step
Spider.SYNC_RATE       = 0.05  -- seconds between server→client syncs (~20 Hz)

-- Leg root definitions: angle from forward (yaw offset) + forward bias.
-- Right side = legs 1-4, Left side = legs 5-8.
Spider.LEG_ROOTS = {
    [1] = { ang = -30, fwd =  0.65 }, -- Front-Right
    [2] = { ang = -68, fwd =  0.10 },
    [3] = { ang = -112, fwd = -0.10 },
    [4] = { ang = -150, fwd = -0.65 }, -- Back-Right
    [5] = { ang =  30, fwd =  0.65 },  -- Front-Left
    [6] = { ang =  68, fwd =  0.10 },
    [7] = { ang =  112, fwd = -0.10 },
    [8] = { ang =  150, fwd = -0.65 }, -- Back-Left
}

-- Pairs of legs that step together (alternating gait).
Spider.STEP_GROUPS = {
    { 1, 7 },
    { 3, 5 },
    { 2, 8 },
    { 4, 6 },
}

-- ─────────────────────────────────────────────────────────────────────────────
-- Deterministic PRNG (LCG) — same seed → same sequence on any realm
-- ─────────────────────────────────────────────────────────────────────────────
local function makePRNG(seed)
    local s = (seed or 12345) % 4294967296
    return function(lo, hi)
        s = (s * 1664525 + 1013904223) % 4294967296
        local t = s / 4294967296
        return lo and hi and (lo + t * (hi - lo)) or t
    end
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Gene Generation
-- ─────────────────────────────────────────────────────────────────────────────

---Generate a procedural gene table for one spider.
---@param seed  number  Integer seed (use EntIndex * prime)
---@return table
function Spider.GenerateGenes(seed)
    local r = makePRNG(seed)

    -- Stats (health generated first so size can be derived from it)
    local speed  = r(340,  420)  -- INCREASED SPEED: Formerly r(260, 340)
    local health = r(45,  80)
    local damage = r(5,   12)

    -- Size scales with health: weaker spiders are smaller, tougher ones are larger
    local healthT       = (health - 45) / (80 - 45)  -- 0.0 (weakest) to 1.0 (strongest)
    local bodyRadius    = 7  + healthT * (16 - 7)        -- 7 to 16
    local abdomenRadius = 12 + healthT * (24 - 12)       -- 12 to 24

    local legLength1    = r(17, 28)  -- femur
    local legLength2    = r(15, 26)  -- tibia
    local legLength3    = r(12, 22)  -- tarsus/foot segment
    local legSpread     = r(0.88, 1.40)

    -- HSV colour (dark palette: blacks, browns, dark teals)
    local hue = r(0, 360)
    local sat = r(0.10, 0.55)
    local val = r(0.04, 0.22)

    -- Eyes
    local eyeCount  = math.floor(r(0, 5) + 0.5) + 4  -- 4, 5, 6, 7, or 8
    local eyeGlow   = r(0.55, 1.0)
    local eyeColorR = r(0.45, 1.0)
    local eyeColorG = r(0.00, 0.35)
    local eyeColorB = r(0.00, 0.30)

    local bodyHeight = (legLength1 + legLength2 + legLength3) * r(0.36, 0.48)

    return {
        seed          = seed,
        bodyRadius    = bodyRadius,
        abdomenRadius = abdomenRadius,
        bodyHeight    = bodyHeight,
        legLength1    = legLength1,
        legLength2    = legLength2,
        legLength3    = legLength3,
        legSpread     = legSpread,
        hue           = hue,
        sat           = sat,
        val           = val,
        eyeCount      = eyeCount,
        eyeGlow       = eyeGlow,
        eyeColorR     = eyeColorR,
        eyeColorG     = eyeColorG,
        eyeColorB     = eyeColorB,
        speed         = speed,
        health        = health,
        damage        = damage,
    }
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Colour Helper
-- ─────────────────────────────────────────────────────────────────────────────

---Convert HSV (0-360, 0-1, 0-1) to a GMod Color.
function Spider.HSVtoColor(h, s, v, a)
    h = h % 360
    local i = math.floor(h / 60) % 6
    local f = (h / 60) - math.floor(h / 60)
    local p = v * (1 - s)
    local q = v * (1 - f * s)
    local t = v * (1 - (1 - f) * s)
    local lut = {
        [0] = { v, t, p },
        [1] = { q, v, p },
        [2] = { p, v, t },
        [3] = { p, q, v },
        [4] = { t, p, v },
        [5] = { v, p, q },
    }
    local c = lut[i]
    return Color(c[1] * 255, c[2] * 255, c[3] * 255, a or 255)
end

-- ─────────────────────────────────────────────────────────────────────────────
-- 2-Bone Analytic IK Solver  (client uses this for leg rendering)
-- ─────────────────────────────────────────────────────────────────────────────

---Solve a 2-bone IK chain analytically.
---Returns: mid (knee) Vector, tip (possibly clamped foot) Vector
---@param root   Vector  Shoulder / leg root
---@param target Vector  Desired foot position
---@param len1   number  Femur length
---@param len2   number  Tibia length
---@param hint   Vector  Direction the knee should prefer (normalised)
function Spider.SolveTwoBone(root, target, len1, len2, hint, flip)
    local diff = target - root
    local dist = diff:Length()
    local maxR = len1 + len2 - 0.1
    local minR = math.abs(len1 - len2) + 0.1

    -- Clamp foot to reachable shell
    if dist > maxR then
        dist   = maxR
        target = root + diff:GetNormalized() * dist
        diff   = target - root
    elseif dist < minR then
        dist   = minR
        target = root + diff:GetNormalized() * dist
        diff   = target - root
    end

    local dir = diff:GetNormalized()

    -- Angle at root via law of cosines
    local cosA = math.Clamp(
        (len1 * len1 + dist * dist - len2 * len2) / (2 * len1 * dist),
        -1, 1
    )
    local angA = math.acos(cosA)

    -- Perpendicular (knee swing axis) from hint
    local perp = dir:Cross(hint)
    if perp:LengthSqr() < 0.0001 then
        local alt = math.abs(dir.z) < 0.9 and Vector(0, 0, 1) or Vector(1, 0, 0)
        perp = dir:Cross(alt)
    end
    perp:Normalize()

    if flip then
        perp = -perp
    end

    local mid = root
              + dir  * (len1 * math.cos(angA))
              + perp * (len1 * math.sin(angA))

    return mid, target
end
