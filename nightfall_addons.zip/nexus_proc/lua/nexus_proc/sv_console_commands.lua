concommand.Add("nexus_max_machines", function(ply, cmd, args)
    if IsValid(ply) and not ply:IsSuperAdmin() then return end

    for _, ent in ipairs(ents.FindByClass("nexus_machine")) do
        if not IsValid(ent) then continue end
        ent:SetNWFloat("Progress", 100.0)

        local role = ent:GetNWString("Role", "")
        local roleData = Nexus.Proc:GetRoleData(role)
        if roleData.RequiresSocketedEquipment then
            ent:SetNWBool("IsSocketed", true)
        end
    end

    if IsValid(ply) then
        Nexus:ChatMessage(ply, {color_white, "[ System ] ", "Socketed and maxed out all of the machines."})
    else
        print("[ System ] Socketed and maxed out all of the machines.")
    end
end)

concommand.Add("nexus_spawn_mother", function(ply, cmd, args)
    if not IsValid(ply) then return end
    if not ply:IsSuperAdmin() then return end

    local mother = ents.Create("nexus_mother_spider")
    if not IsValid(mother) then return end

    local tr = ply:GetEyeTrace()
    local spawnPos = tr.HitPos + tr.HitNormal * 15

    mother:SetPos(spawnPos)
    mother:Spawn()
    mother:Activate()
end)

concommand.Add("nexus_advance_time", function(ply, cmd, args)
    if not IsValid(ply) then return end
    if not ply:IsSuperAdmin() then return end

    local seconds = tonumber(args[1]) or 0
    if seconds == 0 then
        Nexus:ChatMessage(ply, {color_white, "[ System ] ", "Incorrect Use. nexus_advance_time seconds"})
        return
    end

    SetGlobalFloat("NightFall:Round:EndCurTime", GetGlobalFloat("NightFall:Round:EndCurTime", 0) - seconds)
    SetGlobalFloat("NightFall:SetExtractionEndTime", GetGlobalFloat("NightFall:SetExtractionEndTime", 0) - seconds)

    Nexus:ChatMessage(ply, {color_white, "[ System ] ", "Advanced time by "..seconds.." seconds."})
end)

concommand.Add("nexus_advance_stage", function(ply, cmd, args)
    if not IsValid(ply) then return end
    if not ply:IsSuperAdmin() then return end

    local state = GetGlobalInt("NightFall:RoundState", ROUND_WAITING)
    if state == ROUND_ACTIVE then
        local anyExtracted = false
        for _, p in ipairs(player.GetAll()) do
            if p.HasExtracted then
                anyExtracted = true
                break
            end
        end
        state = anyExtracted and ROUND_VICTORY or ROUND_DEFEAT
    elseif state == ROUND_VICTORY or state == ROUND_DEFEAT then
        state = ROUND_WAITING
    else
        state = state + 1
    end

    Nexus.Proc.Rounds.SetState(state)
end)

concommand.Add("nexus_give_perkpoints", function(ply, cmd, args)
    if IsValid(ply) and not ply:IsSuperAdmin() then return end

    local targetName = args[1]
    local amount = tonumber(args[2]) or 1

    if not targetName then
        if IsValid(ply) then
            ply:ChatPrint("[Perks] Usage: nexus_give_perkpoints <player_name> <amount>")
        end
        return
    end

    local target = nil
    for _, p in ipairs(player.GetAll()) do
        if string.find(string.lower(p:Nick()), string.lower(targetName)) then
            target = p
            break
        end
    end

    if not IsValid(target) then
        if IsValid(ply) then
            ply:ChatPrint("[Perks] Player not found!")
        end
        return
    end

    if target.StatsAggregated then
        target.StatsAggregated.perkPoints = (target.StatsAggregated.perkPoints or 0) + amount
        Nexus.Proc.SavePlayerStats(target)
        Nexus.Proc.SyncPerks(target)

        if IsValid(ply) then
            ply:ChatPrint("[Perks] Gave " .. amount .. " Perk Point(s) to " .. target:Nick())
        end
        target:ChatPrint("[Perks] You received " .. amount .. " Perk Point(s) from an administrator!")
    end
end)

concommand.Add("nexus_loadout_info", function(ply, cmd, args)
    if not IsValid(ply) then return end
    if not ply:IsSuperAdmin() then return end

    -- Optionally target another player via name arg
    local target = ply
    if args[1] then
        for _, p in ipairs(player.GetAll()) do
            if string.lower(p:Nick()):find(string.lower(args[1]), 1, true) then
                target = p
                break
            end
        end
    end

    local loadout = target.NexusLoadout
    if not loadout then
        ply:ChatPrint("[Loadout] " .. target:Nick() .. " has no saved loadout yet.")
        return
    end

    ply:ChatPrint("=== LOADOUT: " .. target:Nick() .. " ===")
    ply:ChatPrint("  Primary:   " .. tostring(loadout.primary))
    ply:ChatPrint("  Secondary: " .. tostring(loadout.secondary))

    if loadout.attachments then
        for wepClass, slots in pairs(loadout.attachments) do
            ply:ChatPrint("  [" .. wepClass .. "] Attachments:")
            for slotStr, att in pairs(slots) do
                if att and att ~= "" then
                    ply:ChatPrint("    Slot " .. slotStr .. ": " .. att)
                end
            end
        end
    else
        ply:ChatPrint("  (No attachments saved)")
    end
    ply:ChatPrint("===================")
end)

util.AddNetworkString("NightFall:Debug:ResetPlayer")

local function resetPlayerData(target, caller)
    if not IsValid(target) then return end

    -- 1. Delete stats JSON file
    local statsPath = "nexus_proc/stats/" .. target:SteamID64() .. ".json"
    if file.Exists(statsPath, "DATA") then
        file.Delete(statsPath)
    end

    -- 2. Wipe in-memory stats
    target.StatsAggregated = {
        wins = 0, plays = 0, spiders = 0, dmg = 0,
        npcs = 0, dist = 0, revived = 0, downed = 0,
        perkPoints = 0, unlockedPerks = {}, equippedPerks = {}
    }

    -- 3. Wipe loadout PData
    target:SetPData("nexus_loadout", "")

    -- 4. Wipe all weapon unlock PData
    for _, w in ipairs(Nexus.Proc.Weapons.List or {}) do
        target:SetPData("nexus_weapon_unlocked_" .. w.class, "0")
    end

    -- 5. Clear in-memory loadout
    target.NexusLoadout = nil

    -- 6. Sync cleared perks to client
    Nexus.Proc.SyncPerks(target)

    -- 7. Sync cleared weapon unlocks to client
    Nexus.Proc.Weapons.SyncToClient(target)

    local msg = "[Reset] " .. target:Nick() .. " has been fully wiped (simulating new user)."
    if IsValid(caller) then
        caller:ChatPrint(msg)
    end
    target:ChatPrint("[Reset] Your data has been wiped. Reconnect or respawn to take effect.")
    print(msg)
end

concommand.Add("nexus_reset_player", function(ply, cmd, args)
    if IsValid(ply) and not ply:IsSuperAdmin() then return end

    local target = ply
    if args[1] then
        for _, p in ipairs(player.GetAll()) do
            if string.lower(p:Nick()):find(string.lower(args[1]), 1, true) then
                target = p
                break
            end
        end
    end

    resetPlayerData(target, ply)
end)

-- Client can trigger a self-reset via a net message (SuperAdmin only)
net.Receive("NightFall:Debug:ResetPlayer", function(len, ply)
    if not IsValid(ply) or not ply:IsSuperAdmin() then return end
    resetPlayerData(ply, ply)
end)