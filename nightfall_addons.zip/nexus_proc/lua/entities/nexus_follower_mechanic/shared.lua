ENT.Type = "nextbot"
ENT.Base = "nexus_follower"
ENT.PrintName = "Mechanic"
ENT.Category = "Night Fall"
ENT.Spawnable = true

ENT.Role = "Mechanic"