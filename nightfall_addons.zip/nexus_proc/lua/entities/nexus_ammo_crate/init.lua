AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
    self:SetModel("models/items/ammocrate_ar2.mdl")
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:Wake()
    end
end

local function ClampedGiveAmmo(ply, ammo, amt, clamp)
    local count = ply:GetAmmoCount(ammo)

    if count >= clamp then
        return false
    elseif count + amt > clamp then
        amt = math.max(clamp - count, 0)
    end

    ply:GiveAmmo(amt, ammo)

    return true
end

function ENT:Use(ply)
    local wpn = ply:GetActiveWeapon()

    local ammotype = wpn:GetPrimaryAmmoType()
    local clipsize = wpn:GetMaxClip1()
    local supplyamount = clipsize
    local max = clipsize * 6

    local t2

    if wpn.ARC9 then
        ammotype = wpn:GetProcessedValue("Ammo")
        clipsize = wpn:GetProcessedValue("ClipSize")
        max = wpn:GetProcessedValue("SupplyLimit") * clipsize

        if max <= 0 then
            max = 1
        end

        if wpn:GetProcessedValue("UBGL") then
            local ammotype2 = wpn:GetProcessedValue("UBGLAmmo")
            local clipsize2 = wpn:GetProcessedValue("UBGLClipSize")
            local supplyamount2 = clipsize2 * 1
            local max2 = clipsize2 * wpn:GetProcessedValue("SecondarySupplyLimit")

            t2 = ClampedGiveAmmo(ply, ammotype2, supplyamount2, max2)
        end
    end

    local t = ClampedGiveAmmo(ply, ammotype, supplyamount, max)
end