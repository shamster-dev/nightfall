ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Ammo Crate"
ENT.Category = "Night Fall"
ENT.Spawnable = true