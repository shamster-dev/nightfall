ENT.Type = "nextbot"
ENT.Base = "nexus_follower"
ENT.PrintName = "Pilot"
ENT.Category = "Night Fall"
ENT.Spawnable = true

ENT.Role = "Pilot"