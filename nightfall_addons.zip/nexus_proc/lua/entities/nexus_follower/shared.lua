ENT.Type = "nextbot"
ENT.Base = "base_nextbot"
ENT.PrintName = "Follower NPC"
ENT.Category = "Night Fall"
ENT.Spawnable = false

ENT.Role = Nexus.Proc.Roles[math.random(#Nexus.Proc.Roles)].Name