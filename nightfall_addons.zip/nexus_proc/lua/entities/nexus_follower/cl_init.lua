include("shared.lua")

function ENT:Draw()
    self:DrawModel()

    local localPlayer = LocalPlayer()
    if not IsValid(localPlayer) then return end

    local eyePos = EyePos()
    local selfPos = self:GetPos()
    if eyePos:DistToSqr(selfPos) > (800 * 800) then return end

    local pos = selfPos + Vector(0, 0, 82)
    local ang = localPlayer:EyeAngles()
    
    ang:RotateAroundAxis(ang:Forward(), 90)
    ang:RotateAroundAxis(ang:Right(), 90)

    cam.Start3D2D(pos, ang, 0.15)
        local roleData = Nexus.Proc:GetRoleData(self.Role)

        local titleFont = Nexus:GetFont({size = 32, font="Lato", bold=true, dontScale=true})
        local descriptionFont = Nexus:GetFont({size = 22, font="Lato", dontScale=true})

        local title = string.upper(roleData.Name)
        surface.SetFont(titleFont)
        local w1, h1 = surface.GetTextSize(title)

        local statusText = self:GetNWString("StatusText", "IDLE")
        surface.SetFont(descriptionFont)
        local w2, h2 = surface.GetTextSize(statusText)

        local boxW = math.max(w1, w2) + 40
        local boxH = h1 + h2 + 25

        Nexus.RNDX.Draw(8, -boxW / 2, -boxH / 2, boxW, boxH, Nexus:SetAlpha(Nexus:GetColor("background"), 175))

        local statusColor = string.StartWith(statusText, "MOVING") and Nexus:GetColor("orange") or roleData.Color
        surface.SetDrawColor(statusColor.r, statusColor.g, statusColor.b, 100)
        surface.DrawOutlinedRect(-boxW / 2, -boxH / 2, boxW, boxH, 2)

        draw.SimpleText(title, titleFont, 0, -boxH / 2 + 10, Nexus:GetTextColor(Nexus:GetColor("background")), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        draw.SimpleText(statusText, descriptionFont, 0, -boxH / 2 + 15 + h1, statusColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    cam.End3D2D()
end