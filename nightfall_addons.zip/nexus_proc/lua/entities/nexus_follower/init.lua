AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
    self:SetUseType(SIMPLE_USE)

    self.FollowTarget = nil

    local roleData = Nexus.Proc:GetRoleData(self.Role)
    self:SetModel(roleData.Model)

    self.loco:SetDesiredSpeed(200)
    self.loco:SetAcceleration(400)
    self.loco:SetDeceleration(400)

    timer.Simple(0, function()
        if not IsValid(self) then return end
        if not roleData.WeaponModel then return end

        local weapon = ents.Create("prop_dynamic")
        if not IsValid(weapon) then return end
        weapon:SetModel(roleData.WeaponModel)
        weapon:SetParent(self)
        weapon:Fire("SetParentAttachment", "anim_attachment_RH")
        weapon:SetLocalPos(Vector(0, 0, 0))
        weapon:SetLocalAngles(Angle(0, 0, 0))
        weapon:Spawn()

        self.WeaponProp = weapon
    end)
end

function ENT:Use(activator, caller)
    if not IsValid(activator) or not activator:IsPlayer() then return end

    local roleData = Nexus.Proc:GetRoleData(self.Role)

    if Nexus.Proc.IsExtractionActive then
        Nexus:ChatMessage(activator, {roleData.Color, "[ "..roleData.Name.." ] ", "We must evacuate."})
        return
    end

    if self.CannotFollow then
        Nexus:ChatMessage(activator, {roleData.Color, "[ "..roleData.Name.." ] ", "I must stay at my station."})
        return
    end

    // Stop following the player
    if self.FollowTarget == activator then
        Nexus:ChatMessage(activator, {roleData.Color, "[ "..roleData.Name.." ] ", "I have stopped following you."})
        self:EmitSound("vo/npc/male01/ok01.wav")

        self.FollowTarget = nil
        return
    end

    local state = GetGlobalInt("NightFall:RoundState", ROUND_WAITING)
    if not (state == ROUND_ACTIVE and activator.IsRoundParticipant) then return end

    // Follow the player
    self.FollowTarget = activator

    Nexus:ChatMessage(activator, {roleData.Color, "[ "..roleData.Name.." ] ", "I am following you."})
    self:EmitSound("vo/npc/male01/question30.wav")

    // Update the users statistics
    activator.StatFollowedThisRound = activator.StatFollowedThisRound or {}

    if not activator.StatFollowedThisRound[self] then
        activator.StatFollowedThisRound[self] = true
        activator.StatNPCsFollowed = (activator.StatNPCsFollowed or 0) + 1
    end
end

function ENT:CheckStationIsNear()
    if self.CannotFollow then return false end

    local roleData = Nexus.Proc:GetRoleData(self.Role)
    for _, ent in ipairs(ents.FindByClass("nexus_machine")) do
        if not (IsValid(ent) and ent:GetNWString("Role", "") == self.Role and ent:GetNWFloat("Progress", 0) < 100) then continue end
        if self:GetPos():DistToSqr(ent:GetPos()) > (1500 * 1500) then continue end

        self.CannotFollow = true
        if IsValid(self.FollowTarget) then
            Nexus:ChatMessage(self.FollowTarget, {roleData.Color, "[ "..roleData.Name.." ] ", "I must goto my station, thank you!"})
            self.FollowTarget = nil
        end

        self:EmitSound("vo/npc/male01/ok01.wav")
        return true
    end

    return false
end

function ENT:RunBehaviour()
    local roleData = Nexus.Proc:GetRoleData(self.Role)
    while IsValid(self) do
        local loco = self.loco
        local target = self.FollowTarget
        local role = self.Role

        // Run this mofo to the extraction point
        if Nexus.Proc.IsExtractionActive then
            self.CannotFollow = true
            self:SetNWString("StatusText", "EVACUATING")

            local extPos = Nexus.Proc.ExtractionPosition["End"]
            loco:SetDesiredSpeed(250)
            self:StartActivity(ACT_RUN)

            local path = Path("Follow")
            path:SetMinLookAheadDistance(30)
            path:Compute(self, extPos)

            local nextRecompute = 0
            while IsValid(self) and Nexus.Proc.IsExtractionActive do
                local distSqr = self:GetPos():DistToSqr(extPos)
                if distSqr <= (120 * 120) then
                    // Reached chopper, wait
                    self:StartActivity(ACT_IDLE)
                    loco:SetDesiredSpeed(0)

                    coroutine.wait(1)
                    continue
                end

                // Continue walking to extraction point
                if CurTime() >= nextRecompute then
                    nextRecompute = CurTime() + 1
                    path:Compute(self, extPos)
                end

                path:Update(self)
                coroutine.wait(0.05)
            end

            coroutine.yield()
            continue
        end

        // We are following a player
        if IsValid(self.FollowTarget) and self.FollowTarget:Alive() then
            self:SetNWString("StatusText", "FOLLOWING: " .. string.upper(self.FollowTarget:Nick()))

            local targetPos = self.FollowTarget:GetPos()
            local distSqr = self:GetPos():DistToSqr(targetPos)

            // Player got too far away
            if distSqr > (1000 * 1000) then
                Nexus:ChatMessage(self.FollowTarget, {roleData.Color, "[ "..roleData.Name.." ] ", "I lost track of you. (too far)"})
                self:EmitSound("vo/npc/male01/lostcontrol01.wav")

                self.FollowTarget = nil
                coroutine.yield()
                continue
            end

            // Start moving towards the player
            if distSqr > (240 * 240) then
                if distSqr > (450 * 450) then
                    loco:SetDesiredSpeed(250)
                    self:StartActivity(ACT_RUN)
                else
                    loco:SetDesiredSpeed(130)
                    self:StartActivity(ACT_WALK)
                end

                local path = Path("Follow")
                path:SetMinLookAheadDistance(30)
                path:Compute(self, targetPos)

                local nextCompute = 0
                while IsValid(self) and IsValid(self.FollowTarget) and self.FollowTarget:Alive() and self.FollowTarget == self.FollowTarget do
                    if self:CheckStationIsNear() then
                        break
                    end

                    local dSqr = self:GetPos():DistToSqr(self.FollowTarget:GetPos())
                    if dSqr <= (90 * 90) then break end

                    if dSqr > (1000 * 1000) then                        
                        self.FollowTarget:PrintMessage(HUD_PRINTTALK, "[" .. self.Role .. "] Lost track of you (too far).")
                        self:EmitSound("vo/npc/male01/lostcontrol01.wav")

                        self.FollowTarget = nil
                        break
                    end

                    if CurTime() >= nextCompute then
                        nextCompute = CurTime() + 0.5
                        path:Compute(self, self.FollowTarget:GetPos())
                    end

                    path:Update(self)
                    coroutine.wait(0.05)
                end

                coroutine.yield()
                continue
            end

            // We are close enough to the player
            self:StartActivity(ACT_IDLE)
            loco:SetDesiredSpeed(0)

            local dir = targetPos - self:GetPos()
            dir.z = 0
            if dir:LengthSqr() > 0.001 then
                self:SetAngles(dir:Angle())
            end

            coroutine.yield()
            continue
        end

        // We are not following a player or they are dead
        self.FollowTarget = nil

        // Try to find a machine we can work on
        local closestMachine = nil
        local closestDist = math.huge
        for _, ent in ipairs(ents.FindByClass("nexus_machine")) do
            if not (IsValid(ent) and ent:GetNWString("Role", "") == self.Role and ent:GetNWFloat("Progress", 0) < 100) then continue end

            local dist = self:GetPos():DistToSqr(ent:GetPos())
            if not (dist <= (1500 * 1500) and dist < closestDist) then continue end
            closestDist = dist
            closestMachine = ent
        end

        // No machine found
        if not IsValid(closestMachine) then
            self:SetNWString("StatusText", "IDLE")

            loco:SetDesiredSpeed(0)
            self:StartActivity(ACT_IDLE)

            coroutine.wait(1)
            continue
        end

        // We found a machine!!!!
        local distSqr = self:GetPos():DistToSqr(closestMachine:GetPos())
        if distSqr > (70 * 70) then
            // Walk towards the machine
            self:SetNWString("StatusText", roleData.WalkingToStationText or "MOVING TO STATION")

            loco:SetDesiredSpeed(130)
            self:StartActivity(ACT_WALK)

            local path = Path("Follow")
            path:SetMinLookAheadDistance(30)
            path:Compute(self, closestMachine:GetPos())

            local nextRecompute = 0
            while IsValid(self) and IsValid(closestMachine) and not IsValid(self.FollowTarget) and closestMachine:GetNWFloat("Progress", 0) < 100 do
                local dS = self:GetPos():DistToSqr(closestMachine:GetPos())
                if dS <= (70 * 70) then break end

                if CurTime() >= nextRecompute then
                    nextRecompute = CurTime() + 1
                    path:Compute(self, closestMachine:GetPos())
                end

                path:Update(self)
                coroutine.wait(0.05)
            end

            coroutine.yield()
            continue
        end

        // We are at the machine, face it
        loco:SetDesiredSpeed(0)
        self:StartActivity(ACT_IDLE)

        local dir = closestMachine:GetPos() - self:GetPos()
        dir.z = 0
        if dir:LengthSqr() > 0.001 then
            self:SetAngles(dir:Angle())
        end

        local allPartsSocketed = true
        if roleData.RequiresSocketedEquipment then
            allPartsSocketed = closestMachine:GetNWBool("IsSocketed", false)
        end

        if allPartsSocketed then
            local status = roleData.StationText or "REPAIRING"
            self:SetNWString("StatusText", status)

            self:RestartGesture(ACT_HL2MP_GESTURE_RANGE_ATTACK_MELEE)

            local func = roleData.OnMachineProgression and roleData.OnMachineProgression or function(ent, closestMachine)
                ent:EmitSound("weapons/stunstick/spark" .. math.random(1, 3) .. ".wav", 75, 100)

                local effect = EffectData()
                effect:SetOrigin(closestMachine:GetPos() + Vector(0, 0, 15))
                effect:SetNormal(Vector(0, 0, 1))
                util.Effect("cball_bounce", effect)
            end
            func(self, closestMachine)

            local curProg = closestMachine:GetNWFloat("Progress", 0)
            local toAdd = math.Rand(roleData.ProgessionPerFix[1], roleData.ProgessionPerFix[2])

            -- Apply perk multiplier if players with Chief Engineer are nearby (within 500 units)
            local mechanicCount = 0
            for _, ply in ipairs(player.GetAll()) do
                if IsValid(ply) and ply:Alive() and ply:GetPos():DistToSqr(self:GetPos()) <= 250000 then
                    if Nexus.Proc.HasPerk(ply, "mechanic_1") then
                        mechanicCount = mechanicCount + 1
                    end
                end
            end
            
            -- Read stacking variables from config
            local speedAdd = (Nexus.Proc.PerkSettings and Nexus.Proc.PerkSettings.MechanicSpeedAdd) or 0.25
            local maxStack = (Nexus.Proc.PerkSettings and Nexus.Proc.PerkSettings.MechanicMaxStack) or 3
            
            local repairSpeedMult = 1.0 + (math.min(mechanicCount, maxStack) * speedAdd)
            toAdd = toAdd * repairSpeedMult

            local newProg = math.min(curProg + toAdd, 100)
            closestMachine:SetNWFloat("Progress", newProg)

            if newProg >= 100 then
                self:EmitSound("vo/npc/male01/nice01.wav")
                self:EmitSound("buttons/button1.wav")
            end

            coroutine.wait(math.Rand(3, 5))
            continue
        end

        // Wait for parts to be socketed
        local waitStatus = roleData.WaitingForSocketItem
        self:SetNWString("StatusText", waitStatus)
        coroutine.wait(1)
    end
end

function ENT:BodyUpdate()
    self:FrameAdvance()
end

function ENT:OnRemove()
    if not IsValid(self.WeaponProp) then return end
    self.WeaponProp:Remove()
end

function ENT:OnTakeDamage(dmginfo)
    return 0
end