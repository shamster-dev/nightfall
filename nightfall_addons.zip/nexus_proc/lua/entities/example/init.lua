AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
end