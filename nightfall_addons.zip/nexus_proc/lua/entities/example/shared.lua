ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Example Entity"
ENT.Category = "Night Fall"
ENT.Spawnable = false