ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Empty Drum"
ENT.Category = "Night Fall"
ENT.Spawnable = true