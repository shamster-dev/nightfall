AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
    self:SetModel("models/props_hive/websackhalf.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_NONE)
    self:SetUseType(SIMPLE_USE)

    self:SetMaxHealth(50)
    self:SetHealth(50)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:EnableMotion(false)
    end
end

local function spawnSpider(pos, angleOffset)
    local pool = {}
    local totalWeight = 0
    
    if Nexus and Nexus.Proc and Nexus.Proc.Spiders then
        for spiderClass, percentage in pairs(Nexus.Proc.Spiders) do
            if Nexus.Proc.SpiderBosses and Nexus.Proc.SpiderBosses[spiderClass] then continue end
            table.insert(pool, { class = spiderClass, weight = percentage })
            totalWeight = totalWeight + percentage
        end
    end

    local class
    if totalWeight > 0 then
        local roll = math.random() * totalWeight
        local curWeight = 0
        for _, item in ipairs(pool) do
            curWeight = curWeight + item.weight
            if roll <= curWeight then
                class = item.class
                break
            end
        end
    end

    if not class then return end

    local spider = ents.Create(class)
    if not IsValid(spider) then return end

    local rad = math.rad(angleOffset or math.random(0, 360))
    local offset = Vector(math.cos(rad) * 20, math.sin(rad) * 20, 12)
    spider:SetPos(pos + offset)
    spider:Spawn()
    spider:Activate()

    return spider
end

function ENT:Hatch()
    if self.isHatching then return end
    self.isHatching = true

    self:EmitSound("physics/flesh/flesh_squishy_impact_hard"..math.random(1, 4)..".wav", 75, 90)
    self:EmitSound("physics/cardboard/cardboard_box_break3.wav", 72, 110)

    local effect = EffectData()
    effect:SetOrigin(self:GetPos() + Vector(0, 0, 15))
    effect:SetScale(1.8)
    util.Effect("BloodImpact", effect)

    local count = math.random(2, 3)
    local step = 360 / count
    local baseAngle = math.random(0, 360)
    for i = 1, count do
        spawnSpider(self:GetPos(), baseAngle + (i - 1) * step)
    end

    self:Remove()
end

function ENT:OnTakeDamage(dmginfo)
    if self.isHatching then return end
    self:SetHealth(self:Health() - dmginfo:GetDamage())
    
    if self:Health() <= 0 then
        self.isHatching = true

        self:EmitSound("physics/flesh/flesh_squishy_impact_hard" .. math.random(1, 4) .. ".wav", 75, 90)

        local effect = EffectData()
        effect:SetOrigin(self:GetPos() + Vector(0, 0, 15))
        effect:SetScale(1.5)
        util.Effect("BloodImpact", effect)

        // 50% chance on break to spawn a spider
        if math.random() <= 0.5 then
            spawnSpider(self:GetPos(), math.random(0, 360))
        end

        self:Remove()
    end
end

function ENT:Think()
    if self.isHatching then return end

    local myPos = self:GetPos()
    local nearPlayer = false
    for _, ply in ipairs(player.GetAll()) do
        if not (ply:Alive() and myPos:DistToSqr(ply:GetPos()) <= (325 * 325)) then return end

        nearPlayer = true
        break
    end

    if nearPlayer then
        self:Hatch()
    end

    self:NextThink(CurTime() + 0.5)

    return true
end
