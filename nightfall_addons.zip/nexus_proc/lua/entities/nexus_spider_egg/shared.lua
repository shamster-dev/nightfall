ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Spider Egg"
ENT.Category = "Night Fall"
ENT.Spawnable = true

ENT.RenderGroup = RENDERGROUP_BOTH