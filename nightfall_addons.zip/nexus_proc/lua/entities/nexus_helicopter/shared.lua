ENT.Type = "point"
ENT.Base = "base_point"
ENT.PrintName = "Extraction Helicopter"
ENT.Category = "Night Fall"
ENT.Spawnable = true