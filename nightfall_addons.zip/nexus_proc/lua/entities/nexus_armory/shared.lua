ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Armoury"
ENT.Category = "Night Fall"
ENT.Spawnable = true