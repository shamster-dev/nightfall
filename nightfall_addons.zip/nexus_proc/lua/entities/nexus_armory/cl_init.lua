include("shared.lua")

function ENT:Draw()
    self:DrawModel()

    local pos = self:GetPos() + self:GetForward() * 13 + self:GetUp() * 60
    local ang = self:GetAngles()

    ang:RotateAroundAxis(ang:Up(), 90)
    ang:RotateAroundAxis(ang:Forward(), 90)

    cam.Start3D2D(pos, ang, 0.05)
        local w, h = Nexus:GetScale(300), Nexus:GetScale(100)
        Nexus.RNDX.Draw(25, -w/2, -h/2, w, h, color_white, Nexus.RNDX.BLUR)
        Nexus.RNDX.Draw(25, -w/2, -h/2, w, h, Nexus:SetAlpha(Nexus:GetColor("background"), 150))

        draw.SimpleTextOutlined("Armoury", Nexus:GetFont({size = 100, dontScale = true}), 0, 0, Nexus:SetAlpha(Nexus:GetColor("blue"), 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 2, color_black)
    cam.End3D2D()
end