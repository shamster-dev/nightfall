ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Perk Station"
ENT.Category = "Night Fall"
ENT.Spawnable = true
