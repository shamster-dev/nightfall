include("shared.lua")

function ENT:Draw()
    self:DrawModel()

    local pos = self:GetPos() + Vector(0, 0, 30)
    local ang = LocalPlayer():EyeAngles()
    ang:RotateAroundAxis(ang:Up(), -90)
    ang:RotateAroundAxis(ang:Forward(), 90)

    local text = "Perks"
    local glowCol = Nexus:SetAlpha(Nexus:GetColor("green"), 200 + math.sin(RealTime() * 4) * 55)

    local titleFont = Nexus:GetFont({size = 50, bold = true, dontScale = true})
    local descriptionFont = Nexus:GetFont({size = 15, dontScale = true})
    cam.Start3D2D(pos, ang, 0.1)
        draw.SimpleTextOutlined(text, titleFont, 1, 1, color_black, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_white)
        draw.SimpleTextOutlined(text, titleFont, 0, 0, glowCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_white)

        draw.SimpleText("(Press E to use)", descriptionFont, 1, 39, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    cam.End3D2D()
end

net.Receive("NightFall:Perks:OpenMenu", function()
    if IsValid(Nexus.Proc.PerkMenuPanel) then
        Nexus.Proc.PerkMenuPanel:Remove()
    end
    Nexus.Proc.PerkMenuPanel = vgui.Create("NexusRoundPerkTree")
end)
