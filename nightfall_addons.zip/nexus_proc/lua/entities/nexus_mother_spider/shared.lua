ENT.Type = "nextbot"
ENT.Base = "nexus_spider"
ENT.PrintName = "Mother Spider"
ENT.Category = "Night Fall"
ENT.Spawnable = true

ENT.RenderGroup = RENDERGROUP_BOTH
ENT.AutomaticFrameAdvance = true