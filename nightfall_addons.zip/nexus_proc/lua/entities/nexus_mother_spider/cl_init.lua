include("shared.lua")

function ENT:Initialize()
    self:SetRenderBounds(Vector(-1000, -1000, -1000), Vector(1000, 1000, 1000))

    InitStaticMeshes = InitStaticMeshes or function() end
    InitStaticMeshes()
end

function ENT:Think()
    baseclass.Get("nexus_spider").Think(self)

    if not (self.genes and not self.ScaledGenes) then return end
    self.ScaledGenes = true

    local Spider = Nexus.Proc.Spider

    self.genes.bodyRadius    = self.genes.bodyRadius    * 5.0
    self.genes.abdomenRadius = self.genes.abdomenRadius * 5.0
    self.genes.bodyHeight    = self.genes.bodyHeight    * 5.0
    self.genes.legLength1    = self.genes.legLength1    * 5.0
    self.genes.legLength2    = self.genes.legLength2    * 5.0
    self.genes.legLength3    = self.genes.legLength3    * 5.0
    self.genes.legSpread     = self.genes.legSpread     * 2.5

    self.legColors = {}
    for i = 1, Spider.LEG_COUNT do
        local shade = 0.80 + (((i - 1) % 4) * 0.06)
        self.legColors[i] = Spider.HSVtoColor(self.genes.hue, self.genes.sat, self.genes.val * shade)
    end

    self.jointCol  = Spider.HSVtoColor(self.genes.hue, self.genes.sat, self.genes.val * 0.55)
    self.legTipCol = Spider.HSVtoColor(self.genes.hue, self.genes.sat, self.genes.val * 0.45)
    self.shadowCol = Spider.HSVtoColor(self.genes.hue, self.genes.sat, self.genes.val * 0.2)

    local scale = (self.genes.bodyRadius * 3.2) / 12
    self:SetModelScale(scale)
end