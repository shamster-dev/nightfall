ENT.Type = "nextbot"
ENT.Base = "nexus_spider"
ENT.PrintName = "Jumping Spider"
ENT.Category = "Night Fall"
ENT.Spawnable = true

ENT.RenderGroup = RENDERGROUP_BOTH
ENT.AutomaticFrameAdvance = true