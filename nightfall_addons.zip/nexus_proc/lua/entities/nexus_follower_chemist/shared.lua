ENT.Type = "nextbot"
ENT.Base = "nexus_follower"
ENT.PrintName = "Chemist"
ENT.Category = "Night Fall"
ENT.Spawnable = true

ENT.Role = "Chemist"