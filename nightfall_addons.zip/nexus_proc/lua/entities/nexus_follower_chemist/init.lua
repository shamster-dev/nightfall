AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
    local base = baseclass.Get("nexus_follower")
    if base and base.Initialize then
        base.Initialize(self)
    end
end