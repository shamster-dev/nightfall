ENT.Type = "nextbot"
ENT.Base = "base_nextbot"
ENT.PrintName = "Spider"
ENT.Category = "Night Fall"
ENT.Spawnable = true

ENT.AutomaticFrameAdvance = true
ENT.RenderGroup = RENDERGROUP_BOTH