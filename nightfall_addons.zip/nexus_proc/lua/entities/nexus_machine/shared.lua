ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "NPC Machine"
ENT.Category = "Night Fall"
ENT.Spawnable = true
ENT.RenderGroup = RENDERGROUP_BOTH