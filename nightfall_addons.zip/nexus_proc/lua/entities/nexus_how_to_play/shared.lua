ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "How To Play"
ENT.Category = "Night Fall"
ENT.Spawnable = true