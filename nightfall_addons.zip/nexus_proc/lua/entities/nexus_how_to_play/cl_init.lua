include("shared.lua")

function ENT:Draw()
    self:DrawModel()

    local pos = self:GetPos() + Vector(0, 0, 18)
    local ang = LocalPlayer():EyeAngles()
    ang:RotateAroundAxis(ang:Up(), -90)
    ang:RotateAroundAxis(ang:Forward(), 90)

    local text = "How To Play"
    local glowCol = Nexus:SetAlpha(Nexus:GetColor("orange"), 200 + math.sin(RealTime() * 4) * 55)

    local titleFont = Nexus:GetFont({size = 35, bold = true, dontScale = true})
    local descriptionFont = Nexus:GetFont({size = 15, dontScale = true})
    cam.Start3D2D(pos, ang, 0.1)
        draw.SimpleText(text, titleFont, 1, 1, color_black, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText(text, titleFont, 0, 0, glowCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        draw.SimpleText("(Press E to use)", descriptionFont, 1, 39, color_black, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText("(Press E to use)", descriptionFont, 0, 40, glowCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    cam.End3D2D()
end

local COLOR_BG = Color(30, 30, 38, 160)
local COLOR_TEXT = Color(240, 240, 245)
local COLOR_TEXT_DIM = Color(160, 160, 176)
local COLOR_ACCENT = Color(255, 170, 0)
local COLOR_DANGER = Color(255, 59, 59)
local COLOR_MONEY = Color(124, 217, 87)

local ROLES = {
    {
        name = "Electrician",
        required = true,
        color = Color(255, 215, 0),
        desc = "Repairs circuits at the power grid panel to keep the sector powered and light sources secured.",
    },
    {
        name = "Engineer",
        required = true,
        color = Color(255, 140, 0),
        desc = "Needs engine parts found out on the map, carried back, and socketed into their assembly rig.",
    },
    {
        name = "Chemist",
        required = true,
        color = Color(0, 210, 255),
        desc = "Needs fuel drums found out on the map, carried back, and socketed to synthesize fuel charges.",
    },
    {
        name = "Researcher",
        required = false,
        color = Color(186, 85, 211),
        desc = "Not required to escape, but their scanner traces radio signals and marks every other NPC on your minimap.",
    },
    {
        name = "Pilot",
        required = true,
        color = Color(124, 217, 87),
        desc = "Bring them home last. Once the other required machines are online they ready the helicopter for extraction.",
    },
}

local function AddSectionTitle(parent, text)
    local lbl = parent:Add("DLabel")
    lbl:Dock(TOP)
    lbl:DockMargin(0, Nexus:GetScale(16), 0, Nexus:GetScale(8))
    lbl:SetFont(Nexus:GetFont({size = 20, font="Lato"}))
    lbl:SetTextColor(COLOR_TEXT)
    lbl:SetText(text)
    lbl:SizeToContentsY()
end

local function AddCard(parent, accentColor, text)
    local card = parent:Add("DPanel")
    card:Dock(TOP)
    card:DockMargin(0, 0, 0, Nexus:GetScale(10))
    card:DockPadding(Nexus:GetScale(12), Nexus:GetScale(10), Nexus:GetScale(12), Nexus:GetScale(10))

    card.Paint = function(self, w, h)
        draw.RoundedBox(6, 0, 0, w, h, COLOR_BG)
        surface.SetDrawColor(accentColor)
        surface.DrawRect(0, 0, Nexus:GetScale(3), h)
    end

    local desc = card:Add("DLabel")
    desc:Dock(TOP)
    desc:SetFont(Nexus:GetFont({size = 15, font="Lato"}))
    desc:SetTextColor(COLOR_TEXT_DIM)
    desc:SetWrap(true)
    desc:SetAutoStretchVertical(true)
    desc:SetText(text)

    function card:PerformLayout(w, h)
        desc:SetWide(w - Nexus:GetScale(24))
        self:SetTall(desc:GetTall() + Nexus:GetScale(20))
    end

    return card
end

local function AddRoleCard(parent, role)
    local card = parent:Add("DPanel")
    card:Dock(TOP)
    card:DockMargin(0, 0, 0, Nexus:GetScale(10))
    card:DockPadding(Nexus:GetScale(12), Nexus:GetScale(10), Nexus:GetScale(12), Nexus:GetScale(10))

    card.Paint = function(self, w, h)
        draw.RoundedBox(6, 0, 0, w, h, COLOR_BG)
        surface.SetDrawColor(role.color)
        surface.DrawRect(0, 0, Nexus:GetScale(3), h)
    end

    local header = card:Add("DPanel")
    header:Dock(TOP)
    header:SetPaintBackground(false)
    header:SetTall(Nexus:GetScale(18))

    local name = header:Add("DLabel")
    name:Dock(LEFT)
    name:SetFont(Nexus:GetFont({size = 20, font="Lato"}))
    name:SetTextColor(role.color)
    name:SetText(role.name)
    name:SizeToContents()

    local tag = header:Add("DLabel")
    tag:Dock(RIGHT)
    tag:SetFont(Nexus:GetFont({size = 12, font="Lato"}))
    tag:SetTextColor(role.required and COLOR_DANGER or COLOR_TEXT_DIM)
    tag:SetText(role.required and "REQUIRED" or "OPTIONAL")
    tag:SetContentAlignment(6)
    tag:SizeToContents()

    local desc = card:Add("DLabel")
    desc:Dock(TOP)
    desc:DockMargin(0, Nexus:GetScale(4), 0, 0)
    desc:SetFont(Nexus:GetFont({size = 15, font="Lato"}))
    desc:SetTextColor(COLOR_TEXT_DIM)
    desc:SetWrap(true)
    desc:SetAutoStretchVertical(true)
    desc:SetText(role.desc)

    function card:PerformLayout(w, h)
        desc:SetWide(w - Nexus:GetScale(24))
        self:SetTall(header:GetTall() + desc:GetTall() + Nexus:GetScale(24))
    end

    return card
end

net.Receive("NightFall:HowToPlay:Open", function()
    local frame = vgui.Create("Nexus:V2:Frame")
    frame:SetSize(Nexus:GetScale(480), Nexus:GetScale(640))
    frame:Center()
    frame:MakePopup()
    frame:HideHeaderButton()

    local scroll = vgui.Create("DScrollPanel", frame)
    scroll:Dock(FILL)
    scroll:DockMargin(Nexus:GetScale(20), Nexus:GetScale(20), Nexus:GetScale(20), Nexus:GetScale(20))

    local vbar = scroll:GetVBar()
    vbar:SetWide(Nexus:GetScale(4))
    vbar.Paint = function() end
    vbar.btnUp.Paint = function() end
    vbar.btnDown.Paint = function() end
    vbar.btnGrip.Paint = function(self, w, h)
        draw.RoundedBox(2, 0, 0, w, h, Color(255, 255, 255, 40))
    end

    local title = scroll:Add("DLabel")
    title:Dock(TOP)
    title:SetFont(Nexus:GetFont({size = 24}))
    title:SetTextColor(COLOR_ACCENT)
    title:SetText("Night Fall")
    title:SetContentAlignment(5)
    title:SizeToContentsY()

    local subtitle = scroll:Add("DLabel")
    subtitle:Dock(TOP)
    subtitle:DockMargin(0, Nexus:GetMargin(), 0, Nexus:GetScale(10))
    subtitle:SetFont(Nexus:GetFont({size = 15}))
    subtitle:SetTextColor(COLOR_TEXT_DIM)
    subtitle:SetText("SURVIVOR MANUAL")
    subtitle:SetContentAlignment(5)
    subtitle:SizeToContentsY()

    AddSectionTitle(scroll, "Mission Overview")
    AddCard(scroll, COLOR_ACCENT, "You are a survivor. Travel the world to find other survivors and bring them back to home base. Each one repairs their own machine, and once every required machine is online the pilot preps the helicopter for extraction. Defend home base until you're out.")

    AddSectionTitle(scroll, "Survivors")
    for _, role in ipairs(ROLES) do
        AddRoleCard(scroll, role)
    end

    AddSectionTitle(scroll, "Parts & Inventory")
    AddCard(scroll, Color(0, 210, 255), "Some machines need specific parts scattered across the map. Walk up to one and press E to pick it up. Press F3 to toggle the cursor and click slots to drop them.")

    AddSectionTitle(scroll, "Threats")
    AddCard(scroll, COLOR_DANGER, "Spiders spawn across the world and attack both you and home base. If home base HP hits 0, all survivors lose, so stay close enough to defend it.")

    AddSectionTitle(scroll, "Economy & Progression")
    AddCard(scroll, COLOR_MONEY, "Every spider you kill pays out $2. Spend it at the shop on perks and weapons to give your squad a better shot at survival.")
end)