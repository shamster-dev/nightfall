AddCSLuaFile("shared.lua")
include("shared.lua")

util.AddNetworkString("NightFall:HowToPlay:Open")
function ENT:Initialize()
    self:SetModel("models/props_lab/clipboard.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:EnableMotion(false)
    end
end

function ENT:Use(activator, caller)
    if not IsValid(activator) then return end

    net.Start("NightFall:HowToPlay:Open")
    net.Send(activator)
end