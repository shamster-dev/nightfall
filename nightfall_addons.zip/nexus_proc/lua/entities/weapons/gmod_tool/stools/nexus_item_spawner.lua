TOOL.Category = "Nexus"
TOOL.Name = "Nexus Item Spawner"
TOOL.Command = nil
TOOL.ConfigName = ""

-- Set up networking strings
if SERVER then
    util.AddNetworkString("Nexus:ItemSpawns:Sync")
end

-- Initialize the shared global table
Nexus.Proc = Nexus.Proc or {}
Nexus.Proc.ItemSpawns = Nexus.Proc.ItemSpawns or {}

-- File paths for saving spawn points
local DATA_DIR = "nexus_proc"
local FILE_PATH = DATA_DIR .. "/item_spawns_" .. game.GetMap() .. ".json"

-- Server-side loading and saving
if SERVER then
    function Nexus.Proc.SaveItemSpawns()
        if not file.Exists(DATA_DIR, "DATA") then
            file.CreateDir(DATA_DIR)
        end
        local saveData = {}
        for _, spawn in ipairs(Nexus.Proc.ItemSpawns) do
            table.insert(saveData, {
                pos = { spawn.pos.x, spawn.pos.y, spawn.pos.z }
            })
        end
        file.Write(FILE_PATH, util.TableToJSON(saveData))
    end

    function Nexus.Proc.LoadItemSpawns()
        if file.Exists(FILE_PATH, "DATA") then
            local data = file.Read(FILE_PATH, "DATA")
            local raw = util.JSONToTable(data) or {}
            Nexus.Proc.ItemSpawns = {}
            for _, v in ipairs(raw) do
                if v.pos then
                    table.insert(Nexus.Proc.ItemSpawns, {
                        pos = Vector(v.pos[1], v.pos[2], v.pos[3])
                    })
                end
            end
        else
            Nexus.Proc.ItemSpawns = {}
        end
    end

    -- Initial load
    hook.Add("Initialize", "NexusProcLoadItemSpawns", function()
        Nexus.Proc.LoadItemSpawns()
    end)
    -- Fallback load if initialized late
    Nexus.Proc.LoadItemSpawns()

    -- Sync to players when they load in
    hook.Add("PlayerInitialSpawn", "NexusProcSyncItemSpawns", function(ply)
        timer.Simple(2, function()
            if IsValid(ply) then
                net.Start("Nexus:ItemSpawns:Sync")
                net.WriteTable(Nexus.Proc.ItemSpawns)
                net.Send(ply)
            end
        end)
    end)
end

-- Network receiver to sync points client-side
if CLIENT then
    net.Receive("Nexus:ItemSpawns:Sync", function()
        Nexus.Proc.ItemSpawns = net.ReadTable() or {}
    end)
end

-- Right click: Create spawn point
function TOOL:RightClick(trace)
    if not trace.HitPos then return false end
    if CLIENT then return true end

    -- Insert point (slightly above ground)
    local pos = trace.HitPos + trace.HitNormal * 2
    table.insert(Nexus.Proc.ItemSpawns, {
        pos = pos
    })
    Nexus.Proc.SaveItemSpawns()

    -- Sync to all clients
    net.Start("Nexus:ItemSpawns:Sync")
    net.WriteTable(Nexus.Proc.ItemSpawns)
    net.Broadcast()

    local ply = self:GetOwner()
    if IsValid(ply) then
        ply:PrintMessage(HUD_PRINTTALK, "[Nexus] Added item spawn point. Total points: " .. #Nexus.Proc.ItemSpawns)
    end

    return true
end

-- Left click: Remove nearest spawn point
function TOOL:LeftClick(trace)
    if not trace.HitPos then return false end
    if CLIENT then return true end

    local hitPos = trace.HitPos
    local closestIdx = nil
    local closestDist = 150 -- threshold distance to remove (150 units)

    for i, spawn in ipairs(Nexus.Proc.ItemSpawns) do
        local dist = spawn.pos:Distance(hitPos)
        if dist < closestDist then
            closestDist = dist
            closestIdx = i
        end
    end

    local ply = self:GetOwner()

    if closestIdx then
        table.remove(Nexus.Proc.ItemSpawns, closestIdx)
        Nexus.Proc.SaveItemSpawns()

        -- Sync to all clients
        net.Start("Nexus:ItemSpawns:Sync")
        net.WriteTable(Nexus.Proc.ItemSpawns)
        net.Broadcast()

        if IsValid(ply) then
            ply:PrintMessage(HUD_PRINTTALK, "[Nexus] Removed item spawn point. Remaining: " .. #Nexus.Proc.ItemSpawns)
        end
    else
        if IsValid(ply) then
            ply:PrintMessage(HUD_PRINTTALK, "[Nexus] No item spawn point close enough to remove.")
        end
    end

    return true
end

-- Reload: Clear all spawn points
function TOOL:Reload(trace)
    if CLIENT then return true end

    Nexus.Proc.ItemSpawns = {}
    Nexus.Proc.SaveItemSpawns()

    -- Sync to all clients
    net.Start("Nexus:ItemSpawns:Sync")
    net.WriteTable(Nexus.Proc.ItemSpawns)
    net.Broadcast()

    local ply = self:GetOwner()
    if IsValid(ply) then
        ply:PrintMessage(HUD_PRINTTALK, "[Nexus] Cleared all item spawn points.")
    end

    return true
end

-- Build Control Panel
function TOOL.BuildCPanel(panel)
    panel:AddControl("Header", {
        Text = "#tool.nexus_item_spawner.name",
        Description = "#tool.nexus_item_spawner.desc"
    })
end

-- Draw spawn points in 3D when tool is equipped
if CLIENT then
    language.Add("tool.nexus_item_spawner.name", "Nexus Item Spawn Point Tool")
    language.Add("tool.nexus_item_spawner.desc", "Set or remove item spawn points for carryable drums and engines.")
    language.Add("tool.nexus_item_spawner.left", "Remove nearest item spawn point.")
    language.Add("tool.nexus_item_spawner.right", "Create an item spawn point.")
    language.Add("tool.nexus_item_spawner.reload", "Clear all item spawn points.")

    local color = Color(218, 112, 214) -- Orchid/Magenta

    -- Render in 3D
    hook.Add("PostDrawTranslucentRenderables", "NexusProcItemSpawnPointsRender", function(bDepth, bSkybox)
        if bDepth or bSkybox then return end

        local ply = LocalPlayer()
        if not IsValid(ply) then return end

        -- Check if player is holding the toolgun with our tool active
        local wep = ply:GetActiveWeapon()
        if not IsValid(wep) or wep:GetClass() ~= "gmod_tool" then return end

        local tool = ply:GetTool("nexus_item_spawner")
        if not tool then return end

        -- Draw all spawn points
        local points = Nexus.Proc.ItemSpawns or {}
        local glowMat = Material("sprites/glow04_nocull")
        
        for _, spawn in ipairs(points) do
            local pos = spawn.pos

            -- Draw a 3D orb at the spawn location
            render.SetMaterial(glowMat)
            local pulse = 16 + math.sin(RealTime() * 8) * 4
            render.DrawSprite(pos + Vector(0, 0, pulse * 0.5), pulse, pulse, Color(color.r, color.g, color.b, 200))
            
            -- Draw outer rings or indicator sphere
            render.DrawWireframeSphere(pos + Vector(0, 0, 10), 12, 8, 8, Color(color.r, color.g, color.b, 100), true)

            -- Draw the label above the spawn point
            local angle = LocalPlayer():EyeAngles()
            angle:RotateAroundAxis(angle:Up(), -90)
            angle:RotateAroundAxis(angle:Forward(), 90)

            cam.Start3D2D(pos + Vector(0, 0, 30), angle, 0.15)
                draw.SimpleText("Item Spawn", "ChatFont", 0, 0, Color(color.r, color.g, color.b, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            cam.End3D2D()
        end
    end)
end
