TOOL.Category = "Nexus"
TOOL.Name = "Nexus Egg Spawner"
TOOL.Command = nil
TOOL.ConfigName = ""

-- Set up networking strings
if SERVER then
    util.AddNetworkString("Nexus:EggSpawns:Sync")
end

-- Initialize the shared global table
Nexus.Proc = Nexus.Proc or {}
Nexus.Proc.EggSpawns = Nexus.Proc.EggSpawns or {}

-- File paths for saving spawn points
local DATA_DIR = "nexus_proc"
local FILE_PATH = DATA_DIR .. "/egg_spawns_" .. game.GetMap() .. ".json"

-- Server-side loading and saving
if SERVER then
    function Nexus.Proc.SaveEggSpawns()
        if not file.Exists(DATA_DIR, "DATA") then
            file.CreateDir(DATA_DIR)
        end
        file.Write(FILE_PATH, util.TableToJSON(Nexus.Proc.EggSpawns))
    end

    function Nexus.Proc.LoadEggSpawns()
        if file.Exists(FILE_PATH, "DATA") then
            local data = file.Read(FILE_PATH, "DATA")
            Nexus.Proc.EggSpawns = util.JSONToTable(data) or {}
        else
            Nexus.Proc.EggSpawns = {}
        end
    end

    -- Initial load
    hook.Add("Initialize", "NexusProcLoadEggSpawns", function()
        Nexus.Proc.LoadEggSpawns()
    end)
    -- Fallback load if initialized late
    Nexus.Proc.LoadEggSpawns()

    -- Sync to players when they load in
    hook.Add("PlayerInitialSpawn", "NexusProcSyncEggSpawns", function(ply)
        timer.Simple(2, function()
            if IsValid(ply) then
                net.Start("Nexus:EggSpawns:Sync")
                net.WriteTable(Nexus.Proc.EggSpawns)
                net.Send(ply)
            end
        end)
    end)
end

-- Network receiver to sync points client-side
if CLIENT then
    net.Receive("Nexus:EggSpawns:Sync", function()
        Nexus.Proc.EggSpawns = net.ReadTable() or {}
    end)
end

-- Right click: Create spawn point
function TOOL:RightClick(trace)
    if not trace.HitPos then return false end
    if CLIENT then return true end

    -- Insert point (slightly above ground to avoid spawning inside displacements)
    local pos = trace.HitPos + trace.HitNormal * 2
    table.insert(Nexus.Proc.EggSpawns, pos)
    Nexus.Proc.SaveEggSpawns()

    -- Sync to all clients
    net.Start("Nexus:EggSpawns:Sync")
    net.WriteTable(Nexus.Proc.EggSpawns)
    net.Broadcast()

    local ply = self:GetOwner()
    if IsValid(ply) then
        ply:PrintMessage(HUD_PRINTTALK, "[Nexus] Added egg spawn point. Total points: " .. #Nexus.Proc.EggSpawns)
    end

    return true
end

-- Left click: Remove nearest spawn point
function TOOL:LeftClick(trace)
    if not trace.HitPos then return false end
    if CLIENT then return true end

    local hitPos = trace.HitPos
    local closestIdx = nil
    local closestDist = 150 -- threshold distance to remove (150 units)

    for i, spawnPos in ipairs(Nexus.Proc.EggSpawns) do
        local dist = spawnPos:Distance(hitPos)
        if dist < closestDist then
            closestDist = dist
            closestIdx = i
        end
    end

    local ply = self:GetOwner()

    if closestIdx then
        table.remove(Nexus.Proc.EggSpawns, closestIdx)
        Nexus.Proc.SaveEggSpawns()

        -- Sync to all clients
        net.Start("Nexus:EggSpawns:Sync")
        net.WriteTable(Nexus.Proc.EggSpawns)
        net.Broadcast()

        if IsValid(ply) then
            ply:PrintMessage(HUD_PRINTTALK, "[Nexus] Removed egg spawn point. Remaining: " .. #Nexus.Proc.EggSpawns)
        end
    else
        if IsValid(ply) then
            ply:PrintMessage(HUD_PRINTTALK, "[Nexus] No spawn point close enough to remove.")
        end
    end

    return true
end

-- Reload: Clear all spawn points
function TOOL:Reload(trace)
    if CLIENT then return true end

    Nexus.Proc.EggSpawns = {}
    Nexus.Proc.SaveEggSpawns()

    -- Sync to all clients
    net.Start("Nexus:EggSpawns:Sync")
    net.WriteTable(Nexus.Proc.EggSpawns)
    net.Broadcast()

    local ply = self:GetOwner()
    if IsValid(ply) then
        ply:PrintMessage(HUD_PRINTTALK, "[Nexus] Cleared all egg spawn points.")
    end

    return true
end

-- Draw spawn points in 3D when tool is equipped
if CLIENT then
    language.Add("tool.nexus_egg_spawner.name", "Nexus Egg Spawn Point Tool")
    language.Add("tool.nexus_egg_spawner.desc", "Set or remove egg spawn points for the Nexus round spawner.")
    language.Add("tool.nexus_egg_spawner.left", "Remove nearest spawn point.")
    language.Add("tool.nexus_egg_spawner.right", "Create a spawn point.")
    language.Add("tool.nexus_egg_spawner.reload", "Clear all spawn points.")

    -- Render in 3D
    hook.Add("PostDrawTranslucentRenderables", "NexusProcEggSpawnPointsRender", function(bDepth, bSkybox)
        if bDepth or bSkybox then return end

        local ply = LocalPlayer()
        if not IsValid(ply) then return end

        -- Check if player is holding the toolgun with our tool active
        local wep = ply:GetActiveWeapon()
        if not IsValid(wep) or wep:GetClass() ~= "gmod_tool" then return end

        local tool = ply:GetTool("nexus_egg_spawner")
        if not tool then return end

        -- Draw all spawn points
        local points = Nexus.Proc.EggSpawns or {}
        local glowMat = Material("sprites/glow04_nocull")
        
        for _, pos in ipairs(points) do
            -- Draw a 3D red/yellow orb at the spawn location
            render.SetMaterial(glowMat)
            local pulse = 16 + math.sin(RealTime() * 8) * 4
            render.DrawSprite(pos + Vector(0, 0, pulse * 0.5), pulse, pulse, Color(255, 80, 0, 200))
            
            -- Draw an outer rings or indicator sphere
            render.DrawWireframeSphere(pos + Vector(0, 0, 10), 12, 8, 8, Color(255, 150, 0, 100), true)
        end
    end)
end
