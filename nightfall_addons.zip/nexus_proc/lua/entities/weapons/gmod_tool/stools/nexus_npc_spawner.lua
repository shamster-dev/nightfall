TOOL.Category = "Nexus"
TOOL.Name = "Nexus NPC Spawner"
TOOL.Command = nil
TOOL.ConfigName = ""

TOOL.ClientConVar = {
    ["role"] = "Random"
}

-- Set up networking strings
if SERVER then
    util.AddNetworkString("Nexus:NpcSpawns:Sync")
end

-- Initialize the shared global table
Nexus.Proc = Nexus.Proc or {}
Nexus.Proc.NpcSpawns = Nexus.Proc.NpcSpawns or {}

-- File paths for saving spawn points
local DATA_DIR = "nexus_proc"
local FILE_PATH = DATA_DIR .. "/npc_spawns_" .. game.GetMap() .. ".json"

-- Server-side loading and saving
if SERVER then
    function Nexus.Proc.SaveNpcSpawns()
        if not file.Exists(DATA_DIR, "DATA") then
            file.CreateDir(DATA_DIR)
        end
        local saveData = {}
        for _, spawn in ipairs(Nexus.Proc.NpcSpawns) do
            table.insert(saveData, {
                pos = { spawn.pos.x, spawn.pos.y, spawn.pos.z },
                role = spawn.role
            })
        end
        file.Write(FILE_PATH, util.TableToJSON(saveData))
    end

    function Nexus.Proc.LoadNpcSpawns()
        if file.Exists(FILE_PATH, "DATA") then
            local data = file.Read(FILE_PATH, "DATA")
            local raw = util.JSONToTable(data) or {}
            Nexus.Proc.NpcSpawns = {}
            for _, v in ipairs(raw) do
                if v.pos and v.role then
                    table.insert(Nexus.Proc.NpcSpawns, {
                        pos = Vector(v.pos[1], v.pos[2], v.pos[3]),
                        role = v.role
                    })
                end
            end
        else
            Nexus.Proc.NpcSpawns = {}
        end
    end

    -- Initial load
    hook.Add("Initialize", "NexusProcLoadNpcSpawns", function()
        Nexus.Proc.LoadNpcSpawns()
    end)
    -- Fallback load if initialized late
    Nexus.Proc.LoadNpcSpawns()

    -- Sync to players when they load in
    hook.Add("PlayerInitialSpawn", "NexusProcSyncNpcSpawns", function(ply)
        timer.Simple(2, function()
            if IsValid(ply) then
                net.Start("Nexus:NpcSpawns:Sync")
                net.WriteTable(Nexus.Proc.NpcSpawns)
                net.Send(ply)
            end
        end)
    end)
end

-- Network receiver to sync points client-side
if CLIENT then
    net.Receive("Nexus:NpcSpawns:Sync", function()
        Nexus.Proc.NpcSpawns = net.ReadTable() or {}
    end)
end

-- Right click: Create spawn point
function TOOL:RightClick(trace)
    if not trace.HitPos then return false end
    if CLIENT then return true end

    local role = self:GetClientInfo("role") or "Random"

    -- Insert point (slightly above ground to avoid spawning inside displacements)
    local pos = trace.HitPos + trace.HitNormal * 2
    table.insert(Nexus.Proc.NpcSpawns, {
        pos = pos,
        role = role
    })
    Nexus.Proc.SaveNpcSpawns()

    -- Sync to all clients
    net.Start("Nexus:NpcSpawns:Sync")
    net.WriteTable(Nexus.Proc.NpcSpawns)
    net.Broadcast()

    local ply = self:GetOwner()
    if IsValid(ply) then
        ply:PrintMessage(HUD_PRINTTALK, "[Nexus] Added NPC spawn point (" .. role .. "). Total points: " .. #Nexus.Proc.NpcSpawns)
    end

    return true
end

-- Left click: Remove nearest spawn point
function TOOL:LeftClick(trace)
    if not trace.HitPos then return false end
    if CLIENT then return true end

    local hitPos = trace.HitPos
    local closestIdx = nil
    local closestDist = 150 -- threshold distance to remove (150 units)

    for i, spawn in ipairs(Nexus.Proc.NpcSpawns) do
        local dist = spawn.pos:Distance(hitPos)
        if dist < closestDist then
            closestDist = dist
            closestIdx = i
        end
    end

    local ply = self:GetOwner()

    if closestIdx then
        local removedRole = Nexus.Proc.NpcSpawns[closestIdx].role
        table.remove(Nexus.Proc.NpcSpawns, closestIdx)
        Nexus.Proc.SaveNpcSpawns()

        -- Sync to all clients
        net.Start("Nexus:NpcSpawns:Sync")
        net.WriteTable(Nexus.Proc.NpcSpawns)
        net.Broadcast()

        if IsValid(ply) then
            ply:PrintMessage(HUD_PRINTTALK, "[Nexus] Removed NPC spawn point (" .. removedRole .. "). Remaining: " .. #Nexus.Proc.NpcSpawns)
        end
    else
        if IsValid(ply) then
            ply:PrintMessage(HUD_PRINTTALK, "[Nexus] No spawn point close enough to remove.")
        end
    end

    return true
end

-- Reload: Clear all spawn points
function TOOL:Reload(trace)
    if CLIENT then return true end

    Nexus.Proc.NpcSpawns = {}
    Nexus.Proc.SaveNpcSpawns()

    -- Sync to all clients
    net.Start("Nexus:NpcSpawns:Sync")
    net.WriteTable(Nexus.Proc.NpcSpawns)
    net.Broadcast()

    local ply = self:GetOwner()
    if IsValid(ply) then
        ply:PrintMessage(HUD_PRINTTALK, "[Nexus] Cleared all NPC spawn points.")
    end

    return true
end

-- Build Control Panel
function TOOL.BuildCPanel(panel)
    panel:AddControl("Header", {
        Text = "#tool.nexus_npc_spawner.name",
        Description = "#tool.nexus_npc_spawner.desc"
    })

    local combo = panel:ComboBox("NPC Role", "nexus_npc_spawner_role")
    combo:AddChoice("Random", "Random")
    combo:AddChoice("Researcher", "Researcher")
    combo:AddChoice("Mechanic", "Mechanic")
    combo:AddChoice("Electrician", "Electrician")
    combo:AddChoice("Chemist", "Chemist")
    combo:AddChoice("Pilot", "Pilot")
end

-- Draw spawn points in 3D when tool is equipped
if CLIENT then
    language.Add("tool.nexus_npc_spawner.name", "Nexus NPC Spawn Point Tool")
    language.Add("tool.nexus_npc_spawner.desc", "Set or remove NPC spawn points for the Nexus round spawner.")
    language.Add("tool.nexus_npc_spawner.left", "Remove nearest spawn point.")
    language.Add("tool.nexus_npc_spawner.right", "Create a spawn point.")
    language.Add("tool.nexus_npc_spawner.reload", "Clear all spawn points.")

    local roleColors = {
        ["Random"] = Color(0, 191, 255),
        ["Researcher"] = Color(220, 220, 220),
        ["Mechanic"] = Color(255, 140, 0),
        ["Electrician"] = Color(50, 205, 50),
        ["Chemist"] = Color(186, 85, 211),
        ["Pilot"] = Color(255, 69, 0)
    }

    -- Render in 3D
    hook.Add("PostDrawTranslucentRenderables", "NexusProcNpcSpawnPointsRender", function(bDepth, bSkybox)
        if bDepth or bSkybox then return end

        local ply = LocalPlayer()
        if not IsValid(ply) then return end

        -- Check if player is holding the toolgun with our tool active
        local wep = ply:GetActiveWeapon()
        if not IsValid(wep) or wep:GetClass() ~= "gmod_tool" then return end

        local tool = ply:GetTool("nexus_npc_spawner")
        if not tool then return end

        -- Draw all spawn points
        local points = Nexus.Proc.NpcSpawns or {}
        local glowMat = Material("sprites/glow04_nocull")
        
        for _, spawn in ipairs(points) do
            local pos = spawn.pos
            local role = spawn.role or "Random"
            local color = roleColors[role] or Color(255, 255, 255)

            -- Draw a 3D orb at the spawn location
            render.SetMaterial(glowMat)
            local pulse = 16 + math.sin(RealTime() * 8) * 4
            render.DrawSprite(pos + Vector(0, 0, pulse * 0.5), pulse, pulse, Color(color.r, color.g, color.b, 200))
            
            -- Draw outer rings or indicator sphere
            render.DrawWireframeSphere(pos + Vector(0, 0, 10), 12, 8, 8, Color(color.r, color.g, color.b, 100), true)

            -- Draw the role name above the spawn point
            local angle = LocalPlayer():EyeAngles()
            angle:RotateAroundAxis(angle:Up(), -90)
            angle:RotateAroundAxis(angle:Forward(), 90)

            cam.Start3D2D(pos + Vector(0, 0, 30), angle, 0.15)
                draw.SimpleText(role, "ChatFont", 0, 0, Color(color.r, color.g, color.b, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            cam.End3D2D()
        end
    end)
end
