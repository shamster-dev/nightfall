ENT.Type = "nextbot"
ENT.Base = "nexus_follower"
ENT.PrintName = "Electrician"
ENT.Category = "Night Fall"
ENT.Spawnable = true

ENT.Role = "Electrician"