ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Engine"
ENT.Category = "Night Fall"
ENT.Spawnable = true