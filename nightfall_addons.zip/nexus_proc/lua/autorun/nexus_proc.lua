local function load()
    if not Nexus then return end

    Nexus.Proc = Nexus.Proc or {}
    Nexus.Proc.Rounds = Nexus.Proc.Rounds or {}
    Nexus.Proc.Base = Nexus.Proc.Base or {}

    ROUND_WAITING = 0
    ROUND_PREP    = 1
    ROUND_ACTIVE  = 2
    ROUND_VICTORY = 3
    ROUND_DEFEAT  = 4

    Nexus:LoadDirectory("nexus_proc", {
        "nexus_proc/rounds/sh_base_hp.lua",
        "nexus_proc/sh_spider_config.lua",
    })
end
load()

hook.Add("Nexus:Loaded", "Nexus:Proc:Loaded", function()
    load()
end)