GM.Name = "Nightfall"
GM.Author = "Nexus"
GM.Email = "contact@nexussuite.co.uk"
GM.Website = "nexussuite.co.uk"

function GM:Initialize()
end

DeriveGamemode("sandbox")