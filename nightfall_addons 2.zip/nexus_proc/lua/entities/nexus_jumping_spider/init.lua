AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
    baseclass.Get("nexus_spider").Initialize(self)

    self.Spider = Nexus.Proc.Spider
    self.CHASE_RANGE_SQR  = self.Spider.CHASE_RANGE * self.Spider.CHASE_RANGE
    self.CHASE_RANGE_LIMIT_SQR = (self.Spider.CHASE_RANGE + 200) * (self.Spider.CHASE_RANGE + 200)
    self.ATTACK_RANGE_SQR = self.Spider.ATTACK_RANGE * self.Spider.ATTACK_RANGE
    self.ATTACK_RANGE_LIMIT_SQR = (self.Spider.ATTACK_RANGE + 15) * (self.Spider.ATTACK_RANGE + 15)
end

function ENT:RunBehaviour()
    coroutine.wait(0.5)

    while IsValid(self) do
        if self:GetNWBool("IsDead", false) then
            coroutine.wait(1.0)
            continue
        end

        local loco = self.loco
        if not loco then
            coroutine.wait(0.2)
            continue
        end

        local target = self:FindClosestPlayer()
        local isBase = type(target) == "table" and target.IsBase
        local isTargetValid = isBase or IsValid(target)

        if not isTargetValid then
            loco:SetDesiredSpeed(self.genes.speed * 0.30)

            local dir = Vector(math.Rand(-1,1), math.Rand(-1,1), 0)
            if dir:LengthSqr() < 0.001 then dir = Vector(1,0,0) end
            dir:Normalize()

            local wander = self:GetPos() + dir * math.Rand(150, 400)
            local path = Path("Follow")
            path:SetMinLookAheadDistance(60)
            path:Compute(self, wander)

            local t0 = CurTime()
            while IsValid(self) and (CurTime() - t0) < 3.5 do
                path:Update(self)
                coroutine.wait(0.05)
            end

            coroutine.wait(math.Rand(0.3, 1.5))
            continue
        end

        local distSqr = self:GetPos():DistToSqr(target:GetPos())
        if distSqr <= self.ATTACK_RANGE_SQR then
            self:FaceTarget(target)
            
            self:SetNWFloat("LastAttackTime", CurTime())

            local lungeEnd = CurTime() + 0.15
            self:EmitSound("npc/headcrab_fast/fast_headcrab_leap1.wav", 80, math.random(125, 145))
            while IsValid(self) and (isBase or IsValid(target)) and CurTime() < lungeEnd do
                local dir = target:GetPos() - self:GetPos()
                dir.z = 0
                dir:Normalize()

                if self.loco then
                    self.loco:SetVelocity(dir * 550 + Vector(0, 0, 100))
                end

                coroutine.wait(0.01)
            end

            if IsValid(self) and (isBase or IsValid(target)) then
                self:AttackPlayer(target)
            end

            coroutine.wait(self.Spider.ATTACK_RATE - 0.15)
            continue
        end

        if distSqr <= 800 * 800 and not isBase and (not self.nextJumpTime or CurTime() >= self.nextJumpTime) then
            self:FaceTarget(target)

            self:SetNWFloat("LastAttackTime", CurTime())
            
            // Prepare to jump
            coroutine.wait(0.15)

            if not (IsValid(self) and IsValid(target)) then continue end
            local myPos = self:GetPos()
            local targetPos = target:GetPos()
            local jumpDir = targetPos - myPos
            local heightDiff = targetPos.z - myPos.z
            jumpDir.z = 0
            jumpDir:Normalize()

            local gravity = physenv.GetGravity():Length()
            local jumpZ = 220
            if heightDiff > 0 then
                jumpZ = math.sqrt(2 * gravity * heightDiff) + 150
            end

            local dist = myPos:Distance(targetPos)
            local jumpVel = jumpDir * (dist * 2.0 + 300) + Vector(0, 0, jumpZ)

            loco:Jump()
            loco:SetVelocity(jumpVel)
            self:EmitSound("npc/headcrab_fast/fast_headcrab_leap1.wav", 80, math.random(115, 135))

            self.nextJumpTime = CurTime() + math.Rand(2.5, 4.0)

            local tStart = CurTime()
            coroutine.wait(0.2)

            while IsValid(self) and not self:IsOnGround() and (CurTime() - tStart) < 1.5 do
                local currentDistSqr = self:GetPos():DistToSqr(target:GetPos())
                if currentDistSqr <= self.ATTACK_RANGE_LIMIT_SQR then
                    self:AttackPlayer(target)
                end

                coroutine.wait(0.05)
            end

            coroutine.wait(0.25)
            continue
        end

        // Chase the player
        if distSqr <= self.CHASE_RANGE_SQR then
            loco:SetDesiredSpeed(self.genes.speed * 1.2)

            local path = Path("Follow")
            path:SetMinLookAheadDistance(50)

            local nextComputeTime = 0
            local t0 = CurTime()
            while IsValid(self) and (isBase or IsValid(target)) and (CurTime() - t0) < 2 do
                local dSqr = self:GetPos():DistToSqr(target:GetPos())
                if dSqr <= self.ATTACK_RANGE_SQR or dSqr > self.CHASE_RANGE_LIMIT_SQR then break end
                
                // Can we jump?
                if dSqr <= 800 * 800 and not isBase and (not self.nextJumpTime or CurTime() >= self.nextJumpTime) then
                    break // break chase to perform jump
                end

                local now = CurTime()
                if now >= nextComputeTime then
                    nextComputeTime = now + 0.4
                    path:Compute(self, target:GetPos())
                end

                path:Update(self)
                coroutine.wait(0.05)
            end

            continue
        end

        loco:SetDesiredSpeed(self.genes.speed * 0.55)
        local path = Path("Follow")
        path:Compute(self, target:GetPos())

        local t0 = CurTime()
        while IsValid(self) and (isBase or IsValid(target)) and (CurTime() - t0) < 1.5 do
            path:Update(self)
            coroutine.wait(0.05)
        end
    end
end
