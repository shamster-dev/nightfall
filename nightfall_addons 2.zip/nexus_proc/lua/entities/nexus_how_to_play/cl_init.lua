include("shared.lua")

function ENT:Draw()
    self:DrawModel()

    local pos = self:GetPos() + Vector(0, 0, 18)
    local ang = LocalPlayer():EyeAngles()
    ang:RotateAroundAxis(ang:Up(), -90)
    ang:RotateAroundAxis(ang:Forward(), 90)

    local text = "How To Play"
    local glowCol = Nexus:SetAlpha(Nexus:GetColor("orange"), 200 + math.sin(RealTime() * 4) * 55)

    local titleFont = Nexus:GetFont({size = 35, bold = true, dontScale = true})
    local descriptionFont = Nexus:GetFont({size = 15, dontScale = true})
    cam.Start3D2D(pos, ang, 0.1)
        draw.SimpleText(text, titleFont, 1, 1, color_black, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText(text, titleFont, 0, 0, glowCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        draw.SimpleText("(Press E to use)", descriptionFont, 1, 39, color_black, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText("(Press E to use)", descriptionFont, 0, 40, glowCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    cam.End3D2D()
end

local COLOR_BG = Color(20, 20, 26, 230)
local COLOR_CARD_BG = Color(30, 30, 40, 200)
local COLOR_TEXT = Color(240, 240, 245)
local COLOR_TEXT_DIM = Color(170, 170, 188)
local COLOR_ACCENT = Color(255, 170, 0)
local COLOR_DANGER = Color(255, 75, 75)
local COLOR_SUCCESS = Color(124, 217, 87)
local COLOR_BLUE = Color(0, 195, 255)
local COLOR_PURPLE = Color(186, 85, 211)

local function AddSectionHeader(parent, text)
    local lbl = parent:Add("DLabel")
    lbl:Dock(TOP)
    lbl:DockMargin(0, Nexus:GetScale(14), 0, Nexus:GetScale(8))
    lbl:SetFont(Nexus:GetFont({size = 22, bold = true, font = "Lato"}))
    lbl:SetTextColor(COLOR_ACCENT)
    lbl:SetText(text)
    lbl:SizeToContentsY()
    return lbl
end

local function OpenImageLightbox(imagePath, titleText)
    local frame = vgui.Create("Nexus:V2:Frame")
    frame:SetSize(Nexus:GetScale(900), Nexus:GetScale(650))
    frame:Center()
    frame:MakePopup()
    frame:SetTitle(titleText or "Image Preview")

    local mat = Material(imagePath, "smooth noclamp")
    local imgPanel = vgui.Create("DPanel", frame)
    imgPanel:Dock(FILL)
    imgPanel:DockMargin(Nexus:GetScale(15), Nexus:GetScale(15), Nexus:GetScale(15), Nexus:GetScale(15))
    imgPanel.Paint = function(self, w, h)
        draw.RoundedBox(8, 0, 0, w, h, Color(10, 10, 14, 240))
        if mat and not mat:IsError() then
            surface.SetDrawColor(255, 255, 255, 255)
            surface.SetMaterial(mat)

            local matW, matH = mat:Width(), mat:Height()
            local availW, availH = w - 16, h - 16
            if matW > 0 and matH > 0 then
                local aspect = matW / matH
                local drawW, drawH = availW, availH
                if (availW / availH) > aspect then
                    drawW = availH * aspect
                else
                    drawH = availW / aspect
                end
                local drawX = (w - drawW) / 2
                local drawY = (h - drawH) / 2
                surface.DrawTexturedRect(drawX, drawY, drawW, drawH)
            else
                surface.DrawTexturedRect(8, 8, availW, availH)
            end
        end
    end
end

local function AddGuideCard(parent, titleText, descText, images, accentColor)
    local card = parent:Add("DPanel")
    card:Dock(TOP)
    card:DockMargin(0, 0, 0, Nexus:GetScale(16))
    card:DockPadding(Nexus:GetScale(14), Nexus:GetScale(12), Nexus:GetScale(14), Nexus:GetScale(14))

    card.Paint = function(self, w, h)
        draw.RoundedBox(8, 0, 0, w, h, COLOR_CARD_BG)
        if accentColor then
            surface.SetDrawColor(accentColor)
            surface.DrawRect(0, 0, Nexus:GetScale(4), h)
        end
    end

    if titleText then
        local title = card:Add("DLabel")
        title:Dock(TOP)
        title:SetFont(Nexus:GetFont({size = 20, bold = true, font = "Lato"}))
        title:SetTextColor(accentColor or COLOR_TEXT)
        title:SetText(titleText)
        title:SizeToContentsY()
    end

    if descText then
        local desc = card:Add("DLabel")
        desc:Dock(TOP)
        desc:DockMargin(0, Nexus:GetScale(6), 0, Nexus:GetScale(10))
        desc:SetFont(Nexus:GetFont({size = 16, font = "Lato"}))
        desc:SetTextColor(COLOR_TEXT_DIM)
        desc:SetWrap(true)
        desc:SetAutoStretchVertical(true)
        desc:SetText(descText)
    end

    if images and #images > 0 then
        local imgContainer = card:Add("DPanel")
        imgContainer:Dock(TOP)
        imgContainer:DockMargin(0, Nexus:GetScale(6), 0, 0)
        imgContainer:SetPaintBackground(false)

        local numImages = #images
        local imgHeight = numImages > 2 and Nexus:GetScale(170) or Nexus:GetScale(220)
        imgContainer:SetTall(imgHeight)

        local spacing = Nexus:GetScale(10)
        
        imgContainer.PerformLayout = function(self, w, h)
            local count = #images
            local itemW = (w - (spacing * (count - 1))) / count
            for idx, imgChild in ipairs(self:GetChildren()) do
                imgChild:SetPos((idx - 1) * (itemW + spacing), 0)
                imgChild:SetSize(itemW, h)
            end
        end

        for _, imgData in ipairs(images) do
            local path = type(imgData) == "table" and imgData.path or imgData
            local label = type(imgData) == "table" and imgData.label or nil
            local mat = Material(path, "smooth noclamp")

            local imgBtn = imgContainer:Add("DButton")
            imgBtn:SetText("")
            imgBtn:SetCursor("hand")
            imgBtn.Paint = function(self, w, h)
                local isHover = self:IsHovered()
                draw.RoundedBox(6, 0, 0, w, h, isHover and COLOR_ACCENT or Color(10, 10, 15, 200))

                local labelH = label and 26 or 4
                local availW = w - 8
                local availH = h - labelH - 4

                if mat and not mat:IsError() then
                    surface.SetDrawColor(255, 255, 255, 255)
                    surface.SetMaterial(mat)

                    local matW, matH = mat:Width(), mat:Height()
                    if matW > 0 and matH > 0 then
                        local aspect = matW / matH
                        local drawW, drawH = availW, availH
                        if (availW / availH) > aspect then
                            drawW = availH * aspect
                        else
                            drawH = availW / aspect
                        end
                        local drawX = (w - drawW) / 2
                        local drawY = 4 + (availH - drawH) / 2
                        surface.DrawTexturedRect(drawX, drawY, drawW, drawH)
                    else
                        surface.DrawTexturedRect(4, 4, availW, availH)
                    end
                end

                if label then
                    draw.RoundedBoxEx(6, 2, h - 24, w - 4, 22, Color(15, 15, 20, 220), false, false, true, true)
                    draw.SimpleText(label, Nexus:GetFont({size = 13, font = "Lato"}), w / 2, h - 13, isHover and COLOR_ACCENT or COLOR_TEXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                end
            end

            imgBtn.DoClick = function()
                OpenImageLightbox(path, label or titleText)
            end
        end
    end

    function card:PerformLayout(w, h)
        local totalH = Nexus:GetScale(24)
        for _, child in ipairs(self:GetChildren()) do
            if child:IsVisible() then
                totalH = totalH + child:GetTall() + Nexus:GetScale(6)
            end
        end
        self:SetTall(totalH)
    end

    return card
end

net.Receive("NightFall:HowToPlay:Open", function()
    local frame = vgui.Create("Nexus:V2:Frame")
    frame:SetSize(Nexus:GetScale(960), Nexus:GetScale(680))
    frame:Center()
    frame:MakePopup()
    frame:SetTitle("NIGHTFALL - SURVIVOR MANUAL")

    -- Top Navigation Bar
    local navbar = vgui.Create("Nexus:V2:Navbar", frame)
    navbar:Dock(TOP)
    navbar:DockMargin(Nexus:GetScale(20), Nexus:GetScale(10), Nexus:GetScale(20), Nexus:GetScale(10))
    navbar:SetFont(Nexus:GetFont({size = 15, bold = true, font="Lato"}))

    -- Main Content Scroll Area
    local scroll = vgui.Create("Nexus:V2:ScrollPanel", frame)
    scroll:Dock(FILL)
    scroll:DockMargin(Nexus:GetScale(20), 0, Nexus:GetScale(20), Nexus:GetScale(20))

    local function RebuildTab(tabId)
        scroll:Clear()

        if tabId == 1 then
            -- Overview & Base
            AddSectionHeader(scroll, "Mission Objective")
            AddGuideCard(
                scroll,
                "Defend Home Base & Rescue Survivors",
                "You are stranded in a hostile sector overrun by procedural spiders. Travel out into the wasteland to rescue missing specialists (Electrician, Engineer/Mechanic, Chemist, Researcher, Pilot). Escort them back to Home Base and keep them alive while they repair their respective systems.",
                { { path = "how_to/Home Base 1.jpg", label = "Home Base Perimeter" } },
                COLOR_ACCENT
            )

            AddSectionHeader(scroll, "Victory & Failure Conditions")
            AddGuideCard(
                scroll,
                "Protect Home Base HP",
                "Spiders will attack both you and Home Base. If Home Base health reaches 0%, all survivors fail immediately. Defend the perimeter until all required machines are socketed and the helicopter arrives.",
                {
                    { path = "how_to/End Screen 1 - Defeated.jpg", label = "Defeated Screen" },
                    { path = "how_to/End Screen 2 - Victory.jpg", label = "Victory Extraction Screen" }
                },
                COLOR_DANGER
            )

        elseif tabId == 2 then
            -- Survivors & Roles
            AddSectionHeader(scroll, "Specialist Survivor Roles")

            AddGuideCard(
                scroll,
                "Electrician (Required)",
                "Repairs circuits at the power grid panel to maintain power and keep lighting sources functional across Home Base.",
                { { path = "how_to/Electrician 2 - NPC.jpg", label = "Electrician Specialist" } },
                Color(255, 215, 0)
            )

            AddGuideCard(
                scroll,
                "Mechanic / Engineer (Required)",
                "Requires engine parts found across the map. Bring engine parts back to Home Base and socket them into the assembly rig.",
                { { path = "how_to/Mechanic 4 - NPC.jpg", label = "Mechanic Specialist" } },
                Color(255, 140, 0)
            )

            AddGuideCard(
                scroll,
                "Chemist (Required)",
                "Requires fuel drums scattered around the map. Carry oil drums back to Home Base and socket them into the chemical station.",
                { { path = "how_to/Chemistry 4 - NPC.jpg", label = "Chemist Specialist" } },
                COLOR_BLUE
            )

            AddGuideCard(
                scroll,
                "Researcher (Optional Support)",
                "Not strictly required for extraction, but their radar scanner active-traces signals to reveal and mark missing NPCs on your HUD/minimap.",
                { { path = "how_to/Researcher 1 - NPC.jpg", label = "Researcher Specialist" } },
                COLOR_PURPLE
            )

            AddGuideCard(
                scroll,
                "Pilot (Required for Extraction)",
                "Bring the Pilot home last. Once all required specialist machines are fully repaired and online, the Pilot preps the helicopter for final extraction.",
                { { path = "how_to/Pilot 1 - NPC.jpg", label = "Pilot Specialist" } },
                COLOR_SUCCESS
            )

        elseif tabId == 3 then
            -- Machinery & Parts
            AddSectionHeader(scroll, "Assembly Rigs & Socketing")

            AddGuideCard(
                scroll,
                "Engine Assembly Rig (Mechanic)",
                "Locate Engine parts out in the field. Walk up to an engine part, pick it up into your inventory (F3), carry it to Home Base, and socket it into the rig.",
                {
                    { path = "how_to/Mechanic 3 - Engine.jpg", label = "Engine Part" },
                    { path = "how_to/Mechanic 1 - Unsocketed Engine.jpg", label = "Unsocketed Rig" },
                    { path = "how_to/Mechanic 2 - Socketed Engine.jpg", label = "Socketed Rig" }
                },
                Color(255, 140, 0)
            )

            AddGuideCard(
                scroll,
                "Fuel Chemical Station (Chemist)",
                "Search for Oil Fuel Drums around the map. Pick them up and socket them into the Chemist's station to synthesize fuel charges.",
                {
                    { path = "how_to/Chemistry 3 - Oil Drum.jpg", label = "Oil Drum Part" },
                    { path = "how_to/Chemistry 1 - Unsocketed Oil.jpg", label = "Unsocketed Station" },
                    { path = "how_to/Chemistry 2 - Socketed Oil.jpg", label = "Socketed Station" }
                },
                COLOR_BLUE
            )

            AddGuideCard(
                scroll,
                "Electrician Power Grid",
                "The Electrician works directly on the main power terminal to restore sector power once escorted to Home Base.",
                { { path = "how_to/Electrician 1 - Machine.jpg", label = "Power Grid Terminal" } },
                Color(255, 215, 0)
            )

        elseif tabId == 4 then
            -- Stations & Extraction
            AddSectionHeader(scroll, "Base Stations & Helipad")

            AddGuideCard(
                scroll,
                "Armory & Weapon Upgrades",
                "Access the Armory station at base to purchase primary weapons, secondary sidearms, ammunition, and attachments.",
                { { path = "how_to/Armoury.jpg", label = "Armory Weapon Station" } },
                COLOR_ACCENT
            )

            AddGuideCard(
                scroll,
                "Perk Station",
                "Upgrade your survivor perks (Spider Hunter, Heavy Hitter, Executioner, Fast Reload) to boost damage and squad survival.",
                { { path = "how_to/Perk Box 1.jpg", label = "Perk Box Terminal" } },
                COLOR_PURPLE
            )

            AddGuideCard(
                scroll,
                "Ammo Resupply Crate",
                "Interact with Ammo Crates stationed around Home Base to replenish your weapon reserve ammo during heavy waves.",
                { { path = "how_to/Ammo Crate 1.jpg", label = "Ammo Crate" } },
                COLOR_BLUE
            )

            AddGuideCard(
                scroll,
                "Helicopter Extraction",
                "When all required machines reach 100% repair status, the pilot signals the extraction helicopter. Board the chopper at the extraction pad to win!",
                { { path = "how_to/Extraction NPC 1.jpg", label = "Extraction Helicopter Pad" } },
                COLOR_SUCCESS
            )

        elseif tabId == 5 then
            -- Threats & Commands
            AddSectionHeader(scroll, "Threats & NPC Commands")

            AddGuideCard(
                scroll,
                "Spider Waves & Bounties",
                "Spiders (Standard, Jumping, Mother Spiders) spawn continually in waves. Killing spiders awards $2 cash bounties per kill to spend at the Armory and Perk Box.",
                nil,
                COLOR_DANGER
            )

            AddGuideCard(
                scroll,
                "NPC Escort Commands",
                "When you find a survivor NPC in the wasteland, press E to tell them to Follow You. Escort them back to Home Base and direct them to their assigned station.",
                {
                    { path = "how_to/NPC Status 1 - Following.jpg", label = "NPC Following Status" },
                    { path = "how_to/NPC Status 1 - Moving to statiion.jpg", label = "NPC Station Bound" }
                },
                COLOR_ACCENT
            )
        end
    end

    navbar:AddItem("Overview & Base", function() RebuildTab(1) end, nil, 1)
    navbar:AddItem("Survivors & Roles", function() RebuildTab(2) end, nil, 2)
    navbar:AddItem("Machinery & Parts", function() RebuildTab(3) end, nil, 3)
    navbar:AddItem("Stations & Extraction", function() RebuildTab(4) end, nil, 4)
    navbar:AddItem("Threats & Commands", function() RebuildTab(5) end, nil, 5)

    navbar:SelectItem(1)
end)