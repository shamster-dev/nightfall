include("shared.lua")

local Spider = Nexus.Proc.Spider
local STEP_THRESHOLD_SQR = Spider.STEP_THRESHOLD * Spider.STEP_THRESHOLD
local cvDrawDist = CreateClientConVar("cl_nexus_spider_draw_dist", "3000", true, false, "Maximum distance to draw procedural spider legs.", 100, 5000)

local matBody = CreateMaterial("nexusproc_spider_body_v4", "VertexLitGeneric", {
    ["$basetexture"]  = "color/white",
    ["$model"]        = "1",
    ["$halflambert"]  = "1",
    ["$vertexcolor"]  = "1",
    ["$vertexalpha"]  = "1",
})

local matGlow = CreateMaterial("nexusproc_spider_eye_v3", "UnlitGeneric", {
    ["$basetexture"] = "color/white",
    ["$additive"]    = "1",
    ["$vertexcolor"] = "1",
    ["$vertexalpha"] = "1",
})

local CylinderMesh = CylinderMesh or nil
local SphereMesh = SphereMesh or nil
local function InitStaticMeshes()
    if CylinderMesh and SphereMesh then return end

    CylinderMesh = Mesh()
    SphereMesh = Mesh()

    local cylinderVerts = {}
    local segments = 8
    local whiteCol = Color(255, 255, 255, 255)
    for i = 0, segments - 1 do
        local a0 = (i / segments) * math.pi * 2
        local a1 = ((i + 1) / segments) * math.pi * 2
        
        local cos0, sin0 = math.cos(a0), math.sin(a0)
        local cos1, sin1 = math.cos(a1), math.sin(a1)
        
        local n0 = Vector(0, cos0, sin0)
        local n1 = Vector(0, cos1, sin1)
        
        local s0 = Vector(0, cos0, sin0)
        local s1 = Vector(0, cos1, sin1)
        local e0 = Vector(1, cos0, sin0)
        local e1 = Vector(1, cos1, sin1)
        
        local u0 = i / segments
        local u1 = (i + 1) / segments
        
        table.insert(cylinderVerts, { pos = s0, normal = n0, u = u0, v = 0, color = whiteCol })
        table.insert(cylinderVerts, { pos = s1, normal = n1, u = u1, v = 0, color = whiteCol })
        table.insert(cylinderVerts, { pos = e0, normal = n0, u = u0, v = 1, color = whiteCol })
        
        table.insert(cylinderVerts, { pos = s1, normal = n1, u = u1, v = 0, color = whiteCol })
        table.insert(cylinderVerts, { pos = e1, normal = n1, u = u1, v = 1, color = whiteCol })
        table.insert(cylinderVerts, { pos = e0, normal = n0, u = u0, v = 1, color = whiteCol })
    end
    CylinderMesh:BuildFromTriangles(cylinderVerts)
    
    local sphereVerts = {}
    local longitudeSegs = 8
    local latitudeSegs = 8
    for i = 0, latitudeSegs - 1 do
        local lat0 = math.pi * (-0.5 + i / latitudeSegs)
        local lat1 = math.pi * (-0.5 + (i + 1) / latitudeSegs)
        local sinLat0, cosLat0 = math.sin(lat0), math.cos(lat0)
        local sinLat1, cosLat1 = math.sin(lat1), math.cos(lat1)
        
        for j = 0, longitudeSegs - 1 do
            local lon0 = 2 * math.pi * (j / longitudeSegs)
            local lon1 = 2 * math.pi * ((j + 1) / longitudeSegs)
            local sinLon0, cosLon0 = math.sin(lon0), math.cos(lon0)
            local sinLon1, cosLon1 = math.sin(lon1), math.cos(lon1)
            
            local p00 = Vector(cosLat0 * cosLon0, cosLat0 * sinLon0, sinLat0)
            local p01 = Vector(cosLat0 * cosLon1, cosLat0 * sinLon1, sinLat0)
            local p10 = Vector(cosLat1 * cosLon0, cosLat1 * sinLon0, sinLat1)
            local p11 = Vector(cosLat1 * cosLon1, cosLat1 * sinLon1, sinLat1)
            
            table.insert(sphereVerts, { pos = p00, normal = p00, u = j/longitudeSegs, v = i/latitudeSegs, color = whiteCol })
            table.insert(sphereVerts, { pos = p01, normal = p01, u = (j+1)/longitudeSegs, v = i/latitudeSegs, color = whiteCol })
            table.insert(sphereVerts, { pos = p10, normal = p10, u = j/longitudeSegs, v = (i+1)/latitudeSegs, color = whiteCol })
            
            table.insert(sphereVerts, { pos = p01, normal = p01, u = (j+1)/longitudeSegs, v = i/latitudeSegs, color = whiteCol })
            table.insert(sphereVerts, { pos = p11, normal = p11, u = (j+1)/longitudeSegs, v = (i+1)/latitudeSegs, color = whiteCol })
            table.insert(sphereVerts, { pos = p10, normal = p10, u = j/longitudeSegs, v = (i+1)/latitudeSegs, color = whiteCol })
        end
    end
    SphereMesh:BuildFromTriangles(sphereVerts)
end

local ActiveSpiders = ActiveSpiders or {}
local mat = Matrix()
local function DrawCylinder(startPos, endPos, radius)
    if not CylinderMesh then InitStaticMeshes() end
    local diff = endPos - startPos
    local len = diff:Length()
    if len < 0.01 then return end

    mat:Identity()
    mat:Translate(startPos)
    mat:SetAngles(diff:Angle())
    mat:Scale(Vector(len, radius, radius))

    cam.PushModelMatrix(mat)
    CylinderMesh:Draw()
    cam.PopModelMatrix()
end

local function DrawSphere(pos, radius)
    if not SphereMesh then InitStaticMeshes() end
    mat:Identity()
    mat:Translate(pos)
    mat:Scale(Vector(radius, radius, radius))

    cam.PushModelMatrix(mat)
    SphereMesh:Draw()
    cam.PopModelMatrix()
end

local function GetIdealFootPos(ent, legIdx, genes, groundZ)
    local legDef  = Spider.LEG_ROOTS[legIdx]
    local bodyPos = ent:GetPos()
    local angles  = ent:GetAngles()
    local yaw     = angles.y

    local fwd = angles:Forward()

    local angYaw = yaw + legDef.ang
    local legDir = Vector(math.cos(math.rad(angYaw)), math.sin(math.rad(angYaw)), 0)

    local spread  = genes.bodyRadius * genes.legSpread * 0.75
    local rootPos = bodyPos
        + legDir * spread
        + fwd * (legDef.fwd * genes.bodyRadius * 0.45)

    local isDead = ent:GetNWBool("IsDead", false)
    local bodyHeight = isDead and 2 or genes.bodyHeight
    rootPos.z = bodyPos.z + bodyHeight

    local velocity = ent:GetVelocity()
    local forwardBias = velocity * 0.12
    forwardBias.z = 0

    local reach = (genes.legLength1 + genes.legLength2 + genes.legLength3) * 0.58
    local footXY = rootPos + legDir * reach + forwardBias

    if groundZ then
        return Vector(footXY.x, footXY.y, groundZ)
    end

    local tr = util.TraceLine({
        start  = Vector(footXY.x, footXY.y, bodyPos.z + bodyHeight + 60),
        endpos = Vector(footXY.x, footXY.y, bodyPos.z - 300),
        filter = ent,
        mask   = MASK_SOLID_BRUSHONLY,
    })

    return tr.Hit and tr.HitPos or Vector(footXY.x, footXY.y, bodyPos.z)
end

local function UpdateLegsClient(ent, genes, distSqr)
    local now = CurTime()
    
    local bodyPos = ent:GetPos()
    local isDead = ent:GetNWBool("IsDead", false)
    local trBody = util.TraceLine({
        start  = bodyPos + Vector(0, 0, 50),
        endpos = bodyPos - Vector(0, 0, 300),
        filter = ent,
        mask   = MASK_SOLID_BRUSHONLY,
    })

    local groundZ = trBody.Hit and trBody.HitPos.z or bodyPos.z
    if not ent.footPos then
        ent.footPos       = {}
        ent.footIdeal     = {}
        ent.footStepping  = {}
        ent.footStepStart = {}
        ent.footStepFrom  = {}
        ent.footStepTo    = {}
        ent.stepGroupIdx  = 1
        ent.lastStepTime  = 0

        for i = 1, Spider.LEG_COUNT do
            local footPos = GetIdealFootPos(ent, i, genes, groundZ)
            ent.footPos[i]       = Vector(footPos)
            ent.footIdeal[i]     = Vector(footPos)
            ent.footStepping[i]  = false
            ent.footStepStart[i] = 0
            ent.footStepFrom[i]  = Vector(footPos)
            ent.footStepTo[i]    = Vector(footPos)
        end
    end

    local isDead = ent:GetNWBool("IsDead", false)
    if isDead then
        for i = 1, Spider.LEG_COUNT do
            local footPos = GetIdealFootPos(ent, i, genes, groundZ)
            ent.footPos[i]:Set(footPos)
            ent.footStepping[i] = false
        end

        return
    end

    local traceThrottle = 0.033
    if distSqr > 2000 * 2000 then
        traceThrottle = 0.25
    elseif distSqr > 1000 * 1000 then
        traceThrottle = 0.09
    end

    ent.nextTraceTime = ent.nextTraceTime or 0
    if now >= ent.nextTraceTime then
        ent.nextTraceTime = now + traceThrottle

        for i = 1, Spider.LEG_COUNT do
            local footPos = GetIdealFootPos(ent, i, genes, groundZ)
            ent.footIdeal[i]:Set(footPos)
        end
    end

    for i = 1, Spider.LEG_COUNT do
        if not ent.footStepping[i] then continue end

        local t = (now - ent.footStepStart[i]) / Spider.STEP_DURATION
        if t >= 1 then
            ent.footPos[i]:Set(ent.footStepTo[i])
            ent.footStepping[i] = false
            continue
        end

        local ease = t * t * (3 - 2 * t)
        local arc  = math.sin(t * math.pi) * Spider.STEP_ARC_HEIGHT
        
        local from = ent.footStepFrom[i]
        local to = ent.footStepTo[i]
        ent.footPos[i].x = from.x + (to.x - from.x) * ease
        ent.footPos[i].y = from.y + (to.y - from.y) * ease
        ent.footPos[i].z = from.z + (to.z - from.z) * ease + arc
    end

    if (now - ent.lastStepTime) < Spider.STEP_DURATION * 1.1 then return end

    local group = Spider.STEP_GROUPS[ent.stepGroupIdx]
    local anyNeedStep = false
    for _, i in ipairs(group) do
        if not ent.footStepping[i] and ent.footPos[i]:DistToSqr(ent.footIdeal[i]) > STEP_THRESHOLD_SQR then
            anyNeedStep = true
            break
        end
    end

    if not anyNeedStep then return end

    for _, i in ipairs(group) do
        if ent.footStepping[i] then continue end
        ent.footStepping[i]  = true
        ent.footStepStart[i] = now
        ent.footStepFrom[i]:Set(ent.footPos[i])
        ent.footStepTo[i]:Set(ent.footIdeal[i])
    end

    -- Play subtle skittering footstep sound for the step group
    local soundName = "npc/antlion/foot" .. math.random(1, 4) .. ".wav"
    local pitch = math.Clamp(math.Round(120 / (genes.scale or 1)), 80, 160)
    ent:EmitSound(soundName, 58, pitch, 0.35)

    ent.lastStepTime = now
    ent.stepGroupIdx = (ent.stepGroupIdx % #Spider.STEP_GROUPS) + 1
end

local function GetSpiderGeometry(ent, genes)
    local bodyPos = ent:GetPos()
    local angles  = ent:GetAngles()
    local bodyYaw = angles.y

    local fwd = angles:Forward()
    local rgt = angles:Right()

    local isDead = ent:GetNWBool("IsDead", false)
    local bodyHeight = isDead and 2 or genes.bodyHeight
    local bodyCenter    = Vector(bodyPos.x, bodyPos.y, bodyPos.z + bodyHeight)
    
    local lastAttack = ent:GetNWFloat("LastAttackTime", 0)
    local attackTime = CurTime() - lastAttack
    if attackTime < 0.45 then
        local progress = attackTime / 0.45
        local bodyOffset
        if progress < 0.25 then // Rear up
            local f = progress / 0.25
            bodyOffset = -fwd * (5 * f) + Vector(0, 0, 10 * f)
        elseif progress < 0.55 then // Strike
            local f = (progress - 0.25) / 0.30
            bodyOffset = fwd * (18 * f) - Vector(0, 0, 12 * f)
        else // Recovery
            local f = (progress - 0.55) / 0.45
            local ease = f * f * (3 - 2 * f)
            bodyOffset = (fwd * 18 - Vector(0, 0, 12)) * (1 - ease)
        end

        bodyCenter:Add(bodyOffset)
    end

    local abdomenCenter = bodyCenter - fwd * (genes.bodyRadius * 0.65 + genes.abdomenRadius * 0.55)
    local neckMid = (bodyCenter + abdomenCenter) * 0.5

    return bodyPos, angles, bodyYaw, fwd, rgt, bodyCenter, abdomenCenter, neckMid
end

local function DrawSpiderLegsOnly(ent, genes, distSqr)
    local bodyPos, angles, bodyYaw, fwd, rgt, bodyCenter, abdomenCenter, neckMid = GetSpiderGeometry(ent, genes)

    local femurR    = genes.bodyRadius * 0.115
    local tibiaR    = genes.bodyRadius * 0.085
    local tarsusR   = genes.bodyRadius * 0.060

    local drawSpheres = distSqr < 200 * 200

    local r, g, b = render.GetColorModulation()
    local blend = render.GetBlend()

    render.SetMaterial(matBody)

    local lastAttack = ent:GetNWFloat("LastAttackTime", 0)
    local attackTime = CurTime() - lastAttack

    for i = 1, Spider.LEG_COUNT do
        local legDef  = Spider.LEG_ROOTS[i]
        local angYaw  = bodyYaw + legDef.ang
        local legDir  = Vector(math.cos(math.rad(angYaw)), math.sin(math.rad(angYaw)), 0)

        local spread  = genes.bodyRadius * genes.legSpread * 0.75
        local rootPos = bodyCenter
            + legDir * spread
            + fwd * (legDef.fwd * genes.bodyRadius * 0.45)

        local outwardDir = Vector(legDir.x, legDir.y, 0)
        local hint = outwardDir + Vector(0, 0, 0.65)
        hint:Normalize()

        local foot = ent.footPos[i]
        if not foot then continue end

        // Front leg attack
        if (i == 1 or i == 5) and attackTime < 0.45 then
            local progress = attackTime / 0.45
            local frontLegOffset = 0
            if progress < 0.25 then
                frontLegOffset = 45 * (progress / 0.25)
            elseif progress < 0.55 then
                frontLegOffset = 45 * (1 - ((progress - 0.25) / 0.30) * 1.5)
            else
                local f = (progress - 0.55) / 0.45
                local ease = f * f * (3 - 2 * f)
                frontLegOffset = -22.5 * (1 - ease)
            end

            foot = Vector(foot.x, foot.y, foot.z + frontLegOffset) + fwd * (frontLegOffset * 0.3)
        end

        local isLeft = i > 4
        local kneePos, adjFootPos = Spider.SolveTwoBone(rootPos, foot, genes.legLength1, genes.legLength2 + genes.legLength3, hint, isLeft)

        local fLegCol = ent.legColors[i]

        // Level of detail
        if distSqr > 1500 * 1500 then
            -- LOD 3: Too far away, skip drawing legs entirely (only draw body/eyes/shadows)
        elseif distSqr > 1000 * 1000 then
            -- LOD 2: Medium distance, draw cheap single-pixel lines (nearly zero GPU overhead)
            render.DrawLine(rootPos, kneePos, fLegCol, true)
            render.DrawLine(kneePos, adjFootPos, fLegCol, true)
        else
            -- LOD 1: Close range, draw textured beams for nice thickness (2 segments instead of 3)
            render.DrawBeam(rootPos, kneePos, femurR * 2.3, 0, 1, fLegCol)
            render.DrawBeam(kneePos, adjFootPos, tibiaR * 2.3, 0, 1, fLegCol)

            -- Joint spheres (only draw when extremely close to the player < 200 units)
            if drawSpheres then
                local jointCol = ent.jointCol
                local legTipCol = ent.legTipCol
                render.SetColorModulation(jointCol.r / 255, jointCol.g / 255, jointCol.b / 255)
                render.SetBlend(jointCol.a / 255)
                DrawSphere(rootPos, femurR * 1.35)
                DrawSphere(kneePos, femurR * 1.2)
                
                render.SetColorModulation(legTipCol.r / 255, legTipCol.g / 255, legTipCol.b / 255)
                render.SetBlend(legTipCol.a / 255)
                DrawSphere(adjFootPos, tarsusR * 1.15)
            end
        end
    end

    render.SetColorModulation(r, g, b)
    render.SetBlend(blend)
end

local function DrawSpiderBodyAndEyesOnly(ent, genes, distSqr)
    local bodyPos, angles, bodyYaw, fwd, rgt, bodyCenter, abdomenCenter, neckMid = GetSpiderGeometry(ent, genes)

    if distSqr > 1800 * 1800 then return end

    if not ent.Emitter then
        ent.Emitter = ParticleEmitter(bodyPos, false)
    end

    local particleRate = 0.05
    if distSqr > 800 * 800 then
        particleRate = 0.15
    end

    local now = CurTime()
    local spawnParticles = false
    if now >= (ent.nextParticleTime or 0) then
        ent.nextParticleTime = now + particleRate
        spawnParticles = true
    end

    local emitter = ent.Emitter
    if emitter then
        emitter:SetPos(bodyCenter)

        if spawnParticles then
            local function spawnShadow(pos, radius)
                local p = emitter:Add("particle/smokestack", pos + VectorRand() * (radius * 0.15))
                if p then
                    p:SetDieTime(math.Rand(0.3, 0.6))
                    p:SetStartAlpha(math.Rand(180, 240))
                    p:SetEndAlpha(0)
                    p:SetStartSize(radius * math.Rand(0.25, 0.45))
                    p:SetEndSize(radius * math.Rand(0.45, 0.75))
                    p:SetRoll(math.Rand(-180, 180))
                    p:SetRollDelta(math.Rand(-3, 3))
                    
                    local baseCol = ent.shadowCol
                    p:SetColor(baseCol.r, baseCol.g, baseCol.b)
                    p:SetVelocity(VectorRand() * 3 + ent:GetVelocity() * 0.5)
                    p:SetAirResistance(12)
                end
            end

            for _ = 1, 2 do
                spawnShadow(bodyCenter, genes.bodyRadius)
                spawnShadow(abdomenCenter, genes.abdomenRadius)
                spawnShadow(neckMid, genes.bodyRadius * 0.4)
            end
        end
    end

    local eyeRadius  = genes.bodyRadius * 0.22
    local eyeRingR   = genes.bodyRadius * 0.38
    local eyeForward = genes.bodyRadius * 1.05
    if not (emitter and spawnParticles) then return end
    for _, side in ipairs({-1, 1}) do
        local eOff = fwd * eyeForward
            + rgt * (side * eyeRingR)
            + Vector(0, 0, genes.bodyRadius * 0.15)

        local ePos = bodyCenter + eOff

        local p = emitter:Add("particle/particle_glow_04", ePos + VectorRand() * 0.8)
        if not p then return end
        p:SetDieTime(math.Rand(0.12, 0.28))
        p:SetStartAlpha(255)
        p:SetEndAlpha(0)
        p:SetStartSize(eyeRadius * math.Rand(1.8, 3.0))
        p:SetEndSize(eyeRadius * 0.4)
        p:SetRoll(math.Rand(-180, 180))
        p:SetRollDelta(math.Rand(-4, 4))
        p:SetColor(255, 0, 0)
        p:SetVelocity(fwd * 12 + ent:GetVelocity() * 0.8)
        p:SetAirResistance(4)
    end
end

function ENT:Initialize()
    self:SetRenderBounds(Vector(-500, -500, -300), Vector(500, 500, 500))
    ActiveSpiders[self] = true

    InitStaticMeshes()
end

function ENT:Think()
    ActiveSpiders[self] = true

    local seed = self:GetNWInt("SpiderSeed", 0)
    if seed == 0 then
        local idx = self:EntIndex()
        seed = (idx > 0) and (idx * 7919 + 3) or 12345
    end

    if not self.genes then
        self.genes = Spider.GenerateGenes(seed)

        self.legColors = {}

        for i = 1, Spider.LEG_COUNT do
            local shade = 0.80 + (((i - 1) % 4) * 0.06)
            self.legColors[i] = Spider.HSVtoColor(self.genes.hue, self.genes.sat, self.genes.val * shade)
        end

        self.jointCol  = Spider.HSVtoColor(self.genes.hue, self.genes.sat, self.genes.val * 0.55)
        self.legTipCol = Spider.HSVtoColor(self.genes.hue, self.genes.sat, self.genes.val * 0.45)
        self.shadowCol = Spider.HSVtoColor(self.genes.hue, self.genes.sat, self.genes.val * 0.2)
    end

    local eyePos = EyePos()
    local entPos = self:GetPos()
    local distSqr = eyePos:DistToSqr(entPos)

    local maxDist = cvDrawDist:GetInt()
    local maxDistSqr = maxDist * maxDist
    if distSqr > maxDistSqr then return end

    local throttle = 0.033
    if distSqr > 2000 * 2000 then
        throttle = 0.16
    elseif distSqr > 1000 * 1000 then
        throttle = 0.08
    end

    local now = CurTime()
    self.nextThinkTime = self.nextThinkTime or 0
    if now >= self.nextThinkTime then
        self.nextThinkTime = now + throttle
        UpdateLegsClient(self, self.genes, distSqr)
    end
end

function ENT:Draw()
end

function ENT:DrawTranslucent()
    if self.genes and self.footPos then
        local entPos = self:GetPos()
        local distSqr = EyePos():DistToSqr(entPos)
        local maxDist = cvDrawDist:GetInt()
        if distSqr <= maxDist * maxDist then
            render.SetLightingOrigin(entPos)
            DrawSpiderLegsOnly(self, self.genes, distSqr)
            DrawSpiderBodyAndEyesOnly(self, self.genes, distSqr)
        end
    end
end

hook.Add("PostDrawOpaqueRenderables", "NexusProc:Spider:FallbackDraw", function(bDepth, bSkybox)
    if bDepth or bSkybox then return end

    local eyePos = EyePos()
    local maxDist = cvDrawDist:GetInt()
    local maxDistSqr = maxDist * maxDist

    for ent, _ in pairs(ActiveSpiders) do
        if IsValid(ent) and ent.genes and ent.footPos then
            local entPos = ent:GetPos()
            local distSqr = eyePos:DistToSqr(entPos)
            if distSqr <= maxDistSqr then
                render.SetLightingOrigin(entPos)
                DrawSpiderLegsOnly(ent, ent.genes, distSqr)
            end
        end
    end
end)

hook.Add("PostDrawTranslucentRenderables", "NexusProc:Spider:FallbackDrawTranslucent", function(bDepth, bSkybox)
    if bDepth or bSkybox then return end

    local eyePos = EyePos()
    local maxDist = cvDrawDist:GetInt()
    local maxDistSqr = maxDist * maxDist

    for ent, _ in pairs(ActiveSpiders) do
        if IsValid(ent) and ent.genes and ent.footPos then
            local entPos = ent:GetPos()
            local distSqr = eyePos:DistToSqr(entPos)
            if distSqr <= maxDistSqr then
                render.SetLightingOrigin(entPos)
                DrawSpiderBodyAndEyesOnly(ent, ent.genes, distSqr)
            end
        end
    end
end)

function ENT:OnRemove()
    ActiveSpiders[self] = nil
    if IsValid(self.Emitter) then
        self.Emitter:Finish()
    end
end

InitStaticMeshes()