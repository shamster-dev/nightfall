AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

local color_zero = Color(0, 0, 0, 0)
function ENT:Initialize()
    self:SetModel("models/headcrabclassic.mdl")
    self:SetRenderMode(RENDERMODE_TRANSALPHA)
    self:SetColor(color_zero)
    self:DrawShadow(false)

    self:SetSolid(SOLID_BBOX)
    self:SetCollisionGroup(COLLISION_GROUP_WORLD)

    self.Spider = Nexus.Proc.Spider
    self.DETECT_RANGE_SQR = self.Spider.DETECT_RANGE * self.Spider.DETECT_RANGE
    self.CHASE_RANGE_SQR  = self.Spider.CHASE_RANGE * self.Spider.CHASE_RANGE
    self.CHASE_RANGE_LIMIT_SQR = (self.Spider.CHASE_RANGE + 200) * (self.Spider.CHASE_RANGE + 200)
    self.ATTACK_RANGE_SQR = self.Spider.ATTACK_RANGE * self.Spider.ATTACK_RANGE

    baseclass.Get("base_nextbot").Initialize(self)

    local entIdx = self:EntIndex()
    if not entIdx or entIdx <= 0 then
        entIdx = math.random(1, 100000)
    end
    local seed = (entIdx * 7919 + 3) % 4294967296
    if seed == 0 then seed = 12345 end

    self.genes = self.Spider.GenerateGenes(seed)

    self:SetMaxHealth(math.floor(self.genes.health))
    self:SetHealth(math.floor(self.genes.health))

    local scale = (self.genes.bodyRadius * 3.2) / 12
    self:SetModelScale(scale)

    local boxSize = self.genes.bodyRadius * 1.5
    self:SetCollisionBounds(Vector(-boxSize, -boxSize, 0), Vector(boxSize, boxSize, self.genes.bodyHeight + 10))

    self:SetNWInt("SpiderSeed", seed)

    if self.loco then
        self.loco:SetDesiredSpeed(self.genes.speed)
        self.loco:SetAcceleration(500)
        self.loco:SetDeceleration(500)
    end
end

function ENT:OnTakeDamage(dmginfo)
    if self:GetNWBool("IsDead", false) then return end

    self:SetHealth(self:Health() - dmginfo:GetDamage())

    local pitch = math.Clamp(math.Round(105 / (self.genes and self.genes.scale or 1)), 70, 140)
    self:EmitSound("npc/headcrab/pain" .. math.random(1, 3) .. ".wav", 75, pitch)

    if self:Health() > 0 then return end
    self:SetNWBool("IsDead", true)

    self:EmitSound("npc/antlion/pain" .. math.random(1, 2) .. ".wav", 80, pitch)
    self:EmitSound("physics/flesh/flesh_squishy_impact_hard" .. math.random(1, 4) .. ".wav", 75, 90)

    hook.Run("OnNPCKilled", self, dmginfo:GetAttacker(), dmginfo:GetInflictor())

    self:SetSolid(SOLID_NONE)
    self:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
    self.loco:SetDesiredSpeed(0)

    timer.Simple(2, function()
        if not IsValid(self) then return end
        self:Remove()
    end)
end

function ENT:RunBehaviour()
    coroutine.wait(0.5)

    while IsValid(self) do
        if self:GetNWBool("IsDead", false) then
            coroutine.wait(1.0)
            continue
        end

        local loco = self.loco
        if not loco then
            coroutine.wait(0.2)
            coroutine.wait(0.25)
            continue
        end

        local target = self:FindClosestPlayer()
        local isBase = type(target) == "table" and target.IsBase
        local isTargetValid = isBase or IsValid(target)

        if not isTargetValid then
            self.hasSpottedTarget = false
            loco:SetDesiredSpeed(self.genes.speed * 0.30)

            if math.random() < 0.25 then
                local pitch = math.Clamp(math.Round(100 / (self.genes and self.genes.scale or 1)), 75, 140)
                self:EmitSound("npc/headcrab/idle" .. math.random(1, 3) .. ".wav", 60, pitch)
            end

            local dir = Vector(math.Rand(-1, 1), math.Rand(-1, 1), 0)
            if dir:LengthSqr() < 0.001 then dir = Vector(1, 0, 0) end
            dir:Normalize()

            local wander = self:GetPos() + dir * math.Rand(150, 400)
            local path = Path("Follow")
            path:SetMinLookAheadDistance(60)
            path:Compute(self, wander)

            local t0 = CurTime()
            while IsValid(self) and (CurTime() - t0) < 3.5 do
                path:Update(self)
                coroutine.wait(0.05)
            end

            coroutine.wait(math.Rand(0.3, 1.5))

            coroutine.wait(0.25)
            continue
        end

        local distSqr = self:GetPos():DistToSqr(target:GetPos())
        if distSqr <= self.ATTACK_RANGE_SQR then
            self:FaceTarget(target)
            self:SetNWFloat("LastAttackTime", CurTime())

            // Physically lunge forward
            local lungeEnd = CurTime() + 0.15
            local pitch = math.Clamp(math.Round(110 / (self.genes and self.genes.scale or 1)), 75, 140)
            self:EmitSound("npc/headcrab/attack-growl" .. math.random(1, 2) .. ".wav", 75, pitch)
            while IsValid(self) and (isBase or IsValid(target)) and CurTime() < lungeEnd do
                local dir = target:GetPos() - self:GetPos()
                dir.z = 0
                dir:Normalize()

                if self.loco then
                    self.loco:SetVelocity(dir * 550 + Vector(0, 0, 100))
                end

                coroutine.wait(0.01)
            end
            
            if IsValid(self) and (isBase or IsValid(target)) then
                self:AttackPlayer(target)
            end
            coroutine.wait(self.Spider.ATTACK_RATE - 0.15)
        elseif distSqr <= self.CHASE_RANGE_SQR then
            if not self.hasSpottedTarget then
                self.hasSpottedTarget = true
                local pitch = math.Clamp(math.Round(110 / (self.genes and self.genes.scale or 1)), 75, 140)
                self:EmitSound("npc/headcrab/attack-growl" .. math.random(1, 2) .. ".wav", 75, pitch)
            end
            loco:SetDesiredSpeed(self.genes.speed)

            local path = Path("Follow")
            path:SetMinLookAheadDistance(50)

            local nextComputeTime = 0
            local t0 = CurTime()
            while IsValid(self) and (isBase or IsValid(target)) and (CurTime() - t0) < 2 do
                local dSqr = self:GetPos():DistToSqr(target:GetPos())
                if dSqr <= self.ATTACK_RANGE_SQR or dSqr > self.CHASE_RANGE_LIMIT_SQR then break end
                
                local now = CurTime()
                if now >= nextComputeTime then
                    nextComputeTime = now + 0.4
                    path:Compute(self, target:GetPos())
                end
                
                path:Update(self)
                coroutine.wait(0.05)
            end
        else
            loco:SetDesiredSpeed(self.genes.speed * 0.55)

            local path = Path("Follow")
            path:Compute(self, target:GetPos())

            local t0 = CurTime()
            while IsValid(self) and (isBase or IsValid(target)) and (CurTime() - t0) < 1.5 do
                path:Update(self)
                coroutine.wait(0.05)
            end
        end

        coroutine.wait(0.25)
    end
end

-- Track targeting counts on players globally
Nexus.Proc.PlayerTargets = Nexus.Proc.PlayerTargets or {}

function ENT:FindClosestPlayer()
    local now = CurTime()
    if self.nextFindPlayerTime and now < self.nextFindPlayerTime and (not self.cachedPlayerIsBase) and IsValid(self.cachedPlayer) and self.cachedPlayer:Alive() then
        return self.cachedPlayer
    end
    self.nextFindPlayerTime = now + 0.5 -- 2 Hz search rate maximum

    -- Clean up untracked targets
    local selfID = self:EntIndex()
    for ply, t in pairs(Nexus.Proc.PlayerTargets) do
        t[selfID] = nil
    end

    local myPos = self:GetPos()
    local nearest = nil
    local nearDistSqr = math.huge
    local maxSpidersPerPlayer = 3 -- Threshold of spiders per player before they target the base instead

    -- Find nearest player that isn't fully saturated
    for _, ply in ipairs(player.GetAll()) do
        if not ply:Alive() or ply:Team() == TEAM_SPECTATOR then continue end

        local plyPos = ply:GetPos()
        local homeBase = Nexus.Proc.HomeBase
        local safeRadius = Nexus.Proc.BaseSafeRadius or 800
        local isPlayerInBase = homeBase and plyPos:DistToSqr(homeBase) < (safeRadius * safeRadius)
        local isSpiderInBase = homeBase and myPos:DistToSqr(homeBase) < (safeRadius * safeRadius)
        if isPlayerInBase and not isSpiderInBase then continue end

        local dSqr = myPos:DistToSqr(plyPos)
        if dSqr <= self.DETECT_RANGE_SQR then
            -- Count active targeting NextBots
            Nexus.Proc.PlayerTargets[ply] = Nexus.Proc.PlayerTargets[ply] or {}
            local count = table.Count(Nexus.Proc.PlayerTargets[ply])
            
            if count < maxSpidersPerPlayer then
                if dSqr < nearDistSqr then
                    nearest = ply
                    nearDistSqr = dSqr
                end
            end
        end
    end

    -- If players are saturated or none are nearby, target the base walls
    if not nearest and Nexus.Proc.Base and Nexus.Proc.Base.GetClosestWallPoint then
        local wallPos, wallDistSqr, wallIdx = Nexus.Proc.Base:GetClosestWallPoint(myPos)
        if wallPos then
            local dists = Nexus.Proc.SpiderSpawnDistance or {1500, 1800}
            local maxSeeDist = dists[2] * 1.1
            if wallDistSqr <= (maxSeeDist * maxSeeDist) then
                self.cachedPlayerIsBase = true
                -- Create a dummy target object matching the expected structure
                self.cachedPlayer = {
                    IsBase = true,
                    WallPos = wallPos,
                    WallIdx = wallIdx,
                    GetPos = function() return wallPos end,
                    Alive = function() return (Nexus.Proc.Base:GetHP() > 0) end,
                    TakeDamageInfo = function(_, dmgInfo)
                        Nexus.Proc.Base:TakeDamage(dmgInfo:GetDamage(), self)
                    end
                }
                return self.cachedPlayer
            end
        end
    end

    self.cachedPlayerIsBase = false
    self.cachedPlayer = nearest
    if IsValid(nearest) then
        Nexus.Proc.PlayerTargets[nearest] = Nexus.Proc.PlayerTargets[nearest] or {}
        Nexus.Proc.PlayerTargets[nearest][selfID] = true
    end
    return nearest
end

function ENT:OnRemove()
    -- Clean up tracking on death/removal
    local selfID = self:EntIndex()
    for ply, t in pairs(Nexus.Proc.PlayerTargets or {}) do
        t[selfID] = nil
    end
end

function ENT:FaceTarget(target)
    if not target then return end
    local isTableBase = type(target) == "table" and target.IsBase
    if not isTableBase and not IsValid(target) then return end
    local dir = target:GetPos() - self:GetPos()
    self:SetAngles(dir:Angle())
end

function ENT:AttackPlayer(target)
    if not target then return end
    local isTableBase = type(target) == "table" and target.IsBase
    if not isTableBase and not IsValid(target) then return end
    
    local myPos = self:GetPos()
    local targetPos = target:GetPos()
    
    -- Generous active strike reach check (150 units) to allow lunges to connect
    if myPos:DistToSqr(targetPos) > (150 * 150) then return end

    -- Forward cone check (within ~100 degrees in front of the spider), skip for base walls
    if not isTableBase then
        local toTarget = targetPos - myPos
        toTarget.z = 0
        toTarget:Normalize()
        local facing = self:GetAngles():Forward()
        facing.z = 0
        facing:Normalize()

        if toTarget:Dot(facing) < 0.65 then return end
    end

    local pitch = math.Clamp(math.Round(100 / (self.genes and self.genes.scale or 1)), 75, 130)
    self:EmitSound("npc/headcrab/headbite.wav", 75, pitch)

    local dmgInfo = DamageInfo()
    dmgInfo:SetDamage(self.genes.damage)
    dmgInfo:SetAttacker(self)
    dmgInfo:SetInflictor(self)
    dmgInfo:SetDamageType(DMG_SLASH)
    target:TakeDamageInfo(dmgInfo)
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Register entity
-- ─────────────────────────────────────────────────────────────────────────────

-- ─────────────────────────────────────────────────────────────────────────────
-- Spider-on-Spider Collision Hook
-- ─────────────────────────────────────────────────────────────────────────────
hook.Add("ShouldCollide", "NexusSpiderNoCollideSpiders", function(ent1, ent2)
    if not IsValid(ent1) or not IsValid(ent2) then return end
    
    local class1 = ent1:GetClass()
    local class2 = ent2:GetClass()
    
    if (class1 == "nexus_spider" or class1 == "nexus_jumping_spider") and
       (class2 == "nexus_spider" or class2 == "nexus_jumping_spider") then
        return false
    end
end)
