include("shared.lua")

function ENT:Draw()
    local role = self:GetNWString("Role", "")
    if role == "" then return end

    local isSocketed = self:GetNWBool("IsSocketed", false)

    local roleData = Nexus.Proc:GetRoleData(role)
    local configModel = roleData and roleData.MachineModel or "models/props_lab/reciever01b.mdl"

    if (roleData.RequiresSocketedEquipment and isSocketed) or (not roleData.RequiresSocketedEquipment) then
        self:DrawModel()
    end

    if roleData.RequiresSocketedEquipment and not isSocketed then
        render.SetColorModulation(0, 0.5, 1)
        render.SetBlend(0.35)
            self:DrawModel()
        render.SetColorModulation(1, 1, 1)
        render.SetBlend(1.0)
    end

    local localPlayer = LocalPlayer()
    if not IsValid(localPlayer) then return end

    local selfPos = self:GetPos()
    if EyePos():DistToSqr(selfPos) > (1000 * 1000) then return end

    local pos = selfPos + (roleData.OverheadYPos or Vector(0, 0, 55))
    local ang = localPlayer:EyeAngles()
    ang:RotateAroundAxis(ang:Forward(), 90)
    ang:RotateAroundAxis(ang:Right(), 90)

    cam.Start3D2D(pos, ang, 0.12)
        local progress = self:GetNWFloat("Progress", 0)

        local titleText = string.upper(roleData.MachineTitle or role.." MACHINE")
        local percentText = string.format("%.1f%%", progress)

        local statusColor = progress >= 100 and Nexus:GetColor("green") or Nexus:GetColor("red")
        local statusText = roleData.RequiresSocketedEquipment and (isSocketed and (roleData.MachineActive or "REPAIRING") 
            or (roleData.MachineRequired or "ITEM MISSING")) 
            or "NEEDS REPAIR"

        statusText = ((roleData.RequiresSocketedEquipment and isSocketed) or (not roleData.RequiresSocketedEquipment)) 
            and statusText..": "..percentText.."" 
            or statusText

        statusText = progress >= 100 and "FIXED" or statusText
        statusText = string.upper(statusText)

        local titleFont = Nexus:GetFont({size = 28, bold=true, dontScale = true, font="Lato"})
        local descriptionFont = Nexus:GetFont({size = 20, dontScale = true, font="Lato"})

        surface.SetFont(titleFont)
        local w1, h1 = surface.GetTextSize(titleText)

        surface.SetFont(descriptionFont)
        local w2, h2 = surface.GetTextSize(statusText)

        local boxW = math.max(w1, w2, 220) + 40
        local boxH = h1 + h2 + 40

        Nexus.RNDX.Draw(6, -boxW / 2, -boxH / 2, boxW, boxH, Nexus:SetAlpha(Nexus:GetColor("background"), 175))
        
        surface.SetDrawColor(statusColor.r, statusColor.g, statusColor.b, 120)
        surface.DrawOutlinedRect(-boxW / 2, -boxH / 2, boxW, boxH, 2)

        draw.SimpleText(titleText, titleFont, 0, -boxH / 2 + 12, Nexus:GetTextColor(Nexus:GetColor("background")), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        draw.SimpleText(statusText, descriptionFont, 0, -boxH / 2 + 20 + h1, statusColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

        local barW, barH = boxW - 40, 10
        local barX, barY = -barW / 2, boxH / 2 - 18

        Nexus.RNDX.Draw(4, barX, barY, barW, barH, Nexus:GetColor("overlay"))

        local fillW = (math.min(progress, 100) / 100) * barW
        Nexus.RNDX.Draw(4, barX, barY, fillW, barH, statusColor)
    cam.End3D2D()

    if roleData.MachineEffects then
        roleData.MachineEffects(self, progress, roleData)
    end
end

function ENT:OnRemove()
    if self.Emitter then
        self.Emitter:Finish()
    end
end