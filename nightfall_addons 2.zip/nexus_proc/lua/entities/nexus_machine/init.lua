AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
    self:SetSolid(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_NONE)
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetCollisionGroup(COLLISION_GROUP_PASSABLE_DOOR)

    if self:GetNWString("Role", "") == "" then
        local role = Nexus.Proc.Roles[math.random(#Nexus.Proc.Roles)].Name
        self:SetNWString("Role", role)
        self.Role = role
    else
        self.Role = self:GetNWString("Role")
    end

    local roleData = Nexus.Proc:GetRoleData(self.Role)
    local model = roleData.MachineModel or "models/props_lab/reciever01b.mdl"
    self:SetModel(model)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:EnableMotion(false)
    end
end

util.AddNetworkString("NightFall:Researcher:AddBlip")
function ENT:Think()
    self:NextThink(CurTime() + 0.5)

    local roleData = Nexus.Proc:GetRoleData(self.Role)

    if roleData.SocketEnt and not self:GetNWBool("IsSocketed", false) then
        local find = ents.FindInSphere(self:GetPos(), 80)
        for _, ent in ipairs(find) do
            if not (IsValid(ent) and ent:GetClass() == roleData.SocketEnt) then continue end
            ent:Remove()

            self:SetNWBool("IsSocketed", true)
            self:EmitSound("physics/metal/metal_box_impact_bullet1.wav", 80, 100)
            self:EmitSound("ambient/machines/thumper_startup1.wav", 80, 100)

            break
        end

        return true
    end

    if self.Role == "Researcher" and self:GetNWFloat("Progress", 0) >= 100 then
        self:SetNWFloat("Progress", 0.0)

        local candidates = {}
        for _, ent in ipairs(ents.GetAll()) do
            if not (string.StartWith(ent:GetClass(), "nexus_follower") and ent:GetPos():Distance(Nexus.Proc.HomeBase) > 600) then continue end
            table.insert(candidates, ent)
        end

        if #candidates > 0 then
            local targetNPC = candidates[math.random(#candidates)]
            net.Start("NightFall:Researcher:AddBlip")
            net.WriteEntity(targetNPC)
            net.WriteVector(targetNPC:GetPos())
            net.Broadcast()

            for _, ply in ipairs(player.GetAll()) do
                ply:EmitSound("ambient/alarms/klaxon1.wav", 55, 120)
                Nexus:ChatMessage(ply, {roleData.Color, "[ "..roleData.Name.." ] ", "I have found a new survivor! I have added a blip on the minimap."})
            end
        end

        self:EmitSound("ambient/machines/steam_release_2.wav", 80, 100)

        return true
    end

    return true
end