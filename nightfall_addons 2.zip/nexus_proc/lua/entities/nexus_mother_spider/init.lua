AddCSLuaFile("shared.lua")
include("shared.lua")

local Spider = Nexus.Proc.Spider

local DETECT_RANGE_SQR = Spider.DETECT_RANGE * Spider.DETECT_RANGE
local CHASE_RANGE_SQR  = Spider.CHASE_RANGE * Spider.CHASE_RANGE
local CHASE_RANGE_LIMIT_SQR = (Spider.CHASE_RANGE + 200) * (Spider.CHASE_RANGE + 200)
local ATTACK_RANGE_SQR = (Spider.ATTACK_RANGE * 4.0) * (Spider.ATTACK_RANGE * 4.0)

function ENT:Initialize()
    for _, ply in ipairs(player.GetAll()) do
        Nexus:ChatMessage(ply, {color_white, "[ System ] ", "A mother spider has spawned."})        
    end

    baseclass.Get("base_nextbot").Initialize(self)

    local seed = (self:EntIndex() * 7919 + 3) % 4294967296
    self.genes = Spider.GenerateGenes(seed)

    self.genes.bodyRadius    = self.genes.bodyRadius    * 5.0
    self.genes.abdomenRadius = self.genes.abdomenRadius * 5.0
    self.genes.bodyHeight    = self.genes.bodyHeight    * 5.0
    self.genes.legLength1    = self.genes.legLength1    * 5.0
    self.genes.legLength2    = self.genes.legLength2    * 5.0
    self.genes.legLength3    = self.genes.legLength3    * 5.0
    self.genes.legSpread     = self.genes.legSpread     * 2.5

    local activePlayers = math.max(1, Nexus.Proc:GetPlayersParticipatingCount())

    local bossHP = 1000 + (activePlayers * 350)
    self:SetMaxHealth(bossHP)
    self:SetHealth(bossHP)

    self:SetModel("models/headcrabclassic.mdl")
    self:SetModelScale(1.0)
    self:SetRenderMode(RENDERMODE_TRANSALPHA)
    self:SetColor(Color(255, 255, 255, 0))
    self:DrawShadow(false)

    self:SetNWInt("SpiderSeed", seed)

    if self.loco then
        self.loco:SetDesiredSpeed(150)
        self.loco:SetAcceleration(350)
        self.loco:SetDeceleration(350)
        self.loco:SetStepHeight(18)
    end

    local boxW = self.genes.bodyRadius * 1.2
    local boxH = self.genes.bodyRadius * 2.0
    timer.Simple(0, function()
        if not IsValid(self) then return end
        self:SetSolid(SOLID_BBOX)
        self:SetCollisionGroup(COLLISION_GROUP_NPC)
        self:SetCollisionBounds(Vector(-boxW, -boxW, 0), Vector(boxW, boxW, boxH))
    end)

    self.nextSpawnTime = CurTime() + 5
end


local DETECT_RANGE_SQR_M = Spider.DETECT_RANGE * Spider.DETECT_RANGE
function ENT:FindClosestPlayer()
    local now = CurTime()
    if self.nextFindPlayerTime and now < self.nextFindPlayerTime and not self.cachedPlayerIsBase and IsValid(self.cachedPlayer) and self.cachedPlayer:Alive() then
        return self.cachedPlayer
    end
    self.nextFindPlayerTime = now + 0.5

    local myPos = self:GetPos()
    local nearest, nearDistSqr = nil, math.huge
    for _, ply in ipairs(player.GetAll()) do
        if not ply:Alive() or ply:Team() == TEAM_SPECTATOR then continue end

        local plyPos = ply:GetPos()
        local homeBase = Nexus.Proc.HomeBase
        local safeRadius = Nexus.Proc.BaseSafeRadius or 800
        local isPlayerInBase = homeBase and plyPos:DistToSqr(homeBase) < (safeRadius * safeRadius)
        local isSpiderInBase = homeBase and myPos:DistToSqr(homeBase) < (safeRadius * safeRadius)
        if isPlayerInBase and not isSpiderInBase then continue end

        local dSqr = myPos:DistToSqr(plyPos)
        if dSqr <= DETECT_RANGE_SQR_M and dSqr < nearDistSqr then
            nearest = ply
            nearDistSqr = dSqr
        end
    end

    if not nearest and Nexus.Proc.Base and Nexus.Proc.Base.GetClosestWallPoint then
        local wallPos, wallDistSqr, wallIdx = Nexus.Proc.Base:GetClosestWallPoint(myPos)
        if wallPos then
            local dists = Nexus.Proc.SpiderSpawnDistance or {1500, 1800}
            local maxSeeDist = dists[2] * 1.1
            if wallDistSqr <= (maxSeeDist * maxSeeDist) then
                self.cachedPlayerIsBase = true
                self.cachedPlayer = {
                    IsBase = true, WallPos = wallPos, WallIdx = wallIdx,
                    GetPos = function() return wallPos end,
                    Alive  = function() return (Nexus.Proc.Base:GetHP() > 0) end,
                    TakeDamageInfo = function(_, dmgInfo)
                        Nexus.Proc.Base:TakeDamage(dmgInfo:GetDamage(), self)
                    end
                }

                return self.cachedPlayer
            end
        end
    end

    self.cachedPlayerIsBase = false
    self.cachedPlayer = nearest
    return nearest
end

function ENT:FaceTarget(target)
    if not target then return end
    if type(target) ~= "table" and not IsValid(target) then return end

    local dir = target:GetPos() - self:GetPos()
    self:SetAngles(dir:Angle())
end

function ENT:OnTakeDamage(dmginfo)
    if self:GetNWBool("IsDead", false) then return end

    self:SetHealth(self:Health() - dmginfo:GetDamage())
    self:EmitSound("npc/antlion/pain" .. math.random(1, 2) .. ".wav", 85, 75)

    if self:Health() <= 0 then
        self:SetNWBool("IsDead", true)
        hook.Run("OnNPCKilled", self, dmginfo:GetAttacker(), dmginfo:GetInflictor())

        local numBabies = math.random(2, 3)
        for i = 1, numBabies do
            local angle = (i / numBabies) * math.pi * 2
            local offset = Vector(math.cos(angle) * 65, math.sin(angle) * 65, 15)
            local baby = ents.Create("nexus_spider")
            if IsValid(baby) then
                baby:SetPos(self:GetPos() + offset)
                baby:Spawn()
                baby:Activate()
            end
        end

        self:EmitSound("npc/barnacle/barnacle_die2.wav", 90, 75)
        self:EmitSound("physics/flesh/flesh_squishy_impact_hard" .. math.random(1, 4) .. ".wav", 85, 70)

        self:SetSolid(SOLID_NONE)
        self:SetCollisionGroup(COLLISION_GROUP_DEBRIS)

        if self.loco then self.loco:SetDesiredSpeed(0) end

        timer.Simple(5, function()
            if IsValid(self) then self:Remove() end
        end)
    end
end

function ENT:OnRemove() end

function ENT:AttackPlayer(target)
    if not IsValid(target) and type(target) ~= "table" then return end
    
    self:EmitSound("npc/barnacle/barnacle_scream1.wav", 80, 75)

    if target.IsBase then
        local dmgInfo = DamageInfo()
        dmgInfo:SetDamage(40)
        dmgInfo:SetAttacker(self)
        dmgInfo:SetInflictor(self)
        dmgInfo:SetDamageType(DMG_SLASH)
        target:TakeDamageInfo(dmgInfo)
        return
    end

    local dmgInfo = DamageInfo()
    dmgInfo:SetDamage(math.random(35, 50))
    dmgInfo:SetAttacker(self)
    dmgInfo:SetInflictor(self)
    dmgInfo:SetDamageType(DMG_SLASH)
    target:TakeDamageInfo(dmgInfo)
end

function ENT:RunBehaviour()
    coroutine.wait(0.5)

    while IsValid(self) do
        if self:GetNWBool("IsDead", false) then
            coroutine.wait(1.0)
            continue
        end

        local loco = self.loco
        if not loco then
            coroutine.wait(0.2)
            coroutine.wait(0.2)
            continue
        end

        local target = self:FindClosestPlayer()
        local isBase = type(target) == "table" and target.IsBase
        local isTargetValid = isBase or IsValid(target)
        if not isTargetValid then
            loco:SetDesiredSpeed(80)

            local dir = Vector(math.Rand(-1,1), math.Rand(-1,1), 0)
            if dir:LengthSqr() < 0.001 then dir = Vector(1,0,0) end
            dir:Normalize()

            local wander = self:GetPos() + dir * math.Rand(150, 400)
            local path = Path("Follow")
            path:SetMinLookAheadDistance(60)
            path:Compute(self, wander)

            local t0 = CurTime()
            while IsValid(self) and (CurTime() - t0) < 3.5 do
                path:Update(self)
                coroutine.wait(0.05)
            end

            coroutine.wait(math.Rand(0.5, 1.5))
            coroutine.wait(0.2)
            continue
        end

        local distSqr = self:GetPos():DistToSqr(target:GetPos())
        if CurTime() >= (self.nextSpawnTime or 0) then
            self.nextSpawnTime = CurTime() + 10
            
            local spawnPos = self:GetPos() - self:GetForward() * 100 + Vector(0, 0, 15)
            local baby = ents.Create("nexus_spider")
            if IsValid(baby) then
                baby:SetPos(spawnPos)
                baby:Spawn()
                baby:Activate()
                self:EmitSound("npc/barnacle/barnacle_die2.wav", 80, 130)
            end
        end

        if distSqr <= ATTACK_RANGE_SQR then
            self:FaceTarget(target)
            self:SetNWFloat("LastAttackTime", CurTime())
            
            local lungeEnd = CurTime() + 0.20
            while IsValid(self) and (isBase or IsValid(target)) and CurTime() < lungeEnd do
                local dir = target:GetPos() - self:GetPos()
                dir.z = 0
                dir:Normalize()

                if self.loco then
                    self.loco:SetVelocity(dir * 300 + Vector(0, 0, 80))
                end

                coroutine.wait(0.01)
            end
            
            if IsValid(self) and (isBase or IsValid(target)) then
                self:AttackPlayer(target)
            end

            coroutine.wait(1.5)
            coroutine.wait(0.2)
            continue
        end

        if distSqr <= CHASE_RANGE_SQR then
            loco:SetDesiredSpeed(160)

            local path = Path("Follow")
            path:SetMinLookAheadDistance(50)

            local nextComputeTime = 0
            local t0 = CurTime()
            while IsValid(self) and (isBase or IsValid(target)) and (CurTime() - t0) < 2 do
                local dSqr = self:GetPos():DistToSqr(target:GetPos())
                if dSqr <= ATTACK_RANGE_SQR or dSqr > CHASE_RANGE_LIMIT_SQR then break end
                
                local now = CurTime()
                if now >= nextComputeTime then
                    nextComputeTime = now + 0.4
                    path:Compute(self, target:GetPos())
                end
                
                path:Update(self)
                coroutine.wait(0.05)
            end

            coroutine.wait(0.2)
            continue
        end

        loco:SetDesiredSpeed(100)

        local path = Path("Follow")
        path:Compute(self, target:GetPos())

        local t0 = CurTime()
        while IsValid(self) and (isBase or IsValid(target)) and (CurTime() - t0) < 1.5 do
            path:Update(self)
            coroutine.wait(0.05)
        end

        coroutine.wait(0.2)
    end
end