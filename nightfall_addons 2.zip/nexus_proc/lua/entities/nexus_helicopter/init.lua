AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
    local heli = ents.Create("npc_helicopter")
    if not IsValid(heli) then return end

    local startPos = Nexus.Proc.ExtractionPosition["Start"]
    local endPos = Nexus.Proc.ExtractionPosition["End"]

    heli:SetPos(startPos)
    heli:SetAngles((endPos - startPos):Angle())

    self.HeliNPC = heli
    self:ParentToModules(heli)

    local trackName = "heli_target_node_"..heli:EntIndex()
    local track = ents.Create("path_track")
    if not IsValid(track) then
        self:Remove() 
        return
    end

    track:SetPos(endPos)
    track:SetName(trackName)
    track:Spawn()
    track:Activate()

    heli:DeleteOnRemove(track)

    heli:SetKeyValue("target", trackName)
    heli:Spawn()
    heli:Activate()

    heli:Fire("FlyToSpecificTrackNode", trackName, 0.1)
    heli:Fire("StartPatrol", "", 0.2)
end

function ENT:ParentToModules(heli)
    self:SetParent(heli)
    self:SetLocalPos(Vector(0,0,0))
    self:SetLocalAngles(Angle(0,0,0))

    for _, ply in ipairs(player.GetAll()) do
        heli:AddEntityRelationship(ply, D_NU, 99)
    end
end

function ENT:OnRemove()
    Nexus.Proc.IsExtractionActive = false
    SetGlobalFloat("NightFall:SetExtractionEndTime", 0)

    if IsValid(self.HeliNPC) then
        self.HeliNPC:Remove()
    end
end

hook.Add("EntityTakeDamage", "NightFall:HelicopterIndestructible", function(target, dmginfo)
    if not IsValid(target) or target:GetClass() != "npc_helicopter" then return end

    dmginfo:ScaleDamage(0)
    dmginfo:SetDamage(0)

    return true
end)

hook.Add("KeyPress", "NightFall:ExtractionUse", function(ply, key)
    if key != IN_USE then return end
    if ply.HasExtracted then return end
    if not ply:Alive() or ply:Team() == TEAM_SPECTATOR then return end

    local state = GetGlobalInt("NightFall:RoundState", ROUND_WAITING)
    if state ~= ROUND_ACTIVE then return end

    if not Nexus.Proc.IsExtractionActive then return end

    local lookingAt = ply:GetEyeTrace().Entity
    if not (IsValid(lookingAt) and lookingAt:GetClass() == "npc_helicopter") then return end

    // (350^2)
    local dist = ply:GetPos():DistToSqr(lookingAt:GetPos())
    if not (dist <= 122500) then return end

    ply.HasExtracted = true

    Nexus:ChatMessage(ply, {color_white, "[ System ] You have successfully ", Nexus:GetColor("green"), "extracted", color_white, "!"})

    for _, curPly in ipairs(player.GetAll()) do
        if curPly == ply then continue end
        Nexus:ChatMessage(curPly, {color_white, "[ System ] " .. ply:Nick() .. " has successfully ", Nexus:GetColor("green"), "extracted", color_white, "!"})
    end

    ply:StripWeapons()
    ply:SetTeam(TEAM_SPECTATOR)

    ply:Spectate(OBS_MODE_CHASE)
    ply:SpectateEntity(lookingAt)
end)

hook.Add("PlayerSpawn", "NightFall:HelicopterRelations", function(ply)
    for _, heli in ipairs(ents.FindByClass("npc_helicopter")) do
        if not IsValid(heli) then continue end
        heli:AddEntityRelationship(ply, D_NU, 99)
    end
end)