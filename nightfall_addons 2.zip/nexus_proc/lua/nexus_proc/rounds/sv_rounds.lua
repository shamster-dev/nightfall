util.AddNetworkString("NightFall:Rounds:CloseMenu")
util.AddNetworkString("NightFall:Rounds:SendStats")
util.AddNetworkString("Nexus:Rounds:RequestScoreboard")
util.AddNetworkString("Nexus:Rounds:SyncScoreboard")

function Nexus.Proc.Rounds:GetAlivePlayers()
    local alivePlayers = {}
    for _, ply in ipairs(player.GetAll()) do
        if not (ply:Alive() and ply:Team() ~= TEAM_SPECTATOR) then continue end
        table.insert(alivePlayers, ply)
    end

    return alivePlayers
end

local function getReadyPlayers()
    local readyPlayers = {}
    for _, ply in ipairs(player.GetAll()) do
        if not (ply.IsReady or ply:IsBot()) then continue end
        table.insert(readyPlayers, ply)
    end

    return readyPlayers
end

function Nexus.Proc:GetPlayersParticipatingCount()
    local activePlayers = 0
    for _, ply in ipairs(player.GetAll()) do
        if not (ply.IsRoundParticipant or ply:IsBot()) then continue end
        activePlayers = activePlayers + 1
    end

    return activePlayers
end

local function getActiveSpidersCount()
    local count = 0
    for spiderClass, _ in pairs(Nexus.Proc.Spiders) do
        count = count + #ents.FindByClass(spiderClass)
    end

    return count
end

local function cleanEntities()
    Nexus.Proc.IsExtractionActive = false
    SetGlobalFloat("NightFall:SetExtractionEndTime", 0)

    for _, entClass in ipairs(Nexus.Proc.CleanEntities) do
        for _, ent in ipairs(ents.FindByClass(entClass)) do
            if not IsValid(ent) then continue end
            ent:Remove()
        end
    end

    for _, roleData in ipairs(Nexus.Proc.Roles) do
        for _, ent in ipairs(ents.FindByClass(roleData.Class)) do
            if not IsValid(ent) then continue end
            ent:Remove()
        end
    end

    for _, ent in ipairs(ents.FindByClass("path_track")) do
        if not (IsValid(ent) and string.StartWith(ent:GetName(), "heli_target_node_")) then continue end
        ent:Remove()
    end

    for _, ent in ipairs(ents.FindByClass("prop_ragdoll")) do
        if not ent.NexusReviveTime then continue end
        ent:Remove()
    end
end

local function spawnSingleSpider(spawnPos)
    if not spawnPos then return end
    if Nexus.Proc.IsInNoSpawnZone and Nexus.Proc.IsInNoSpawnZone(spawnPos) then return end

    if Nexus.Proc.HomeBase and spawnPos:DistToSqr(Nexus.Proc.HomeBase) < (1500 * 1500) then
        local dir = (spawnPos - Nexus.Proc.HomeBase)
        dir.z = 0
        if dir:LengthSqr() > 0.001 then
            dir:Normalize()
            local dists = Nexus.Proc.SpiderSpawnDistance or {1500, 1800}
            local spawnDist = math.random(dists[1], dists[2])
            spawnPos = Nexus.Proc.HomeBase + dir * spawnDist
        end
    end
    if getActiveSpidersCount() >= Nexus.Proc.Base.GetMaxSpiders() then return end

    local tr = util.TraceLine({
        start = spawnPos + Vector(0, 0, 50),
        endpos = spawnPos - Vector(0, 0, 500),
        mask = MASK_SOLID_BRUSHONLY
    })

    local finalPos = tr.Hit and tr.HitPos + Vector(0, 0, 8) or spawnPos
    if Nexus.Proc.IsInNoSpawnZone and Nexus.Proc.IsInNoSpawnZone(finalPos) then return end

    -- Verify that the spawn space is not blocked by world solid geometry
    local checkHull = util.TraceHull({
        start = finalPos,
        endpos = finalPos + Vector(0, 0, 10),
        mins = Vector(-12, -12, 0),
        maxs = Vector(12, 12, 24),
        mask = MASK_SOLID_BRUSHONLY
    })
    if checkHull.Hit and not checkHull.StartSolid then return end

    // Is a boss allowed
    local endTime = GetGlobalFloat("NightFall:Round:EndCurTime", 0)
    local timeLeft = math.max(0, endTime - CurTime())
    local progress = 1.0 - (timeLeft / 480)
    local bossAllowed = progress > 0.4

    // Select a spider to spawn
    local pool = {}
    local totalWeight = 0
    for spiderClass, percentage in pairs(Nexus.Proc.Spiders) do
        if not bossAllowed and Nexus.Proc.SpiderBosses[spiderClass] then continue end
        table.insert(pool, { class = spiderClass, weight = percentage })
        totalWeight = totalWeight + percentage
    end

    local class
    if totalWeight > 0 then
        local roll = math.random() * totalWeight
        local curWeight = 0
        for _, item in ipairs(pool) do
            curWeight = curWeight + item.weight
            if roll <= curWeight then
                class = item.class
                break
            end
        end
    end

    local spider = ents.Create(class)
    if not IsValid(spider) then return end
    spider:SetPos(finalPos)
    spider:Spawn()
    spider:Activate()
end

util.AddNetworkString("NightFall:Rounds:OpenMenu")
util.AddNetworkString("NightFall:Base:SetMaxHP")
function Nexus.Proc.Rounds.SetState(state)
    local duration = Nexus.Proc.RoundInformation[state].Duration

    local previousState = GetGlobalInt("NightFall:RoundState", ROUND_WAITING)
    SetGlobalInt("NightFall:RoundState", state)
    SetGlobalFloat("NightFall:Round:EndCurTime", CurTime() + duration)

    if state == ROUND_PREP then
        cleanEntities()
        timer.Remove("NightFall:SpawnSpiders")
        spawnMachines()

        for _, ply in ipairs(player.GetAll()) do
            if not IsValid(ply) then continue end

            ply.HasExtracted = nil
            ply.IsRoundParticipant = nil
            ply.StatNPCsFollowed = 0
            ply.StatSpidersKilled = 0
            ply.StatDamageDealt = 0
            ply.StatDistanceTravelled = 0
            ply.StatRevivedCount = 0
            ply.StatDownedCount = 0
            ply.StatFollowedThisRound = nil
            ply.StatLastPos = nil

            Nexus.Proc.InitPlayerInventory(ply)
        end

        Nexus.Proc.Base.MaxHP = Nexus.Proc.Base.DefaultHealth
        SetGlobalInt("NightFall:BaseMaxHP", Nexus.Proc.Base.MaxHP)
        Nexus.Proc.Base:SetHP(Nexus.Proc.Base.DefaultHealth)

        if previousState ~= ROUND_WAITING then
            for _, ply in ipairs(player.GetAll()) do
                if not IsValid(ply) then continue end
                if ply:IsBot() then
                    ply:UnSpectate()
                    ply:SetTeam(TEAM_UNASSIGNED)

                    ply.NexusAllowSpawn = true
                    ply:Spawn()
                    ply.NexusAllowSpawn = nil

                    continue
                end

                ply.IsReady = nil
                ply:StripWeapons()

                if ply:Alive() then
                    ply:KillSilent()
                end

                ply:Spectate(OBS_MODE_ROAMING)
                ply:SetTeam(TEAM_SPECTATOR)

                timer.Simple(0, function()
                    if not IsValid(ply) then return end
                    ply:SetPos(Nexus.Proc.VoidPosition)
                end)

                net.Start("NightFall:Rounds:OpenMenu")
                net.Send(ply)
            end

            return
        end

        // Transitioning from ROUND_WAITING to ROUND_PREP
        // Keep ready players who are ready and do not reopen their menu.
        // Keep the menu open for players who haven't pressed Play yet
        for _, ply in ipairs(player.GetAll()) do
            if not IsValid(ply) then continue end
            if not (ply.IsReady or ply:IsBot()) then
                ply:StripWeapons()
                ply:Spectate(OBS_MODE_ROAMING)
                ply:SetTeam(TEAM_SPECTATOR)

                timer.Simple(0, function()
                    if not IsValid(ply) then return end
                    ply:SetPos(Nexus.Proc.VoidPosition)
                end)

                net.Start("NightFall:Rounds:OpenMenu")
                net.Send(ply)

                continue
            end

            if not ply:Alive() or ply:Team() == TEAM_SPECTATOR then
                ply:UnSpectate()
                ply:SetTeam(TEAM_UNASSIGNED)

                ply.NexusAllowSpawn = true
                ply:Spawn()
                ply.NexusAllowSpawn = nil
            end
        end

        return
    end

    if state == ROUND_ACTIVE then
        // Spawn all the players who are ready
        for _, ply in ipairs(player.GetAll()) do
            if not IsValid(ply) then continue end
            if not (ply.IsReady or ply:IsBot()) then continue end
            ply.IsRoundParticipant = true

            ply:UnSpectate()
            ply:SetTeam(TEAM_UNASSIGNED)

            ply.NexusAllowSpawn = true
            ply:Spawn()
            ply.NexusAllowSpawn = nil

            net.Start("NightFall:Rounds:CloseMenu")
            net.Send(ply)
        end

        // Scale base HP based on player count
        local activePlayers = math.max(1, Nexus.Proc:GetPlayersParticipatingCount())
        Nexus.Proc.Base.MaxHP = Nexus.Proc.Base.DefaultHealth + ((activePlayers - 1) * Nexus.Proc.Base.AddPerPlayer)
        SetGlobalInt("NightFall:BaseMaxHP", Nexus.Proc.Base.MaxHP)
        Nexus.Proc.Base:SetHP(Nexus.Proc.Base.MaxHP)

        // Spawn the spider egg entities
        local points = table.Copy(Nexus.Proc.EggSpawns or {})
        if #points > 0 then
            // Shuffle egg spawns
            for i = #points, 2, -1 do
                local j = math.random(i)
                points[i], points[j] = points[j], points[i]
            end

            local maxEggs = Nexus.Proc.Base.EggsPerPlayer * math.max(1, Nexus.Proc:GetPlayersParticipatingCount())
            for i = 1, maxEggs do
                local pos = points[i]
                local egg = ents.Create("nexus_spider_egg")

                if not IsValid(egg) then continue end
                egg:SetPos(pos + Vector(0, 0, 10))
                egg:SetAngles(Angle(-90, math.random(0, 360), 0))
                egg:Spawn()
                egg:Activate()
            end
        end

        spawnNPCsAtPoints()

        timer.Create("NightFall:SpawnSpiders", Nexus.Proc.SpiderSpawnTimer, 0, function()
            local state = GetGlobalInt("NightFall:RoundState", 0)
            if state ~= ROUND_ACTIVE then return end

            local players = Nexus.Proc.Rounds:GetAlivePlayers()
            local activePlayerCount = #players
            if activePlayerCount == 0 then return end

            // 1. Spawn spiders at random players
            local numPlayerSpawns = activePlayerCount*math.random(1, 3)
            for i = 1, numPlayerSpawns do
                local ply = players[math.random(#players)]
                local candidatePos
                local attempts = 0
                repeat
                    attempts = attempts + 1
                    local angle = math.Rand(0, 360)
                    local dist = math.Rand(250, 750)
                    local offset = Vector(math.cos(math.rad(angle)) * dist, math.sin(math.rad(angle)) * dist, 120)
                    candidatePos = ply:GetPos() + offset
                until not (Nexus.Proc.IsInNoSpawnZone and Nexus.Proc.IsInNoSpawnZone(candidatePos)) or attempts >= 10

                spawnSingleSpider(candidatePos)
            end

            // 2. Spawn spiders outside the base
            local numBaseSpawns = math.max(1, math.floor(activePlayerCount * 0.5 + 0.5))
            for i = 1, numBaseSpawns do
                local candidatePos
                local attempts = 0
                repeat
                    attempts = attempts + 1
                    // Pick a random base wall
                    local wall = Nexus.Proc.Base.Walls[math.random(#Nexus.Proc.Base.Walls)]
                    local lerpVal = math.random()
                    local wallPoint = wall.startPos + (wall.endPos - wall.startPos) * lerpVal

                    // Offset outwards from base center to spawn on the correct side of the wall
                    local baseCenter = Nexus.Proc.HomeBase
                    local dir = (wallPoint - baseCenter)
                    dir.z = 0
                    dir:Normalize()

                    // Spawn at a randomized distance outside the wall
                    local spawnDist = math.Rand(Nexus.Proc.SpiderSpawnDistance[1], Nexus.Proc.SpiderSpawnDistance[2])
                    candidatePos = wallPoint + dir * spawnDist + Vector(0, 0, 15)
                until not (Nexus.Proc.IsInNoSpawnZone and Nexus.Proc.IsInNoSpawnZone(candidatePos)) or attempts >= 10

                spawnSingleSpider(candidatePos)
            end
        end)

        return
    end

    if state == ROUND_VICTORY or state == ROUND_DEFEAT then
        timer.Remove("NightFall:SpawnSpiders")
        cleanEntities()

        for _, ply in ipairs(player.GetAll()) do
            ply:StopSound("ambient/alarms/siren.wav")
        end

        // Check if any player successfully extracted
        local teamWon = (state == ROUND_VICTORY)
        if not teamWon then
            for _, p in ipairs(player.GetAll()) do
                if not p.HasExtracted then continue end

                teamWon = true
                break
            end
        end

        for _, ply in ipairs(player.GetAll()) do
            if not IsValid(ply) then continue end

            local won = ply.IsRoundParticipant and ply.HasExtracted or teamWon
            if ply.IsRoundParticipant and ply.StatsAggregated then
                local stats = ply.StatsAggregated
                stats.plays = stats.plays + 1
                stats.wins = won and stats.wins + 1 or stats.wins
                if won then
                    stats.perkPoints = (stats.perkPoints or 0) + 1
                    ply:ChatPrint("[Perks] You won the round and earned 1 Perk Point!")
                end

                stats.spiders = stats.spiders + (ply.StatSpidersKilled or 0)
                stats.dmg = stats.dmg + (ply.StatDamageDealt or 0)
                stats.npcs = stats.npcs + (ply.StatNPCsFollowed or 0)
                stats.dist = stats.dist + (ply.StatDistanceTravelled or 0)
                stats.revived = stats.revived + (ply.StatRevivedCount or 0)
                stats.downed = stats.downed + (ply.StatDownedCount or 0)

                -- Coin accumulation & Victory Bonus
                local baseCoinsEarned = ply.StatCoinsEarned or 0
                local finalCoins = baseCoinsEarned
                if won then
                    local bonusMultiplier = Nexus.Proc.CoinSettings and Nexus.Proc.CoinSettings.VictoryBonus or 0.20
                    local bonus = math.Round(baseCoinsEarned * bonusMultiplier)
                    finalCoins = baseCoinsEarned + bonus
                    ply:ChatPrint("[NightFall] Victory! You earned a +20% coin bonus ($" .. bonus .. " extra)!")
                end
                stats.coins = (stats.coins or 0) + finalCoins
                ply:ChatPrint("[NightFall] Round Finished! Total Coins Earned: $" .. finalCoins .. ". Your Total: $" .. stats.coins)
                ply.StatCoinsEarned = 0 -- Reset for next round

                Nexus.Proc.SavePlayerStats(ply)
            end

            // Reward the player
            local unlockedItems = {}
            if ply.IsRoundParticipant then
                local lockableWeapons = {}
                for _, weapon in ipairs(Nexus.Proc.Weapons.List or {}) do
                    if weapon.defaultUnlocked or Nexus.Proc.Weapons:IsWeaponUnlocked(ply, weapon.class) then continue end
                    table.insert(lockableWeapons, weapon.class)
                end

                local lockableAttachments = {}
                if ARC9 and ARC9.Attachments then
                    for att, _ in pairs(ARC9.Attachments) do
                        local defaultAtts = Nexus.Proc.Weapons.DefaultAttachments
                        if (defaultAtts and defaultAtts[att]) or Nexus.Proc.Weapons:IsAttachmentUnlocked(ply, att) then continue end
                        table.insert(lockableAttachments, att)
                    end
                end

                // Determine reward
                if won then
                    // Victory: 50% chance for weapon, 50% chance for attachments
                    local rewardType = (math.random(1, 2) == 1) and "weapon" or "attachment"
                    if rewardType == "weapon" and #lockableWeapons > 0 then
                        local chosen = table.remove(lockableWeapons, math.random(1, #lockableWeapons))
                        table.insert(unlockedItems, { type = "weapon", class = chosen })
                    elseif rewardType == "attachment" and #lockableAttachments > 0 then
                        for i = 1, math.min(2, #lockableAttachments) do
                            local chosen = table.remove(lockableAttachments, math.random(1, #lockableAttachments))
                            table.insert(unlockedItems, { type = "attachment", class = chosen })
                        end
                    elseif #lockableAttachments > 0 then // Fallback to attachments
                        for i = 1, math.min(2, #lockableAttachments) do
                            local chosen = table.remove(lockableAttachments, math.random(1, #lockableAttachments))
                            table.insert(unlockedItems, { type = "attachment", class = chosen })
                        end
                    elseif #lockableWeapons > 0 then // Fallback to weapon
                        local chosen = table.remove(lockableWeapons, math.random(1, #lockableWeapons))
                        table.insert(unlockedItems, { type = "weapon", class = chosen })
                    end
                else
                    // Defeat: 1 random attachment
                    if #lockableAttachments > 0 then
                        local chosen = table.remove(lockableAttachments, math.random(1, #lockableAttachments))
                        table.insert(unlockedItems, { type = "attachment", class = chosen })
                    elseif #lockableWeapons > 0 then // Fallback to weapon
                        local chosen = table.remove(lockableWeapons, math.random(1, #lockableWeapons))
                        table.insert(unlockedItems, { type = "weapon", class = chosen })
                    end
                end

                // Perform the actual unlocking
                for _, item in ipairs(unlockedItems) do
                    if item.type == "weapon" then
                        Nexus.Proc.Weapons:UnlockWeapon(ply, item.class)
                    elseif item.type == "attachment" then
                        Nexus.Proc.Weapons:UnlockAttachment(ply, item.class)
                    end
                end
            end

            net.Start("NightFall:Rounds:SendStats")
            net.WriteBool(won)
            net.WriteBool(ply.IsRoundParticipant == true)
            net.WriteBool(teamWon)
            net.WriteInt(ply.StatNPCsFollowed or 0, 32)
            net.WriteInt(ply.StatSpidersKilled or 0, 32)
            net.WriteInt(ply.StatDamageDealt or 0, 32)
            net.WriteInt(ply.StatDistanceTravelled or 0, 32)
            net.WriteInt(ply.StatRevivedCount or 0, 32)
            net.WriteInt(ply.StatDownedCount or 0, 32)
            net.WriteUInt(#unlockedItems, 8)
            for _, item in ipairs(unlockedItems) do
                net.WriteString(item.type)
                net.WriteString(item.class)
            end
            net.Send(ply)
        end

        return
    end
end

hook.Add("Initialize", "NightFall:RoundInitialize", function()
    Nexus.Proc.Rounds.SetState(ROUND_WAITING)

    -- Load custom egg spawn points if they exist
    local filePath = "nexus_proc/egg_spawns_" .. game.GetMap() .. ".json"
    if file.Exists(filePath, "DATA") then
        local data = file.Read(filePath, "DATA")
        Nexus.Proc.EggSpawns = util.JSONToTable(data) or {}
    end

    -- Load custom NPC spawn points if they exist
    local npcFilePath = "nexus_proc/npc_spawns_" .. game.GetMap() .. ".json"
    if file.Exists(npcFilePath, "DATA") then
        local data = file.Read(npcFilePath, "DATA")
        local raw = util.JSONToTable(data) or {}
        Nexus.Proc.NpcSpawns = {}
        for _, v in ipairs(raw) do
            if v.pos and v.role then
                table.insert(Nexus.Proc.NpcSpawns, {
                    pos = Vector(v.pos[1], v.pos[2], v.pos[3]),
                    role = v.role
                })
            end
        end
    end

    -- Load custom item spawn points if they exist
    local itemFilePath = "nexus_proc/item_spawns_" .. game.GetMap() .. ".json"
    if file.Exists(itemFilePath, "DATA") then
        local data = file.Read(itemFilePath, "DATA")
        local raw = util.JSONToTable(data) or {}
        Nexus.Proc.ItemSpawns = {}
        for _, v in ipairs(raw) do
            if v.pos then
                table.insert(Nexus.Proc.ItemSpawns, {
                    pos = Vector(v.pos[1], v.pos[2], v.pos[3])
                })
            end
        end
    end
end)

if not Nexus.Proc.EggSpawns or #Nexus.Proc.EggSpawns == 0 then
    local filePath = "nexus_proc/egg_spawns_" .. game.GetMap() .. ".json"
    if file.Exists(filePath, "DATA") then
        local data = file.Read(filePath, "DATA")
        Nexus.Proc.EggSpawns = util.JSONToTable(data) or {}
    end
end

if not Nexus.Proc.NpcSpawns or #Nexus.Proc.NpcSpawns == 0 then
    local npcFilePath = "nexus_proc/npc_spawns_" .. game.GetMap() .. ".json"
    if file.Exists(npcFilePath, "DATA") then
        local data = file.Read(npcFilePath, "DATA")
        local raw = util.JSONToTable(data) or {}
        Nexus.Proc.NpcSpawns = {}
        for _, v in ipairs(raw) do
            if v.pos and v.role then
                table.insert(Nexus.Proc.NpcSpawns, {
                    pos = Vector(v.pos[1], v.pos[2], v.pos[3]),
                    role = v.role
                })
            end
        end
    end
end

if not Nexus.Proc.ItemSpawns or #Nexus.Proc.ItemSpawns == 0 then
    local itemFilePath = "nexus_proc/item_spawns_" .. game.GetMap() .. ".json"
    if file.Exists(itemFilePath, "DATA") then
        local data = file.Read(itemFilePath, "DATA")
        local raw = util.JSONToTable(data) or {}
        Nexus.Proc.ItemSpawns = {}
        for _, v in ipairs(raw) do
            if v.pos then
                table.insert(Nexus.Proc.ItemSpawns, {
                    pos = Vector(v.pos[1], v.pos[2], v.pos[3])
                })
            end
        end
    end
end

hook.Add("Tick", "NexusProcRoundTick", function()
    -- Only run logic checks periodically (every 0.25 seconds) to save CPU
    local now = CurTime()
    Nexus.Proc.Rounds.NextTick = Nexus.Proc.Rounds.NextTick or 0
    if now < Nexus.Proc.Rounds.NextTick then return end
    Nexus.Proc.Rounds.NextTick = now + 0.25

    local state = GetGlobalInt("NightFall:RoundState", ROUND_WAITING)
    local timeEnd = GetGlobalFloat("NightFall:Round:EndCurTime", 0)

    -- If there are no ready players on the server, reset to waiting immediately
    if state ~= ROUND_WAITING then
        local readyHumanCount = 0
        local humanCount = 0
        for _, p in ipairs(player.GetAll()) do
            humanCount = humanCount + 1
            if p.IsReady or p:IsBot() then
                readyHumanCount = readyHumanCount + 1
            end
        end

        -- If there are players but none of them are ready, reset
        if (humanCount > 0 and readyHumanCount == 0) or (#player.GetAll() == 0) then
            Nexus.Proc.Rounds.SetState(ROUND_WAITING, 0)
            return
        end
    end

    if state == ROUND_WAITING then
        -- Wait for players to click Play (classing bots as ready automatically)
        local hasReadyPlayer = false
        for _, p in ipairs(player.GetAll()) do
            if p.IsReady or p:IsBot() then
                hasReadyPlayer = true
                break
            end
        end

        if hasReadyPlayer then
            Nexus.Proc.Rounds.SetState(ROUND_PREP, PREP_DURATION)
        end

    elseif state == ROUND_PREP then
        if now >= timeEnd then
            -- Transition to active round
            Nexus.Proc.Rounds.SetState(ROUND_ACTIVE, ROUND_DURATION)
        end

    elseif state == ROUND_ACTIVE then
        local players = Nexus.Proc.Rounds:GetAlivePlayers()
        
        local activeHumans = {}
        for _, ply in ipairs(player.GetAll()) do
            if ply:Team() ~= TEAM_SPECTATOR or ply.IsReady or ply:IsBot() then
                if ply:Alive() or IsValid(ply.NexusRagdoll) then
                    table.insert(activeHumans, ply)
                end
            end
        end

        if #players == 0 or #activeHumans == 0 then
            -- Everyone died or last active player died/left, defeat
            Nexus.Proc.Rounds.SetState(ROUND_DEFEAT, FADE_DURATION)
        else
            -- Check if extraction triggers are met
            local isExtActive = Nexus.Proc.IsExtractionActive
            if not isExtActive then
                -- Check if survive timer expired
                if now >= timeEnd then
                    for _, p in ipairs(player.GetAll()) do
                        p:ChatPrint("[System] Time is up! You failed to extract! Defeat!")
                    end
                    Nexus.Proc.Rounds.SetState(ROUND_DEFEAT, FADE_DURATION)
                    return
                end

                -- 1. Check if all machines (excluding Researcher) are 100% complete
                local allCompleted = true
                local machinesFound = false
                for _, ent in ipairs(ents.FindByClass("nexus_machine")) do
                    local role = ent:GetNWString("Role", "")
                    if role ~= "Researcher" then
                        machinesFound = true
                        if ent:GetNWFloat("Progress", 0) < 100 then
                            allCompleted = false
                            break
                        end
                    end
                end

                -- 2. Check if Pilot follower NPC has reached home base (within 500 units of 5579.847656 1473.045044 -83.774300)
                local pilotAtBase = false
                local homeBase = Vector(5579.847656, 1473.045044, -83.774300)
                for _, ent in ipairs(ents.FindByClass("nexus_follower_pilot")) do
                    if IsValid(ent) and ent:GetPos():Distance(homeBase) <= 500 then
                        pilotAtBase = true
                        break
                    end
                end

                if machinesFound and allCompleted and pilotAtBase then
                    -- Trigger extraction phase!
                    Nexus.Proc.IsExtractionActive = true
                    SetGlobalFloat("NightFall:SetExtractionEndTime", CurTime() + 60)

                    -- Broadcast alert to everyone
                    for _, p in ipairs(player.GetAll()) do
                        p:EmitSound("ambient/alarms/siren.wav", 55, 100, 0.05)
                        p:ChatPrint("[System] ALL MACHINES OPERATIONAL & PILOT AT BASE! EXTRACTION HELICOPTER APPROACHING!")
                        p:ChatPrint("[System] Get to the extraction helicopter at home base within 60 seconds!")
                    end

                    -- Spawn extraction helicopter wrapper entity at starting position
                    local chopper = ents.Create("nexus_helicopter")
                    if IsValid(chopper) then
                        chopper:SetPos(Vector(8382.583984, 10023.673828, 2256.562012))
                        chopper:Spawn()
                        chopper:Activate()
                    end
                end
            else
                for _, heli in ipairs(ents.FindByClass("npc_helicopter")) do
                    for _, roleData in ipairs(Nexus.Proc.Roles) do
                        for _, npc in ipairs(ents.FindByClass(roleData.Class)) do
                            if IsValid(npc) and npc:GetPos():DistToSqr(heli:GetPos()) <= 122500 then
                                npc:Remove()
                            end
                        end
                    end
                end

                -- Extraction active timer check
                local extEnd = GetGlobalFloat("NightFall:SetExtractionEndTime", 0)
                if now >= extEnd then
                    -- Extraction time expired, defeat!
                    for _, p in ipairs(player.GetAll()) do
                        p:ChatPrint("[System] Extraction helicopter departed without you! Defeat!")
                    end
                    Nexus.Proc.Rounds.SetState(ROUND_DEFEAT, FADE_DURATION)
                end
            end
        end

    elseif state == ROUND_VICTORY or state == ROUND_DEFEAT then
        if now >= timeEnd then
            -- Transition back to preparation for next round
            if #getReadyPlayers() > 0 then
                Nexus.Proc.Rounds.SetState(ROUND_PREP, PREP_DURATION)
            else
                Nexus.Proc.Rounds.SetState(ROUND_WAITING, 0)
            end
        end
    end
end)