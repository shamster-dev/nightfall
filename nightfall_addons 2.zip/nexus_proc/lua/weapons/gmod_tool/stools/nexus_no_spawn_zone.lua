TOOL.Category = "Nexus"
TOOL.Name = "Nexus No Spawn Zone"
TOOL.Command = nil
TOOL.ConfigName = ""

-- Set up networking strings
if SERVER then
    util.AddNetworkString("Nexus:NoSpawnZones:Sync")
end

-- Initialize the shared global table
Nexus.Proc = Nexus.Proc or {}
Nexus.Proc.NoSpawnZones = Nexus.Proc.NoSpawnZones or {}

-- Helper function to check if a position is inside any No-Spawn Zone
function Nexus.Proc.IsInNoSpawnZone(pos)
    if not pos then return false end
    local zones = Nexus.Proc.NoSpawnZones
    if not zones or #zones == 0 then return false end

    for _, zone in ipairs(zones) do
        if zone.min and zone.max then
            local minVec = isvector(zone.min) and zone.min or Vector(zone.min[1] or zone.min.x or 0, zone.min[2] or zone.min.y or 0, zone.min[3] or zone.min.z or 0)
            local maxVec = isvector(zone.max) and zone.max or Vector(zone.max[1] or zone.max.x or 0, zone.max[2] or zone.max.y or 0, zone.max[3] or zone.max.z or 0)

            if pos.x >= minVec.x and pos.x <= maxVec.x and
               pos.y >= minVec.y and pos.y <= maxVec.y and
               pos.z >= minVec.z and pos.z <= maxVec.z then
                return true
            end
        end
    end
    return false
end

-- File paths for saving spawn zones
local DATA_DIR = "nexus_proc"
local FILE_PATH = DATA_DIR .. "/no_spawn_zones_" .. game.GetMap() .. ".json"

-- Server-side loading and saving
if SERVER then
    function Nexus.Proc.SaveNoSpawnZones()
        if not file.Exists(DATA_DIR, "DATA") then
            file.CreateDir(DATA_DIR)
        end
        local saveData = {}
        for _, zone in ipairs(Nexus.Proc.NoSpawnZones) do
            table.insert(saveData, {
                min = { zone.min.x, zone.min.y, zone.min.z },
                max = { zone.max.x, zone.max.y, zone.max.z }
            })
        end
        file.Write(FILE_PATH, util.TableToJSON(saveData))
    end

    function Nexus.Proc.LoadNoSpawnZones()
        if file.Exists(FILE_PATH, "DATA") then
            local data = file.Read(FILE_PATH, "DATA")
            local raw = util.JSONToTable(data) or {}
            Nexus.Proc.NoSpawnZones = {}
            for _, v in ipairs(raw) do
                if v.min and v.max then
                    table.insert(Nexus.Proc.NoSpawnZones, {
                        min = Vector(v.min[1], v.min[2], v.min[3]),
                        max = Vector(v.max[1], v.max[2], v.max[3])
                    })
                end
            end
        else
            Nexus.Proc.NoSpawnZones = {}
        end
    end

    -- Initial load
    hook.Add("Initialize", "NexusProcLoadNoSpawnZones", function()
        Nexus.Proc.LoadNoSpawnZones()
    end)
    -- Fallback load if initialized late
    Nexus.Proc.LoadNoSpawnZones()

    -- Sync to players when they load in
    hook.Add("PlayerInitialSpawn", "NexusProcSyncNoSpawnZones", function(ply)
        timer.Simple(2, function()
            if IsValid(ply) then
                net.Start("Nexus:NoSpawnZones:Sync")
                net.WriteTable(Nexus.Proc.NoSpawnZones)
                net.Send(ply)
            end
        end)
    end)
end

-- Network receiver to sync zones client-side
if CLIENT then
    net.Receive("Nexus:NoSpawnZones:Sync", function()
        Nexus.Proc.NoSpawnZones = net.ReadTable() or {}
    end)
end

-- Left click: Set Corner A (stage 0 -> 1) or Corner B (stage 1 -> 0, creating box)
function TOOL:LeftClick(trace)
    if not trace.HitPos then return false end
    if CLIENT then return true end

    local ply = self:GetOwner()
    local pos = trace.HitPos

    if self:GetStage() == 0 then
        -- Set Corner A
        if IsValid(self:GetWeapon()) then
            self:GetWeapon():SetNWVector("NexusCornerA", pos)
        end
        self:SetStage(1)
        if IsValid(ply) then
            ply:ChatPrint("[Nexus] Corner A set! Left-click another position to set Corner B and create the No-Spawn Zone.")
        end
    else
        -- Set Corner B and create box
        local cornerA = IsValid(self:GetWeapon()) and self:GetWeapon():GetNWVector("NexusCornerA", pos) or pos
        local cornerB = pos

        local minPos = Vector(
            math.min(cornerA.x, cornerB.x),
            math.min(cornerA.y, cornerB.y),
            math.min(cornerA.z, cornerB.z)
        )
        local maxPos = Vector(
            math.max(cornerA.x, cornerB.x),
            math.max(cornerA.y, cornerB.y),
            math.max(cornerA.z, cornerB.z)
        )

        -- If height difference is small (e.g. floor traces), give it a reasonable height volume (e.g. 150 units high)
        if maxPos.z - minPos.z < 32 then
            minPos.z = minPos.z - 16
            maxPos.z = maxPos.z + 150
        end

        table.insert(Nexus.Proc.NoSpawnZones, {
            min = minPos,
            max = maxPos
        })

        Nexus.Proc.SaveNoSpawnZones()

        -- Sync to all clients
        net.Start("Nexus:NoSpawnZones:Sync")
        net.WriteTable(Nexus.Proc.NoSpawnZones)
        net.Broadcast()

        self:SetStage(0)
        if IsValid(ply) then
            ply:ChatPrint("[Nexus] No-Spawn Zone created! Spiders will avoid spawning inside this box.")
        end
    end

    return true
end

-- Right click: Cancel Corner A placement or remove nearest zone
function TOOL:RightClick(trace)
    if CLIENT then return true end

    local ply = self:GetOwner()

    -- If in middle of placing box, cancel Corner A
    if self:GetStage() == 1 then
        self:SetStage(0)
        if IsValid(ply) then
            ply:ChatPrint("[Nexus] Corner A selection cancelled.")
        end
        return true
    end

    -- Otherwise remove nearest zone facing trace
    if not trace.HitPos then return false end
    local pos = trace.HitPos
    local zones = Nexus.Proc.NoSpawnZones

    if #zones == 0 then
        if IsValid(ply) then ply:ChatPrint("[Nexus] No active No-Spawn Zones to remove.") end
        return false
    end

    local nearestIndex = nil
    local nearestDist = 9999999

    for i, zone in ipairs(zones) do
        local center = (zone.min + zone.max) * 0.5
        local dist = pos:Distance(center)
        if dist < nearestDist then
            nearestDist = dist
            nearestIndex = i
        end
    end

    if nearestIndex and nearestDist < 1000 then
        table.remove(Nexus.Proc.NoSpawnZones, nearestIndex)
        Nexus.Proc.SaveNoSpawnZones()

        net.Start("Nexus:NoSpawnZones:Sync")
        net.WriteTable(Nexus.Proc.NoSpawnZones)
        net.Broadcast()

        if IsValid(ply) then
            ply:ChatPrint("[Nexus] Removed nearest No-Spawn Zone.")
        end
        return true
    else
        if IsValid(ply) then
            ply:ChatPrint("[Nexus] No No-Spawn Zone found near your trace point.")
        end
        return false
    end
end

-- Reload: Clear all zones
function TOOL:Reload(trace)
    if CLIENT then return true end

    local ply = self:GetOwner()
    if #Nexus.Proc.NoSpawnZones == 0 then
        if IsValid(ply) then ply:ChatPrint("[Nexus] No active No-Spawn Zones to clear.") end
        return false
    end

    Nexus.Proc.NoSpawnZones = {}
    Nexus.Proc.SaveNoSpawnZones()

    net.Start("Nexus:NoSpawnZones:Sync")
    net.WriteTable(Nexus.Proc.NoSpawnZones)
    net.Broadcast()

    self:SetStage(0)
    if IsValid(ply) then
        ply:ChatPrint("[Nexus] Cleared all No-Spawn Zones for this map!")
    end

    return true
end

-- Control Panel UI
function TOOL.BuildCPanel(panel)
    panel:AddControl("Header", {
        Text = "#tool.nexus_no_spawn_zone.name",
        Description = "#tool.nexus_no_spawn_zone.desc"
    })
    panel:AddControl("Label", {
        Text = "Controls:\n• Left Click: Set Corner A / Corner B to form 3D zone\n• Right Click: Cancel selection / Remove nearest zone\n• Reload: Clear all zones"
    })
end

-- Client-side 3D Visualization
if CLIENT then
    language.Add("tool.nexus_no_spawn_zone.name", "Nexus No Spawn Zone Tool")
    language.Add("tool.nexus_no_spawn_zone.desc", "Box off areas where spiders are forbidden from spawning.")
    language.Add("tool.nexus_no_spawn_zone.left", "Click to set Corner A or Corner B to box off a zone.")
    language.Add("tool.nexus_no_spawn_zone.right", "Cancel corner selection or remove nearest zone.")
    language.Add("tool.nexus_no_spawn_zone.reload", "Clear all No-Spawn Zones.")

    hook.Add("PostDrawTranslucentRenderables", "NexusProcNoSpawnZonesRender", function(bDepth, bSkybox)
        if bDepth or bSkybox then return end

        local ply = LocalPlayer()
        if not IsValid(ply) then return end

        local wep = ply:GetActiveWeapon()
        if not IsValid(wep) or wep:GetClass() ~= "gmod_tool" then return end

        local tool = ply:GetTool("nexus_no_spawn_zone")
        if not tool then return end

        local zones = Nexus.Proc.NoSpawnZones or {}
        local redWireColor = Color(255, 60, 60, 220)
        local redBoxColor = Color(255, 0, 0, 40)

        -- 1. Draw existing zones
        for i, zone in ipairs(zones) do
            if zone.min and zone.max then
                local center = (zone.min + zone.max) * 0.5
                local size = zone.max - zone.min
                local halfSize = size * 0.5

                -- Draw translucent fill and wireframe outline
                render.SetColorMaterial()
                render.DrawBox(center, Angle(0, 0, 0), -halfSize, halfSize, redBoxColor)
                render.DrawWireframeBox(center, Angle(0, 0, 0), -halfSize, halfSize, redWireColor, true)

                -- Draw 3D label above the center of the box
                local angle = LocalPlayer():EyeAngles()
                angle:RotateAroundAxis(angle:Up(), -90)
                angle:RotateAroundAxis(angle:Forward(), 90)

                cam.Start3D2D(center + Vector(0, 0, halfSize.z + 10), angle, 0.2)
                    draw.SimpleText("NO SPAWN ZONE #" .. i, "ChatFont", 0, 0, Color(255, 80, 80, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                cam.End3D2D()
            end
        end

        -- 2. Draw live preview box if stage == 1
        if tool:GetStage() == 1 then
            local cornerA = wep:GetNWVector("NexusCornerA")
            local tr = ply:GetEyeTrace()
            if cornerA and tr.HitPos then
                local cornerB = tr.HitPos
                local minPos = Vector(
                    math.min(cornerA.x, cornerB.x),
                    math.min(cornerA.y, cornerB.y),
                    math.min(cornerA.z, cornerB.z)
                )
                local maxPos = Vector(
                    math.max(cornerA.x, cornerB.x),
                    math.max(cornerA.y, cornerB.y),
                    math.max(cornerA.z, cornerB.z)
                )

                if maxPos.z - minPos.z < 32 then
                    minPos.z = minPos.z - 16
                    maxPos.z = maxPos.z + 150
                end

                local center = (minPos + maxPos) * 0.5
                local size = maxPos - minPos
                local halfSize = size * 0.5

                local yellowWire = Color(255, 255, 0, 220)
                local yellowFill = Color(255, 255, 0, 30)

                render.SetColorMaterial()
                render.DrawBox(center, Angle(0, 0, 0), -halfSize, halfSize, yellowFill)
                render.DrawWireframeBox(center, Angle(0, 0, 0), -halfSize, halfSize, yellowWire, true)
            end
        end
    end)
end
