local color_zero = Color(0, 0, 0, 0)

local PANEL = {}
function PANEL:Init()
    self:SetTall(Nexus:GetScale(35))

    self.active = false
    self.buttons = {}

    self.Scroll = self:Add("Nexus:V2:HorizontalScrollPanel")
    self.Scroll:Dock(FILL)

    local lastH = -1
    local old = self.Scroll.PerformLayout
    self.Scroll.PerformLayout = function(s, w, h)
        old(s, w, h)

        if (!self.FullWide) then return end

        local children = s:GetCanvas():GetChildren()
        local wide = w/#children
        for k, child in pairs(children) do
            child:SetWide(wide)
            child:SetPos((k-1)*wide, 0)
        end
    end

    local old = self.Scroll:GetCanvas().PerformLayout
    self.Scroll:GetCanvas().Paint = function(s, w, h)
        if self.Secondary then
            Nexus.RNDX.Draw(Nexus:GetMargin(), 0, 0, w, h, Nexus:GetColor("overlay"))
        end
    end
    self.Scroll:GetCanvas().PerformLayout = function(s, w, h)
        if not self.shouldReform then return end
        self.shouldReform = false
        if self.FullWide then return end

        local buttonHeight = h
        lastH = buttonHeight

        surface.SetFont(Nexus:GetFont({size = math.Round(buttonHeight*.5), dontScale = true}))
        local size = (h - Nexus:GetMargin("small")*2)*.75

        local x, y = 0, 0
        for buttonID, button in pairs(self.buttons) do
            local tw, th = surface.GetTextSize(button.values.text)
            if button.values.icon then
                tw = tw + size + Nexus:GetMargin("small")
            end

            button:SetPos(x, y)
            button:SetSize(tw + Nexus:GetMargin()*2, buttonHeight)
            x = x + button:GetWide() + Nexus:GetMargin()
        end

        self.Scroll:GetCanvas():SetWide(x)
    end
end

function PANEL:SetFullWide(bool)
    self.FullWide = bool
end

function PANEL:SetSecondary(bool)
    self.Secondary = bool
end

function PANEL:AddItem(text, func, icon, id)
    id = id or (#self.buttons + 1)

    if self.buttons[id] then
        error("you have added a tab to the sidebar with an id that already exists")        
        return
    end

    self.active = self.active or id

    local hoverColor = color_zero
    local bgColor = color_zero
    local textColor = Nexus:GetColor("secondary-text")

    local bgFrac = 0
    local overlayFrac = 0
    local textFrac = 0

    local button = self.Scroll:Add("Nexus:V2:Button")
    button:SetTall(Nexus:GetScale(35))
    button:SetText(text)
    button:SetColor(color_zero)
    button:SetTextColor(textColor)
    if icon then
        button:SetIcon(icon)
    end

    local textWidth = -1
    local old = button.Paint
    button.Paint = function(s, w, h)
        old(s, w, h)

        if self.active == id then
            bgFrac = math.min(1, bgFrac+FrameTime()*5)
        else
            bgFrac = math.max(0, bgFrac-FrameTime()*5)
        end
        hoverColor = color_zero:Lerp(Nexus:GetColor("green"), bgFrac)

        Nexus.Masks.Start()
            Nexus.RDNX.Draw(Nexus:GetMargin(), 0, h - Nexus:GetScale(2), w, 2, hoverColor)
        Nexus.Masks.Source()
            Nexus.RNDX.Draw(0, 0, 0, w, h, color_white)
        Nexus.Masks.End()
    end

    button.OnSizeChanged = function(s)
        textWidth = -1
    end
    button.PerformLayout = function(s, w, h)
        button:SetFont(Nexus:GetFont({size = math.Round(h*.5), dontScale = true}))

        if self.OurFont then button:SetFont(self.OurFont) end
    end

    button.values = {text = text, icon = icon}
    button.func = func
    button.DoClick = function(s)
        self:SelectItem(id)
    end

    self.buttons[id] = button

    if self.active == id then
        self:SelectItem(id)
    end
end

function PANEL:GetActiveText()
    return self.buttons[self.active].values.text
end

function PANEL:SetBody(bod)
    self.OurBody = bod
end

function PANEL:SelectItem(id)
    for itemID, button in pairs(self.buttons) do
        if itemID == id then
            button:SetTextColor(Nexus:GetColor("primary-text"))
            self.active = id
            if isfunction(button.func) then
                button.func()
            else
                local old = self.CurPanel
                if IsValid(old) then
                    self.CurPanel:AlphaTo(0, .2, 0, function()
                        if IsValid(old) then old:Remove() end
                    end)
                end
                self.CurPanel = self.OurBody:Add(button.func)
                self.CurPanel:Dock(FILL)
                self.CurPanel:SetAlpha(0)
                self.CurPanel:AlphaTo(255, .2, 0, function()
                    if IsValid(old) then old:Remove() end
                end)
                self:OnChange(self.CurPanel, button.func)
            end
        else
            button:SetTextColor(Nexus:GetColor("secondary-text"))
        end
    end
end

function PANEL:SetFont(font)
    self.OurFont = font
    for k, button in pairs(self.buttons) do
        button:SetFont(font)
    end
end

function PANEL:OnChange(panel, panelStr)    
end

function PANEL:PerformLayout(w, h)
    self.shouldReform = true
end

local mat = Material("rectangle_background.png")

function PANEL:Paint(w, h)
    surface.SetDrawColor(Nexus:GetColor("secondary-2"))
    surface.SetMaterial(mat)
    surface.DrawTexturedRect(0, 0, w, h)
end
vgui.Register("Nexus:V2:Navbar", PANEL, "EditablePanel")