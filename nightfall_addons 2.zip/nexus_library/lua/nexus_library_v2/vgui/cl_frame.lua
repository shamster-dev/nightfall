local color_zero = Color(0, 0, 0, 0)

local function AddText(frame, str)
    local label = frame:Add("DLabel")
    label:Dock(TOP)
    label:DockMargin(Nexus:GetMargin(), Nexus:GetMargin(), Nexus:GetMargin(), 1)
    label:SetText(str)
    label:SetFont(Nexus:GetFont({size = 15}))
    label:SetColor(Nexus:GetColor("primary-text"))
end

function Nexus:OpenSettings()
    if IsValid(self.SettingsFrame) then
        self.SettingsFrame:Remove()
    end

    self.SettingsFrame = vgui.Create("Nexus:V2:Frame")
    self.SettingsFrame:SetSize(Nexus:GetScale(320), Nexus:GetScale(350))
    self.SettingsFrame:Center()
    self.SettingsFrame:MakePopup()
    self.SettingsFrame.OnRefresh = function() Nexus:OpenSettings() end

    local scroll = self.SettingsFrame:Add("Nexus:V2:ScrollPanel")
    scroll:Dock(FILL)

    local languages = scroll:Add("Nexus:V2:ComboBox")
    languages:Dock(TOP)
    languages:DockMargin(Nexus:GetMargin(), Nexus:GetMargin(), Nexus:GetMargin(), 0)
    languages:SetText(Nexus:GetSetting("nexus_language", "en"))
    for _, value in ipairs(Nexus:GetLanguages()) do
        languages:AddChoice(value, function()
            if not Nexus:IsLanguageLoaded(value) then
                Nexus:QueryPopup(string.format(Nexus:GetInstalledText(value, "download"), value), function()
                    Nexus:LoadLanguage(value, function(success)
                        Nexus:SetSetting("nexus_language", value)
                    end)
                end, nil, Nexus:GetInstalledText(value, "yes"), Nexus:GetInstalledText(value, "no"))

                return
            end

            Nexus:SetSetting("nexus_language", value)
        end)
    end

    AddText(scroll, Nexus:GetPhrase("Themes", "nexus_lib"))

    local themes = scroll:Add("Nexus:V2:ComboBox")
    themes:Dock(TOP)
    themes:DockMargin(Nexus:GetMargin(), 0, Nexus:GetMargin(), 0)
    themes:SetText(Nexus:GetSetting("nexus_theme", "default"))
    for themeID, _ in pairs(Nexus:GetThemes()) do
        if string.find(themeID, " Blur") then continue end
        themes:AddChoice(themeID, function()
            Nexus:SetSetting("nexus_theme", themeID)
            if IsValid(self.SettingsFrame) then
                self.SettingsFrame:OnRefresh()
            end
        end)
    end

    local blur = scroll:Add("Nexus:V2:CheckBox")
    blur:Dock(TOP)
    blur:DockMargin(Nexus:GetMargin(), Nexus:GetMargin(), Nexus:GetMargin(), 0)
    blur:SetText("Blur")
    blur:SetState(Nexus:GetSetting("nexus_theme_blur", "false") == "true")
    blur.OnChange = function(s, bValue)
        Nexus:SetSetting("nexus_theme_blur", tostring(bValue))
    end

    local tbl = {
        Nexus:GetPhrase("Default", "nexus_lib") or "",
        Nexus:GetPhrase("Thin", "nexus_lib") or "",
    }

    AddText(scroll, Nexus:GetPhrase("Header Style", "nexus_lib"))

    local uiSizes = scroll:Add("Nexus:V2:ComboBox")
    uiSizes:Dock(TOP)
    uiSizes:DockMargin(Nexus:GetMargin(), 0, Nexus:GetMargin(), 0)
    uiSizes:SetText(tbl[Nexus:GetSetting("nexus-UISize", 0)+1])
    for sizeID, sizeText in ipairs(tbl) do
        uiSizes:AddChoice(sizeText, function()
            Nexus:SetSetting("nexus-UISize", sizeID-1)
            if IsValid(self.SettingsFrame) then
                self.SettingsFrame:OnRefresh()
            end
        end)
    end

    AddText(scroll, Nexus:GetPhrase("UI Scale", "nexus_lib"))

    local UIScale = scroll:Add("Nexus:V2:NumSlider")
    UIScale:Dock(TOP)
    UIScale:DockMargin(Nexus:GetMargin(), 0, Nexus:GetMargin(), 0)
    UIScale:SetMinMax(75, 125)
    UIScale:SetValue(Nexus:GetSetting("nexus_UIScale", 100))
    UIScale.OnChange = function(s, value)
        Nexus:SetSetting("nexus_UIScale", math.Round(value))
        hook.Run("Nexus:Accessibility")
    end
end

local gradient = Material("vgui/gradient-l")
local PANEL = {}
function PANEL:Init()
    self.Roundness = Nexus:GetMargin("large")
    self.UISize = Nexus:GetSetting("nexus-UISize", 0)

    self.Header = self:Add("DPanel")
    self.Header:Dock(TOP)
    self.Header:DockPadding(Nexus:GetMargin("large"), Nexus:GetMargin(), Nexus:GetMargin("large"), Nexus:GetMargin())
    self.Header:SetTall(self.UISize == 1 and Nexus:GetScale(35) or Nexus:GetScale(50))
    self.Header.Paint = function(s, w, h)
    end
    self.Header.PerformLayout = function(s, w, h)
        local tall = h - Nexus:GetMargin()*2
        s.QuickButtons:SetWide(Nexus:GetMargin()*2 + (#s.QuickButtons.Buttons * tall) + ((#s.QuickButtons.Buttons-1) * Nexus:GetMargin()))
        self.CloseButton:SetWide(tall)
    end

    self.Header.TitleBox = self.Header:Add("DPanel")
    self.Header.TitleBox:Dock(FILL)
    self.Header.TitleBox.Paint = nil
    self.Header.TitleBox.PerformLayout = function(s, w, h)
        local tall = h
        self.Header.TitleBox.Logo:SetTall(tall)
        self.Header.TitleBox.Logo:SetPos(0, (h/2) - (tall/2))
    end

    self.logo = Nexus:GetValue("nexus-logo")
    self.Header.TitleBox.Logo = self.Header.TitleBox:Add("DButton")
    self.Header.TitleBox.Logo:SetText("NIGHT FALL")
    self.Header.TitleBox.Logo:SetFont(Nexus:GetFont({size = 20, bold = true}))
    self.Header.TitleBox.Logo:SizeToContents()
    self.Header.TitleBox.Logo:SetTextColor(Nexus:GetTextColor(Nexus:GetColor("background")))
    self.Header.TitleBox.Logo.Paint = nil
    self.Header.TitleBox.Logo.DoClick = function(s)
        gui.OpenURL(Nexus:GetValue("nexus-link") == "" and "https://www.gmodstore.com/teams/V06g5EAhRaGpHvVnXz5HvA/products" or Nexus:GetValue("nexus-link"))
    end

    local col = Nexus:GetColor("secondary")
    self.Header.QuickButtons = self.Header:Add("DPanel")
    self.Header.QuickButtons:Dock(LEFT)
    self.Header.QuickButtons:DockMargin(Nexus:GetMargin("large")*2, 0, 0, 0)
    self.Header.QuickButtons.Paint = nil
    self.Header.QuickButtons.PerformLayout = function(s, w, h)
        for _, button in ipairs(s.Buttons) do
            if not IsValid(button) then continue end
            button:SetWide(h)
        end
    end

    local hoverColor = color_zero

    self.Header.QuickButtons.Buttons = {}
    self.Header.QuickButtons.AddButton = function(s, icon, doClick)
        local frac = 0
        local button = s:Add("Nexus:V2:Button")
        button:Dock(LEFT)
        button:DockMargin(0, 0, Nexus:GetMargin(), 0)
        button:SetText("")
        button:SetColor(Nexus:GetColor("highlight"))
        button:SetIcon(icon, function(h) return h*.8 end)
        button.DoClick = function()
            doClick()
        end

        table.insert(self.Header.QuickButtons.Buttons, button)

        return button
    end

    local btn = self:AddHeaderButton("https://imgur.com/e6jSBqi", function()
        Nexus:OpenSettings()
        Nexus:SetSetting("nexus_settings_clicked", true)
    end)
    btn.PaintOver = function(s, w, h)
        if Nexus:GetSetting("nexus_settings_clicked") then return end
        local size = h*.75
        Nexus:DrawImgur("https://imgur.com/061iHd3.png", (w/2) - (size/2), (h/2)-(size/2), size, size)
    end

    local buttonColor = Nexus:GetColor("highlight")
    local textColor = color_black
    local frac = 0
    self.CloseButton = self.Header:Add("Nexus:V2:Button")
    self.CloseButton:Dock(RIGHT)
    self.CloseButton:SetText("")
    self.CloseButton:SetColor(buttonColor)
    local old = self.CloseButton.Paint
    self.CloseButton.PaintOver = function(s, w, h)
        local size = h*.4
        Nexus:DrawImgur("https://imgur.com/q9PwEiy", (w/2) - (size/2), (h/2) - (size/2), size, size, textColor)
    end
    self.CloseButton.DoClick = function()
        self:Remove()
    end

    self.Header.DragBar = self.Header:Add("DButton")
    self.Header.DragBar:Dock(FILL)
    self.Header.DragBar:SetText("")
    self.Header.DragBar.Paint = nil
    self.Header.DragBar:SetCursor("sizeall")
    self.Header.DragBar.OnMousePressed = function(s, code)
        if code == MOUSE_LEFT then
            self.Dragging = true
            local x, y = gui.MousePos()
            self.DragX = x - self:GetX()
            self.DragY = y - self:GetY()
        end
    end
    self.Header.DragBar.OnMouseReleased = function(s, code)
        if code == MOUSE_LEFT then
            self.Dragging = false
        end
    end
    local old = self.Header.DragBar.Think
    self.Header.DragBar.Think = function(s)
        old(s)
        if self.Dragging then
            local x, y = gui.MousePos()
            self:SetPos(x - self.DragX, y - self.DragY)
        end
    end

    local col = Nexus:GetColor("overlay")
    self.LineBreak = self:Add("DPanel")
    self.LineBreak:Dock(TOP)
    self.LineBreak:SetTall(Nexus:GetScale(2))
    self.LineBreak.Paint = function(s, w, h)
        surface.SetDrawColor(col.r, col.g, col.b, col.a)
        surface.DrawRect(0, 0, w, h)
    end

    self:LoadLegacy()
    self:DockPadding(Nexus:GetMargin("large"), Nexus:GetMargin("large"), Nexus:GetMargin("large"), Nexus:GetMargin("large"))
end

function PANEL:OnRefresh() end

function PANEL:HideHeader()
    self.Header:Hide()
    self.LineBreak:Hide()
end

function PANEL:HideHeaderButton()
    self.Header.QuickButtons:Hide()
end

function PANEL:HideCloseButton()
    self.CloseButton:Hide()
end

function PANEL:AddHeaderButton(icon, doClick)
    return self.Header.QuickButtons:AddButton(icon, doClick)
end

function PANEL:SetLogo(logo)
    self.logo = logo
end

function PANEL:SetDraggable(bDraggable)
    self.Header.DragBar:SetVisible(bDraggable)
end

function PANEL:HideTitleBox()
    self.Header.TitleBox:Hide()
end

function PANEL:SetRoundness(roundness)
    self.Roundness = roundness
end

function PANEL:SelectContent(str)
    if IsValid(self.Content) then self.Content:Remove() end
    self.Content = self:Add(str)
    self.Content:Dock(FILL)
    self.Content:DockMargin(Nexus:GetMargin(), Nexus:GetMargin(), 0, 0)
end

local mat = Material("rectangle_background.png")
local mini_mat = Material("mini_rectangle_background.png")

function PANEL:SetWhite()
    self.White = true
end

function PANEL:Paint(w, h)
    local col = Nexus:GetColor("background")
    col = self.White and Nexus:GetTextColor(Nexus:GetColor("background")) or col

    Nexus.RNDX.DrawMaterial(0, 0, 0, w, h, Nexus:SetAlpha(col, 220), mini_mat)
    //surface.SetDrawColor(col.r, col.g, col.b, 190)
   //surface.SetMaterial(mini_mat)
   //surface.DrawTexturedRect(0, 0, w, h)
end

// legacy support
function PANEL:SetBarIcon(icon, title, subheading, doClick) end
function PANEL:SetTitle(title) end
function PANEL:PerformLayout(w, h) end

function PANEL:LoadLegacy()
    self.BarButton = self.Header:Add("DButton")
    self.BarButton:Hide()

    self.Header.Content = self.Header:Add("DPanel")
    self.Header.Content:Dock(FILL)
    self.Header.Content:DockMargin(Nexus:GetMargin(), Nexus:GetMargin(), 0, Nexus:GetMargin())
    self.Header.Content.Paint = nil
    self.Header.Content:Hide()

    self.Header.TitleBox.TitleArea = self.Header.TitleBox:Add("Panel")
    self.Header.TitleBox.TitleArea:Hide()

    self.Header.TitleBox.TitleArea.ServerName = self.Header.TitleBox.TitleArea:Add("DLabel")
    self.Header.TitleBox.TitleArea.ServerName:Hide()

    self.Header.TitleBox.TitleArea.Title = self.Header.TitleBox.TitleArea:Add("DLabel")
    self.Header.TitleBox.TitleArea.Title:Hide()
end
vgui.Register("Nexus:V2:Frame", PANEL, "EditablePanel")