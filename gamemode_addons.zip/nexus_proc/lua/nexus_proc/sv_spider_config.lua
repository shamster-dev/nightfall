-- sv_spider_config.lua
-- Server-side live spider settings & difficulty management.

if CLIENT then return end

util.AddNetworkString("NexusProc:SpiderConfig:Sync")
util.AddNetworkString("NexusProc:SpiderConfig:Update")
util.AddNetworkString("NexusProc:SpiderConfig:Reset")
util.AddNetworkString("NexusProc:SpiderConfig:RequestSync")
util.AddNetworkString("NexusProc:SpiderConfig:OpenMenu")

local CONFIG_FILE_PATH = "nexus_proc/spider_config.json"

function Nexus.Proc.SaveSpiderConfig()
    file.CreateDir("nexus_proc")
    local json = util.TableToJSON(Nexus.Proc.SpiderConfig or {}, true)
    file.Write(CONFIG_FILE_PATH, json)
end

function Nexus.Proc.LoadSpiderConfig()
    if file.Exists(CONFIG_FILE_PATH, "DATA") then
        local raw = file.Read(CONFIG_FILE_PATH, "DATA")
        local loaded = util.JSONToTable(raw or "")
        if loaded and type(loaded) == "table" then
            for k, v in pairs(loaded) do
                Nexus.Proc.SpiderConfig[k] = v
            end
        end
    end
    Nexus.Proc.SyncGlobalsFromConfig()
end

function Nexus.Proc.SyncGlobalsFromConfig()
    local cfg = Nexus.Proc.SpiderConfig
    if not cfg then return end

    Nexus.Proc.SpiderSpawnTimer = cfg.SpawnTimer or 6.0
    Nexus.Proc.SpiderSpawnDistance = { cfg.MinSpawnDist or 1500, cfg.MaxSpawnDist or 1800 }

    Nexus.Proc.Spiders = Nexus.Proc.Spiders or {}
    Nexus.Proc.Spiders["nexus_spider"] = cfg.WeightNexusSpider or 60.0
    Nexus.Proc.Spiders["nexus_jumping_spider"] = cfg.WeightJumpingSpider or 39.5
    Nexus.Proc.Spiders["nexus_mother_spider"] = cfg.WeightMotherSpider or 0.5
end

function Nexus.Proc.BroadcastSpiderConfig(target)
    net.Start("NexusProc:SpiderConfig:Sync")
    net.WriteTable(Nexus.Proc.SpiderConfig or {})
    if IsValid(target) then
        net.Send(target)
    else
        net.Broadcast()
    end
end

function Nexus.Proc.ApplySpiderConfig(newConfig, callerPly)
    if not newConfig or type(newConfig) ~= "table" then return end

    for k, v in pairs(newConfig) do
        Nexus.Proc.SpiderConfig[k] = v
    end

    Nexus.Proc.SyncGlobalsFromConfig()
    Nexus.Proc.SaveSpiderConfig()

    -- Live update active spawn timer if round active
    local state = GetGlobalInt("NightFall:RoundState", 0)
    if state == 2 and timer.Exists("NightFall:SpawnSpiders") then -- ROUND_ACTIVE
        timer.Adjust("NightFall:SpawnSpiders", Nexus.Proc.SpiderSpawnTimer, 0)
    end

    -- Real-time update active spider entities in map
    local healthMult = Nexus.Proc.GetSpiderSetting("HealthMult", 1.0)
    local damageMult = Nexus.Proc.GetSpiderSetting("DamageMult", 1.0)
    local speedMult  = Nexus.Proc.GetSpiderSetting("SpeedMult", 1.0)

    -- Update standard & jumping spiders
    for _, class in ipairs({"nexus_spider", "nexus_jumping_spider"}) do
        for _, ent in ipairs(ents.FindByClass(class)) do
            if not IsValid(ent) or ent:GetNWBool("IsDead", false) then continue end

            if ent.genes then
                local oldMax = ent:GetMaxHealth()
                local baseHP = ent.genes.health or 50
                local newMax = math.max(1, math.floor(baseHP * healthMult))

                local currentRatio = oldMax > 0 and (ent:Health() / oldMax) or 1.0
                ent:SetMaxHealth(newMax)
                ent:SetHealth(math.Clamp(math.floor(newMax * currentRatio), 1, newMax))

                local newSpeed = (ent.genes.speed or 350) * speedMult
                if class == "nexus_jumping_spider" then newSpeed = newSpeed * 1.2 end

                if ent.loco then
                    ent.loco:SetDesiredSpeed(newSpeed)
                end
            end
        end
    end

    -- Update mother spiders
    for _, mother in ipairs(ents.FindByClass("nexus_mother_spider")) do
        if not IsValid(mother) or mother:GetNWBool("IsDead", false) then continue end
        local activePlayers = math.max(1, Nexus.Proc:GetPlayersParticipatingCount())
        local baseHP = (Nexus.Proc.GetSpiderSetting("MotherBaseHP", 1000) + (activePlayers * Nexus.Proc.GetSpiderSetting("MotherHPPerPlayer", 350)))
        local newMax = math.max(1, math.floor(baseHP * healthMult))
        local oldMax = mother:GetMaxHealth()

        local currentRatio = oldMax > 0 and (mother:Health() / oldMax) or 1.0
        mother:SetMaxHealth(newMax)
        mother:SetHealth(math.Clamp(math.floor(newMax * currentRatio), 1, newMax))

        if mother.loco then
            mother.loco:SetDesiredSpeed((Nexus.Proc.GetSpiderSetting("MotherSpeed", 150)) * speedMult)
        end
    end

    -- Update spider eggs
    for _, egg in ipairs(ents.FindByClass("nexus_spider_egg")) do
        if not IsValid(egg) or egg.isHatching then continue end
        local eggHP = math.max(1, math.floor(Nexus.Proc.GetSpiderSetting("EggHealth", 50) * healthMult))
        egg:SetMaxHealth(eggHP)
        if egg:Health() > eggHP then egg:SetHealth(eggHP) end
    end

    Nexus.Proc.BroadcastSpiderConfig()

    local msg = "[Nexus] Live spider settings & difficulty (" .. tostring(Nexus.Proc.SpiderConfig.Difficulty or "Custom") .. ") updated successfully."
    if IsValid(callerPly) then
        Nexus:ChatMessage(callerPly, {color_white, "[ System ] ", msg})
    else
        print(msg)
    end
end

-- Network receivers
net.Receive("NexusProc:SpiderConfig:Update", function(len, ply)
    if not IsValid(ply) or not (ply:IsSuperAdmin() or ply:IsAdmin()) then return end
    local updatedData = net.ReadTable()
    if updatedData and type(updatedData) == "table" then
        Nexus.Proc.ApplySpiderConfig(updatedData, ply)
    end
end)

net.Receive("NexusProc:SpiderConfig:Reset", function(len, ply)
    if not IsValid(ply) or not (ply:IsSuperAdmin() or ply:IsAdmin()) then return end
    Nexus.Proc.SpiderConfig = table.Copy(Nexus.Proc.DefaultSpiderConfig)
    Nexus.Proc.ApplySpiderConfig(Nexus.Proc.SpiderConfig, ply)
end)

net.Receive("NexusProc:SpiderConfig:RequestSync", function(len, ply)
    if IsValid(ply) then
        Nexus.Proc.BroadcastSpiderConfig(ply)
    end
end)

hook.Add("Initialize", "NexusProc:SpiderConfig:Init", function()
    Nexus.Proc.LoadSpiderConfig()
end)

hook.Add("PlayerInitialSpawn", "NexusProc:SpiderConfig:SyncJoin", function(ply)
    timer.Simple(2, function()
        if IsValid(ply) then
            Nexus.Proc.BroadcastSpiderConfig(ply)
        end
    end)
end)
