-- cl_spider_config_menu.lua
-- Client-side UI panel for live spider settings and difficulty configuration.

if SERVER then return end

local PANEL = {}

function PANEL:Init()
    self:SetSize(Nexus:GetScale(680), Nexus:GetScale(540))
    self:Center()
    self:MakePopup()

    self.ConfigDraft = table.Copy(Nexus.Proc.SpiderConfig or Nexus.Proc.DefaultSpiderConfig)

    self.Header = self:Add("DPanel")
    self.Header:Dock(TOP)
    self.Header:SetTall(Nexus:GetScale(60))
    self.Header.Paint = function(s, w, h)
        draw.RoundedBox(0, 0, 0, w, h, Color(25, 25, 30, 240))
        draw.SimpleText("SPIDER & DIFFICULTY SETTINGS", Nexus:GetFont({size = 22, bold = true}), Nexus:GetScale(15), Nexus:GetScale(12), Color(230, 230, 235), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        draw.SimpleText("Adjust live game difficulty and procedural spider parameters in real-time.", Nexus:GetFont({size = 13}), Nexus:GetScale(15), Nexus:GetScale(36), Color(160, 165, 175), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    end

    -- Close Button
    self.CloseBtn = self.Header:Add("DButton")
    self.CloseBtn:Dock(RIGHT)
    self.CloseBtn:SetWide(Nexus:GetScale(40))
    self.CloseBtn:SetText("X")
    self.CloseBtn:SetFont(Nexus:GetFont({size = 18, bold = true}))
    self.CloseBtn:SetTextColor(Color(200, 200, 200))
    self.CloseBtn.Paint = function(s, w, h)
        if s:IsHovered() then
            draw.RoundedBox(0, 0, 0, w, h, Color(180, 40, 40, 220))
        end
    end
    self.CloseBtn.DoClick = function()
        self:Remove()
    end

    -- Preset Selector Bar
    self.PresetBar = self:Add("DPanel")
    self.PresetBar:Dock(TOP)
    self.PresetBar:SetTall(Nexus:GetScale(45))
    self.PresetBar:DockMargin(Nexus:GetMargin(), Nexus:GetMargin(), Nexus:GetMargin(), 0)
    self.PresetBar.Paint = function(s, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Color(35, 38, 46, 220))
        draw.SimpleText("PRESET:", Nexus:GetFont({size = 14, bold = true}), Nexus:GetMargin("large"), h/2, Color(200, 205, 215), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    local presetList = {"Easy", "Normal", "Hard", "Nightmare"}
    local pBtnX = Nexus:GetScale(90)
    for _, pName in ipairs(presetList) do
        local btn = self.PresetBar:Add("DButton")
        btn:SetSize(Nexus:GetScale(100), Nexus:GetScale(30))
        btn:SetPos(pBtnX, Nexus:GetScale(7.5))
        btn:SetText(pName)
        btn:SetFont(Nexus:GetFont({size = 14, bold = true}))

        btn.Paint = function(s, w, h)
            local isCurrent = (self.ConfigDraft.Difficulty == pName)
            local col = isCurrent and Color(180, 40, 40) or (s:IsHovered() and Color(65, 70, 85) or Color(45, 48, 58))
            draw.RoundedBox(4, 0, 0, w, h, col)
            btn:SetTextColor(isCurrent and Color(255, 255, 255) or Color(190, 195, 205))
        end

        btn.DoClick = function()
            Nexus.Proc.ApplyPresetToConfig(pName, self.ConfigDraft)
            self.ConfigDraft.Difficulty = pName
            self:RefreshFormValues()
        end

        pBtnX = pBtnX + Nexus:GetScale(110)
    end

    -- Category Tabs Sheet
    self.PropertySheet = self:Add("DPropertySheet")
    self.PropertySheet:Dock(FILL)
    self.PropertySheet:DockMargin(Nexus:GetMargin(), Nexus:GetMargin(), Nexus:GetMargin(), 0)
    self.PropertySheet.Paint = function(s, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Color(28, 30, 36, 230))
    end

    self:BuildWaveTab()
    self:BuildCombatTab()
    self:BuildBossTab()
    self:BuildEggTab()

    -- Bottom Actions Bar
    self.BottomBar = self:Add("DPanel")
    self.BottomBar:Dock(BOTTOM)
    self.BottomBar:SetTall(Nexus:GetScale(45))
    self.BottomBar:DockMargin(Nexus:GetMargin(), Nexus:GetMargin(), Nexus:GetMargin(), Nexus:GetMargin())
    self.BottomBar.Paint = nil

    self.ApplyBtn = self.BottomBar:Add("DButton")
    self.ApplyBtn:Dock(RIGHT)
    self.ApplyBtn:SetWide(Nexus:GetScale(160))
    self.ApplyBtn:SetText("APPLY LIVE")
    self.ApplyBtn:SetFont(Nexus:GetFont({size = 15, bold = true}))
    self.ApplyBtn:SetTextColor(Color(255, 255, 255))
    self.ApplyBtn.Paint = function(s, w, h)
        draw.RoundedBox(4, 0, 0, w, h, s:IsHovered() and Color(40, 160, 80) or Color(30, 130, 65))
    end
    self.ApplyBtn.DoClick = function()
        net.Start("NexusProc:SpiderConfig:Update")
        net.WriteTable(self.ConfigDraft)
        net.SendToServer()
        self:Remove()
    end

    self.ResetBtn = self.BottomBar:Add("DButton")
    self.ResetBtn:Dock(LEFT)
    self.ResetBtn:SetWide(Nexus:GetScale(140))
    self.ResetBtn:SetText("RESET DEFAULTS")
    self.ResetBtn:SetFont(Nexus:GetFont({size = 14, bold = true}))
    self.ResetBtn:SetTextColor(Color(210, 210, 210))
    self.ResetBtn.Paint = function(s, w, h)
        draw.RoundedBox(4, 0, 0, w, h, s:IsHovered() and Color(170, 50, 50) or Color(130, 40, 40))
    end
    self.ResetBtn.DoClick = function()
        net.Start("NexusProc:SpiderConfig:Reset")
        net.SendToServer()
        self:Remove()
    end
end

function PANEL:CreateSliderRow(parent, labelText, keyName, minVal, maxVal, isFloat)
    local pnl = parent:Add("DPanel")
    pnl:Dock(TOP)
    pnl:SetTall(Nexus:GetScale(36))
    pnl:DockMargin(Nexus:GetMargin("small"), Nexus:GetMargin("small"), Nexus:GetMargin("small"), 0)
    pnl.Paint = function(s, w, h)
        draw.RoundedBox(2, 0, 0, w, h, Color(35, 38, 46, 180))
        draw.SimpleText(labelText, Nexus:GetFont({size = 13, bold = true}), Nexus:GetMargin(), h/2, Color(220, 225, 230), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    local slider = pnl:Add("DNumSlider")
    slider:Dock(RIGHT)
    slider:SetWide(Nexus:GetScale(320))
    slider:SetMin(minVal)
    slider:SetMax(maxVal)
    slider:SetDecimals(isFloat and 2 or 0)
    slider:SetValue(self.ConfigDraft[keyName] or minVal)
    slider.OnValueChanged = function(s, val)
        self.ConfigDraft[keyName] = isFloat and math.Round(val, 2) or math.Round(val)
        self.ConfigDraft.Difficulty = "Custom"
    end

    self.Sliders = self.Sliders or {}
    self.Sliders[keyName] = { slider = slider, isFloat = isFloat }
end

function PANEL:RefreshFormValues()
    if not self.Sliders then return end
    for keyName, info in pairs(self.Sliders) do
        if self.ConfigDraft[keyName] ~= nil and IsValid(info.slider) then
            info.slider:SetValue(self.ConfigDraft[keyName])
        end
    end
end

function PANEL:BuildWaveTab()
    local scroll = vgui.Create("DScrollPanel", self.PropertySheet)
    scroll:Dock(FILL)

    self:CreateSliderRow(scroll, "Spawn Cycle Timer (Seconds)", "SpawnTimer", 1, 30, true)
    self:CreateSliderRow(scroll, "Min Spawn Distance (Units)", "MinSpawnDist", 300, 3000, false)
    self:CreateSliderRow(scroll, "Max Spawn Distance (Units)", "MaxSpawnDist", 500, 4000, false)
    self:CreateSliderRow(scroll, "Max Spiders Per Player Target", "MaxSpidersPerPlayer", 1, 10, false)

    self:CreateSliderRow(scroll, "Normal Spider Spawn Weight (%)", "WeightNexusSpider", 0, 100, true)
    self:CreateSliderRow(scroll, "Jumping Spider Spawn Weight (%)", "WeightJumpingSpider", 0, 100, true)
    self:CreateSliderRow(scroll, "Mother Spider Spawn Weight (%)", "WeightMotherSpider", 0, 50, true)

    self.PropertySheet:AddSheet("Spawning & Waves", scroll, "icon16/time.png")
end

function PANEL:BuildCombatTab()
    local scroll = vgui.Create("DScrollPanel", self.PropertySheet)
    scroll:Dock(FILL)

    self:CreateSliderRow(scroll, "Health Multiplier", "HealthMult", 0.2, 5.0, true)
    self:CreateSliderRow(scroll, "Damage Multiplier", "DamageMult", 0.2, 5.0, true)
    self:CreateSliderRow(scroll, "Speed Multiplier", "SpeedMult", 0.2, 3.0, true)

    self:CreateSliderRow(scroll, "Detection Range (Units)", "DetectRange", 400, 3000, false)
    self:CreateSliderRow(scroll, "Chase Range (Units)", "ChaseRange", 300, 2500, false)
    self:CreateSliderRow(scroll, "Melee Attack Range (Units)", "AttackRange", 30, 200, false)
    self:CreateSliderRow(scroll, "Bite Attack Rate (Seconds)", "AttackRate", 0.3, 4.0, true)

    self.PropertySheet:AddSheet("Stats & Combat", scroll, "icon16/sword.png")
end

function PANEL:BuildBossTab()
    local scroll = vgui.Create("DScrollPanel", self.PropertySheet)
    scroll:Dock(FILL)

    self:CreateSliderRow(scroll, "Mother Spider Base HP", "MotherBaseHP", 200, 10000, false)
    self:CreateSliderRow(scroll, "Mother Spider HP Per Player", "MotherHPPerPlayer", 50, 2000, false)
    self:CreateSliderRow(scroll, "Mother Spider Movement Speed", "MotherSpeed", 50, 400, false)
    self:CreateSliderRow(scroll, "Baby Spawn Interval (Seconds)", "MotherBabySpawnInterval", 2, 30, true)
    self:CreateSliderRow(scroll, "Babies Spawned On Death", "MotherDeathBabies", 0, 10, false)

    self.PropertySheet:AddSheet("Mother Boss", scroll, "icon16/bug.png")
end

function PANEL:BuildEggTab()
    local scroll = vgui.Create("DScrollPanel", self.PropertySheet)
    scroll:Dock(FILL)

    self:CreateSliderRow(scroll, "Egg Base Health", "EggHealth", 10, 500, false)
    self:CreateSliderRow(scroll, "Hatch Proximity Distance (Units)", "EggHatchRange", 100, 800, false)
    self:CreateSliderRow(scroll, "Hatch Baby Count", "EggHatchCount", 1, 8, false)
    self:CreateSliderRow(scroll, "Break Spawn Chance (0.0 to 1.0)", "EggBreakSpawnChance", 0.0, 1.0, true)

    self.PropertySheet:AddSheet("Spider Eggs", scroll, "icon16/egg.png")
end

function PANEL:Paint(w, h)
    draw.RoundedBox(6, 0, 0, w, h, Color(20, 22, 26, 245))
end

vgui.Register("Nexus:Proc:SpiderSettingsPanel", PANEL, "EditablePanel")

-- Network listeners
net.Receive("NexusProc:SpiderConfig:Sync", function()
    local tbl = net.ReadTable()
    if tbl and type(tbl) == "table" then
        Nexus.Proc.SpiderConfig = tbl
        if IsValid(Nexus.Proc.SpiderSettingsFrame) then
            Nexus.Proc.SpiderSettingsFrame.ConfigDraft = table.Copy(tbl)
            Nexus.Proc.SpiderSettingsFrame:RefreshFormValues()
        end
    end
end)

net.Receive("NexusProc:SpiderConfig:OpenMenu", function()
    if IsValid(Nexus.Proc.SpiderSettingsFrame) then
        Nexus.Proc.SpiderSettingsFrame:Remove()
    end

    net.Start("NexusProc:SpiderConfig:RequestSync")
    net.SendToServer()

    Nexus.Proc.SpiderSettingsFrame = vgui.Create("Nexus:Proc:SpiderSettingsPanel")
end)
